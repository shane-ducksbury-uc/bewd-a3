# WordPress MySQL database migration
#
# Generated: Tuesday 30. November 2021 08:18 UTC
# Hostname: db
# Database: `wordpress`
# URL: //sockbrew.design
# Path: /var/www/html
# Tables: wp_actionscheduler_actions, wp_actionscheduler_claims, wp_actionscheduler_groups, wp_actionscheduler_logs, wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users, wp_wpforms_tasks_meta, wp_wpmailsmtp_debug_events, wp_wpmailsmtp_tasks_meta
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, board-member, forum, nav_menu_item, news-post, page, post, publication, wpforms
# Protocol: https
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_actionscheduler_actions`
#

DROP TABLE IF EXISTS `wp_actionscheduler_actions`;


#
# Table structure of table `wp_actionscheduler_actions`
#

CREATE TABLE `wp_actionscheduler_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scheduled_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `args` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schedule` longtext COLLATE utf8mb4_unicode_520_ci,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `attempts` int(11) NOT NULL DEFAULT '0',
  `last_attempt_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `extended_args` varchar(8000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `hook` (`hook`),
  KEY `status` (`status`),
  KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  KEY `args` (`args`),
  KEY `group_id` (`group_id`),
  KEY `last_attempt_gmt` (`last_attempt_gmt`),
  KEY `claim_id` (`claim_id`),
  KEY `claim_id_status_scheduled_date_gmt` (`claim_id`,`status`,`scheduled_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=192 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_actions`
#
INSERT INTO `wp_actionscheduler_actions` ( `action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES
(119, 'wpforms_email_summaries_fetch_info_blocks', 'complete', '2021-10-31 01:24:33', '2021-10-31 01:24:33', '{"tasks_meta_id":null}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1635643473;s:18:"\0*\0first_timestamp";i:1633696717;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1635643473;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1635643473;s:15:"first_timestamp";i:1633696717;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1635643473;s:19:"interval_in_seconds";i:604800;}', 2, 1, '2021-10-31 01:25:02', '2021-10-31 11:25:02', 0, NULL),
(120, 'wpforms_admin_addons_cache_update', 'complete', '2021-10-31 01:24:33', '2021-10-31 01:24:33', '{"tasks_meta_id":2}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1635643473;s:18:"\0*\0first_timestamp";i:1634428874;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1635643473;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1635643473;s:15:"first_timestamp";i:1634428874;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1635643473;s:19:"interval_in_seconds";i:604800;}', 2, 1, '2021-10-31 01:25:02', '2021-10-31 11:25:02', 0, NULL),
(121, 'wpforms_admin_builder_templates_cache_update', 'complete', '2021-10-31 01:24:33', '2021-10-31 01:24:33', '{"tasks_meta_id":3}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1635643473;s:18:"\0*\0first_timestamp";i:1634428874;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1635643473;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1635643473;s:15:"first_timestamp";i:1634428874;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1635643473;s:19:"interval_in_seconds";i:604800;}', 2, 1, '2021-10-31 01:25:02', '2021-10-31 11:25:02', 0, NULL),
(123, 'wpforms_builder_help_cache_update', 'complete', '2021-10-31 23:09:56', '2021-10-31 23:09:56', '{"tasks_meta_id":12}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1635721796;s:18:"\0*\0first_timestamp";i:1635114594;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1635721796;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1635721796;s:15:"first_timestamp";i:1635114594;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1635721796;s:19:"interval_in_seconds";i:604800;}', 2, 1, '2021-11-01 00:08:54', '2021-11-01 10:08:54', 0, NULL),
(125, 'wp_mail_smtp_summary_report_email', 'complete', '2021-11-01 05:28:24', '2021-11-01 05:28:24', '[1]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1635744504;s:18:"\0*\0first_timestamp";i:1633924800;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1635744504;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1635744504;s:15:"first_timestamp";i:1633924800;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1635744504;s:19:"interval_in_seconds";i:604800;}', 3, 1, '2021-11-01 05:30:47', '2021-11-01 15:30:47', 0, NULL),
(130, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-10-31 04:49:53', '2021-10-31 04:49:53', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1635655793;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1635655793;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1635655793;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1635655793;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-10-31 05:25:47', '2021-10-31 15:25:47', 0, NULL),
(131, 'wpforms_email_summaries_fetch_info_blocks', 'complete', '2021-11-07 01:25:02', '2021-11-07 01:25:02', '{"tasks_meta_id":null}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1636248302;s:18:"\0*\0first_timestamp";i:1633696717;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1636248302;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1636248302;s:15:"first_timestamp";i:1633696717;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1636248302;s:19:"interval_in_seconds";i:604800;}', 2, 1, '2021-11-07 03:57:08', '2021-11-07 13:57:08', 0, NULL),
(132, 'wpforms_admin_addons_cache_update', 'complete', '2021-11-07 01:25:02', '2021-11-07 01:25:02', '{"tasks_meta_id":2}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1636248302;s:18:"\0*\0first_timestamp";i:1634428874;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1636248302;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1636248302;s:15:"first_timestamp";i:1634428874;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1636248302;s:19:"interval_in_seconds";i:604800;}', 2, 1, '2021-11-07 03:57:08', '2021-11-07 13:57:08', 0, NULL),
(133, 'wpforms_admin_builder_templates_cache_update', 'complete', '2021-11-07 01:25:02', '2021-11-07 01:25:02', '{"tasks_meta_id":3}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1636248302;s:18:"\0*\0first_timestamp";i:1634428874;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1636248302;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1636248302;s:15:"first_timestamp";i:1634428874;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1636248302;s:19:"interval_in_seconds";i:604800;}', 2, 1, '2021-11-07 03:57:08', '2021-11-07 13:57:08', 0, NULL),
(134, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-01 05:25:47', '2021-11-01 05:25:47', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1635744347;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1635744347;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1635744347;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1635744347;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-01 05:30:44', '2021-11-01 15:30:44', 0, NULL),
(135, 'wpforms_builder_help_cache_update', 'complete', '2021-11-08 00:08:54', '2021-11-08 00:08:54', '{"tasks_meta_id":12}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1636330134;s:18:"\0*\0first_timestamp";i:1635114594;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1636330134;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1636330134;s:15:"first_timestamp";i:1635114594;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1636330134;s:19:"interval_in_seconds";i:604800;}', 2, 1, '2021-11-08 01:17:53', '2021-11-08 11:17:53', 0, NULL),
(136, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-02 05:30:44', '2021-11-02 05:30:44', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1635831044;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1635831044;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1635831044;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1635831044;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-02 05:32:38', '2021-11-02 15:32:38', 0, NULL),
(137, 'wp_mail_smtp_summary_report_email', 'complete', '2021-11-08 05:30:47', '2021-11-08 05:30:47', '[1]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1636349447;s:18:"\0*\0first_timestamp";i:1633924800;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1636349447;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1636349447;s:15:"first_timestamp";i:1633924800;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1636349447;s:19:"interval_in_seconds";i:604800;}', 3, 1, '2021-11-08 05:36:31', '2021-11-08 15:36:31', 0, NULL),
(138, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-03 05:32:38', '2021-11-03 05:32:38', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1635917558;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1635917558;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1635917558;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1635917558;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-03 05:34:01', '2021-11-03 15:34:01', 0, NULL),
(139, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-04 05:34:01', '2021-11-04 05:34:01', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1636004041;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1636004041;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1636004041;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1636004041;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-04 10:00:22', '2021-11-04 20:00:22', 0, NULL),
(140, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-05 10:00:22', '2021-11-05 10:00:22', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1636106422;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1636106422;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1636106422;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1636106422;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-05 10:40:11', '2021-11-05 20:40:11', 0, NULL),
(141, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-06 10:40:11', '2021-11-06 10:40:11', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1636195211;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1636195211;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1636195211;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1636195211;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-06 10:45:25', '2021-11-06 20:45:25', 0, NULL),
(142, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-07 10:45:25', '2021-11-07 10:45:25', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1636281925;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1636281925;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1636281925;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1636281925;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-07 11:21:06', '2021-11-07 21:21:06', 0, NULL),
(143, 'wpforms_email_summaries_fetch_info_blocks', 'complete', '2021-11-14 03:57:08', '2021-11-14 03:57:08', '{"tasks_meta_id":null}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1636862228;s:18:"\0*\0first_timestamp";i:1633696717;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1636862228;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1636862228;s:15:"first_timestamp";i:1633696717;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1636862228;s:19:"interval_in_seconds";i:604800;}', 2, 1, '2021-11-14 03:58:30', '2021-11-14 13:58:30', 0, NULL),
(144, 'wpforms_admin_addons_cache_update', 'complete', '2021-11-14 03:57:08', '2021-11-14 03:57:08', '{"tasks_meta_id":2}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1636862228;s:18:"\0*\0first_timestamp";i:1634428874;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1636862228;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1636862228;s:15:"first_timestamp";i:1634428874;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1636862228;s:19:"interval_in_seconds";i:604800;}', 2, 1, '2021-11-14 03:58:30', '2021-11-14 13:58:30', 0, NULL),
(145, 'wpforms_admin_builder_templates_cache_update', 'complete', '2021-11-14 03:57:08', '2021-11-14 03:57:08', '{"tasks_meta_id":3}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1636862228;s:18:"\0*\0first_timestamp";i:1634428874;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1636862228;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1636862228;s:15:"first_timestamp";i:1634428874;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1636862228;s:19:"interval_in_seconds";i:604800;}', 2, 1, '2021-11-14 03:58:30', '2021-11-14 13:58:30', 0, NULL),
(146, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-08 11:21:06', '2021-11-08 11:21:06', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1636370466;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1636370466;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1636370466;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1636370466;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-08 13:35:18', '2021-11-08 23:35:18', 0, NULL),
(147, 'wpforms_builder_help_cache_update', 'complete', '2021-11-15 01:17:53', '2021-11-15 01:17:53', '{"tasks_meta_id":12}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1636939073;s:18:"\0*\0first_timestamp";i:1635114594;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1636939073;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1636939073;s:15:"first_timestamp";i:1635114594;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1636939073;s:19:"interval_in_seconds";i:604800;}', 2, 1, '2021-11-15 01:48:51', '2021-11-15 11:48:51', 0, NULL),
(148, 'wp_mail_smtp_summary_report_email', 'complete', '2021-11-15 05:36:31', '2021-11-15 05:36:31', '[1]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1636954591;s:18:"\0*\0first_timestamp";i:1633924800;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1636954591;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1636954591;s:15:"first_timestamp";i:1633924800;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1636954591;s:19:"interval_in_seconds";i:604800;}', 3, 1, '2021-11-15 06:03:26', '2021-11-15 16:03:26', 0, NULL),
(149, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-09 13:35:18', '2021-11-09 13:35:18', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1636464918;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1636464918;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1636464918;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1636464918;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-09 13:40:10', '2021-11-09 23:40:10', 0, NULL),
(150, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-10 13:40:10', '2021-11-10 13:40:10', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1636551610;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1636551610;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1636551610;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1636551610;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-10 17:17:43', '2021-11-11 03:17:43', 0, NULL),
(151, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-11 17:17:43', '2021-11-11 17:17:43', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1636651063;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1636651063;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1636651063;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1636651063;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-11 18:16:05', '2021-11-12 04:16:05', 0, NULL),
(152, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-12 18:16:05', '2021-11-12 18:16:05', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1636740965;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1636740965;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1636740965;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1636740965;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-12 18:38:09', '2021-11-13 04:38:09', 0, NULL),
(153, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-13 18:38:09', '2021-11-13 18:38:09', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1636828689;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1636828689;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1636828689;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1636828689;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-13 18:43:02', '2021-11-14 04:43:02', 0, NULL),
(154, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-14 18:43:02', '2021-11-14 18:43:02', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1636915382;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1636915382;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1636915382;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1636915382;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-14 18:53:21', '2021-11-15 04:53:21', 0, NULL),
(155, 'wpforms_email_summaries_fetch_info_blocks', 'complete', '2021-11-21 03:58:30', '2021-11-21 03:58:30', '{"tasks_meta_id":null}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1637467110;s:18:"\0*\0first_timestamp";i:1633696717;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1637467110;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1637467110;s:15:"first_timestamp";i:1633696717;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1637467110;s:19:"interval_in_seconds";i:604800;}', 2, 1, '2021-11-21 04:06:29', '2021-11-21 14:06:29', 0, NULL),
(156, 'wpforms_admin_addons_cache_update', 'complete', '2021-11-21 03:58:30', '2021-11-21 03:58:30', '{"tasks_meta_id":2}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1637467110;s:18:"\0*\0first_timestamp";i:1634428874;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1637467110;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1637467110;s:15:"first_timestamp";i:1634428874;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1637467110;s:19:"interval_in_seconds";i:604800;}', 2, 1, '2021-11-21 04:06:29', '2021-11-21 14:06:29', 0, NULL),
(157, 'wpforms_admin_builder_templates_cache_update', 'complete', '2021-11-21 03:58:30', '2021-11-21 03:58:30', '{"tasks_meta_id":3}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1637467110;s:18:"\0*\0first_timestamp";i:1634428874;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1637467110;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1637467110;s:15:"first_timestamp";i:1634428874;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1637467110;s:19:"interval_in_seconds";i:604800;}', 2, 1, '2021-11-21 04:06:29', '2021-11-21 14:06:29', 0, NULL),
(158, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-15 18:53:21', '2021-11-15 18:53:21', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1637002401;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1637002401;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1637002401;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1637002401;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-15 19:28:22', '2021-11-16 05:28:22', 0, NULL),
(159, 'wp_mail_smtp_admin_notifications_update', 'complete', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '[11]', 'O:28:"ActionScheduler_NullSchedule":0:{}', 3, 1, '2021-11-14 20:59:50', '2021-11-15 06:59:50', 0, NULL),
(160, 'wpforms_admin_notifications_update', 'complete', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '{"tasks_meta_id":15}', 'O:28:"ActionScheduler_NullSchedule":0:{}', 2, 1, '2021-11-14 20:59:50', '2021-11-15 06:59:50', 0, NULL),
(161, 'wpforms_builder_help_cache_update', 'complete', '2021-11-22 01:48:51', '2021-11-22 01:48:51', '{"tasks_meta_id":12}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1637545731;s:18:"\0*\0first_timestamp";i:1635114594;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1637545731;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1637545731;s:15:"first_timestamp";i:1635114594;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1637545731;s:19:"interval_in_seconds";i:604800;}', 2, 1, '2021-11-22 02:05:59', '2021-11-22 12:05:59', 0, NULL),
(162, 'wp_mail_smtp_summary_report_email', 'complete', '2021-11-22 06:03:26', '2021-11-22 06:03:26', '[1]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1637561006;s:18:"\0*\0first_timestamp";i:1633924800;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1637561006;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1637561006;s:15:"first_timestamp";i:1633924800;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1637561006;s:19:"interval_in_seconds";i:604800;}', 3, 1, '2021-11-22 06:32:17', '2021-11-22 16:32:17', 0, NULL),
(163, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-16 19:28:22', '2021-11-16 19:28:22', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1637090902;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1637090902;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1637090902;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1637090902;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-16 19:31:58', '2021-11-17 05:31:58', 0, NULL),
(164, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-17 19:31:58', '2021-11-17 19:31:58', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1637177518;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1637177518;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1637177518;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1637177518;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-17 19:41:52', '2021-11-18 05:41:52', 0, NULL),
(165, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-18 19:41:52', '2021-11-18 19:41:52', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1637264512;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1637264512;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1637264512;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1637264512;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-18 20:05:52', '2021-11-19 06:05:52', 0, NULL),
(166, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-19 20:05:52', '2021-11-19 20:05:52', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1637352352;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1637352352;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1637352352;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1637352352;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-19 20:08:52', '2021-11-20 06:08:52', 0, NULL),
(167, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-20 20:08:52', '2021-11-20 20:08:52', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1637438932;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1637438932;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1637438932;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1637438932;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-20 20:14:32', '2021-11-21 06:14:32', 0, NULL),
(168, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-21 20:14:32', '2021-11-21 20:14:32', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1637525672;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1637525672;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1637525672;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1637525672;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-21 20:19:51', '2021-11-22 06:19:51', 0, NULL),
(169, 'wpforms_email_summaries_fetch_info_blocks', 'complete', '2021-11-28 04:06:29', '2021-11-28 04:06:29', '{"tasks_meta_id":null}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1638072389;s:18:"\0*\0first_timestamp";i:1633696717;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1638072389;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1638072389;s:15:"first_timestamp";i:1633696717;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1638072389;s:19:"interval_in_seconds";i:604800;}', 2, 1, '2021-11-28 05:40:59', '2021-11-28 15:40:59', 0, NULL),
(170, 'wpforms_admin_addons_cache_update', 'complete', '2021-11-28 04:06:29', '2021-11-28 04:06:29', '{"tasks_meta_id":2}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1638072389;s:18:"\0*\0first_timestamp";i:1634428874;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1638072389;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1638072389;s:15:"first_timestamp";i:1634428874;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1638072389;s:19:"interval_in_seconds";i:604800;}', 2, 1, '2021-11-28 05:40:59', '2021-11-28 15:40:59', 0, NULL),
(171, 'wpforms_admin_builder_templates_cache_update', 'complete', '2021-11-28 04:06:29', '2021-11-28 04:06:29', '{"tasks_meta_id":3}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1638072389;s:18:"\0*\0first_timestamp";i:1634428874;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1638072389;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1638072389;s:15:"first_timestamp";i:1634428874;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1638072389;s:19:"interval_in_seconds";i:604800;}', 2, 1, '2021-11-28 05:40:59', '2021-11-28 15:40:59', 0, NULL),
(172, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-22 20:19:51', '2021-11-22 20:19:51', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1637612391;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1637612391;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1637612391;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1637612391;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-22 20:48:24', '2021-11-23 06:48:24', 0, NULL),
(173, 'wpforms_builder_help_cache_update', 'complete', '2021-11-29 02:05:59', '2021-11-29 02:05:59', '{"tasks_meta_id":12}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1638151559;s:18:"\0*\0first_timestamp";i:1635114594;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1638151559;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1638151559;s:15:"first_timestamp";i:1635114594;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1638151559;s:19:"interval_in_seconds";i:604800;}', 2, 1, '2021-11-29 02:07:07', '2021-11-29 12:07:07', 0, NULL),
(174, 'wp_mail_smtp_summary_report_email', 'complete', '2021-11-29 06:32:17', '2021-11-29 06:32:17', '[1]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1638167537;s:18:"\0*\0first_timestamp";i:1633924800;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1638167537;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1638167537;s:15:"first_timestamp";i:1633924800;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1638167537;s:19:"interval_in_seconds";i:604800;}', 3, 1, '2021-11-29 06:34:03', '2021-11-29 16:34:03', 0, NULL),
(175, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-23 20:48:24', '2021-11-23 20:48:24', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1637700504;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1637700504;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1637700504;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1637700504;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-23 20:57:05', '2021-11-24 06:57:05', 0, NULL),
(176, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-24 20:57:05', '2021-11-24 20:57:05', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1637787425;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1637787425;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1637787425;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1637787425;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-24 21:03:53', '2021-11-25 07:03:53', 0, NULL),
(177, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-25 21:03:53', '2021-11-25 21:03:53', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1637874233;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1637874233;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1637874233;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1637874233;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-25 21:10:57', '2021-11-26 07:10:57', 0, NULL),
(178, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-26 21:10:57', '2021-11-26 21:10:57', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1637961057;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1637961057;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1637961057;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1637961057;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-26 21:17:44', '2021-11-27 07:17:44', 0, NULL),
(179, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-27 21:17:44', '2021-11-27 21:17:44', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1638047864;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1638047864;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1638047864;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1638047864;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-27 21:20:31', '2021-11-28 07:20:31', 0, NULL),
(180, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-28 21:20:31', '2021-11-28 21:20:31', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1638134431;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1638134431;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1638134431;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1638134431;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-28 21:23:22', '2021-11-29 07:23:22', 0, NULL),
(181, 'wpforms_email_summaries_fetch_info_blocks', 'pending', '2021-12-05 05:40:59', '2021-12-05 05:40:59', '{"tasks_meta_id":null}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1638682859;s:18:"\0*\0first_timestamp";i:1633696717;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1638682859;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1638682859;s:15:"first_timestamp";i:1633696717;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1638682859;s:19:"interval_in_seconds";i:604800;}', 2, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(182, 'wpforms_admin_addons_cache_update', 'pending', '2021-12-05 05:40:59', '2021-12-05 05:40:59', '{"tasks_meta_id":2}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1638682859;s:18:"\0*\0first_timestamp";i:1634428874;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1638682859;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1638682859;s:15:"first_timestamp";i:1634428874;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1638682859;s:19:"interval_in_seconds";i:604800;}', 2, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(183, 'wpforms_admin_builder_templates_cache_update', 'pending', '2021-12-05 05:40:59', '2021-12-05 05:40:59', '{"tasks_meta_id":3}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1638682859;s:18:"\0*\0first_timestamp";i:1634428874;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1638682859;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1638682859;s:15:"first_timestamp";i:1634428874;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1638682859;s:19:"interval_in_seconds";i:604800;}', 2, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(184, 'wpforms_process_entry_emails_meta_cleanup', 'complete', '2021-11-29 21:23:22', '2021-11-29 21:23:22', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1638221002;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1638221002;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1638221002;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1638221002;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2021-11-29 21:24:16', '2021-11-30 07:24:16', 0, NULL),
(185, 'wpforms_builder_help_cache_update', 'pending', '2021-12-06 02:07:07', '2021-12-06 02:07:07', '{"tasks_meta_id":12}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1638756427;s:18:"\0*\0first_timestamp";i:1635114594;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1638756427;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1638756427;s:15:"first_timestamp";i:1635114594;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1638756427;s:19:"interval_in_seconds";i:604800;}', 2, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(186, 'wp_mail_smtp_summary_report_email', 'pending', '2021-12-06 06:34:03', '2021-12-06 06:34:03', '[1]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1638772443;s:18:"\0*\0first_timestamp";i:1633924800;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1638772443;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1638772443;s:15:"first_timestamp";i:1633924800;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1638772443;s:19:"interval_in_seconds";i:604800;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(187, 'wpforms_process_entry_emails_meta_cleanup', 'pending', '2021-11-30 21:24:16', '2021-11-30 21:24:16', '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1638307456;s:18:"\0*\0first_timestamp";i:1633910400;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1638307456;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1638307456;s:15:"first_timestamp";i:1633910400;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1638307456;s:19:"interval_in_seconds";i:86400;}', 2, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(188, 'wp_mail_smtp_admin_notifications_update', 'complete', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '[12]', 'O:28:"ActionScheduler_NullSchedule":0:{}', 3, 1, '2021-11-30 08:16:53', '2021-11-30 18:16:53', 0, NULL),
(189, 'wpforms_admin_notifications_update', 'complete', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '{"tasks_meta_id":16}', 'O:28:"ActionScheduler_NullSchedule":0:{}', 2, 1, '2021-11-30 08:16:54', '2021-11-30 18:16:54', 0, NULL),
(190, 'wp_mail_smtp_admin_notifications_update', 'complete', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '[13]', 'O:28:"ActionScheduler_NullSchedule":0:{}', 3, 1, '2021-11-30 08:16:54', '2021-11-30 18:16:54', 0, NULL),
(191, 'wpforms_admin_notifications_update', 'complete', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '{"tasks_meta_id":17}', 'O:28:"ActionScheduler_NullSchedule":0:{}', 2, 1, '2021-11-30 08:16:54', '2021-11-30 18:16:54', 0, NULL) ;

#
# End of data contents of table `wp_actionscheduler_actions`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_claims`
#

DROP TABLE IF EXISTS `wp_actionscheduler_claims`;


#
# Table structure of table `wp_actionscheduler_claims`
#

CREATE TABLE `wp_actionscheduler_claims` (
  `claim_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`claim_id`),
  KEY `date_created_gmt` (`date_created_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=4748 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_claims`
#

#
# End of data contents of table `wp_actionscheduler_claims`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_groups`
#

DROP TABLE IF EXISTS `wp_actionscheduler_groups`;


#
# Table structure of table `wp_actionscheduler_groups`
#

CREATE TABLE `wp_actionscheduler_groups` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_groups`
#
INSERT INTO `wp_actionscheduler_groups` ( `group_id`, `slug`) VALUES
(1, 'action-scheduler-migration'),
(2, 'wpforms'),
(3, 'wp_mail_smtp') ;

#
# End of data contents of table `wp_actionscheduler_groups`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_logs`
#

DROP TABLE IF EXISTS `wp_actionscheduler_logs`;


#
# Table structure of table `wp_actionscheduler_logs`
#

CREATE TABLE `wp_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `log_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=343 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_logs`
#
INSERT INTO `wp_actionscheduler_logs` ( `log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(126, 119, 'action created', '2021-10-24 01:24:33', '2021-10-24 01:24:33'),
(129, 120, 'action created', '2021-10-24 01:24:33', '2021-10-24 01:24:33'),
(132, 121, 'action created', '2021-10-24 01:24:33', '2021-10-24 01:24:33'),
(138, 123, 'action created', '2021-10-24 23:09:56', '2021-10-24 23:09:56'),
(144, 125, 'action created', '2021-10-25 05:28:24', '2021-10-25 05:28:24'),
(159, 130, 'action created', '2021-10-30 04:49:53', '2021-10-30 04:49:53'),
(160, 119, 'action started via WP Cron', '2021-10-31 01:25:02', '2021-10-31 01:25:02'),
(161, 119, 'action complete via WP Cron', '2021-10-31 01:25:02', '2021-10-31 01:25:02'),
(162, 131, 'action created', '2021-10-31 01:25:02', '2021-10-31 01:25:02'),
(163, 120, 'action started via WP Cron', '2021-10-31 01:25:02', '2021-10-31 01:25:02'),
(164, 120, 'action complete via WP Cron', '2021-10-31 01:25:02', '2021-10-31 01:25:02'),
(165, 132, 'action created', '2021-10-31 01:25:02', '2021-10-31 01:25:02'),
(166, 121, 'action started via WP Cron', '2021-10-31 01:25:02', '2021-10-31 01:25:02'),
(167, 121, 'action complete via WP Cron', '2021-10-31 01:25:02', '2021-10-31 01:25:02'),
(168, 133, 'action created', '2021-10-31 01:25:02', '2021-10-31 01:25:02'),
(169, 130, 'action started via WP Cron', '2021-10-31 05:25:47', '2021-10-31 05:25:47'),
(170, 130, 'action complete via WP Cron', '2021-10-31 05:25:47', '2021-10-31 05:25:47'),
(171, 134, 'action created', '2021-10-31 05:25:47', '2021-10-31 05:25:47'),
(172, 123, 'action started via WP Cron', '2021-11-01 00:08:54', '2021-11-01 00:08:54'),
(173, 123, 'action complete via WP Cron', '2021-11-01 00:08:54', '2021-11-01 00:08:54'),
(174, 135, 'action created', '2021-11-01 00:08:54', '2021-11-01 00:08:54'),
(175, 134, 'action started via WP Cron', '2021-11-01 05:30:44', '2021-11-01 05:30:44'),
(176, 134, 'action complete via WP Cron', '2021-11-01 05:30:44', '2021-11-01 05:30:44'),
(177, 136, 'action created', '2021-11-01 05:30:44', '2021-11-01 05:30:44'),
(178, 125, 'action started via WP Cron', '2021-11-01 05:30:44', '2021-11-01 05:30:44'),
(179, 125, 'action complete via WP Cron', '2021-11-01 05:30:47', '2021-11-01 05:30:47'),
(180, 137, 'action created', '2021-11-01 05:30:47', '2021-11-01 05:30:47'),
(181, 136, 'action started via WP Cron', '2021-11-02 05:32:38', '2021-11-02 05:32:38'),
(182, 136, 'action complete via WP Cron', '2021-11-02 05:32:38', '2021-11-02 05:32:38'),
(183, 138, 'action created', '2021-11-02 05:32:38', '2021-11-02 05:32:38'),
(184, 138, 'action started via WP Cron', '2021-11-03 05:34:01', '2021-11-03 05:34:01'),
(185, 138, 'action complete via WP Cron', '2021-11-03 05:34:01', '2021-11-03 05:34:01'),
(186, 139, 'action created', '2021-11-03 05:34:01', '2021-11-03 05:34:01'),
(187, 139, 'action started via WP Cron', '2021-11-04 10:00:22', '2021-11-04 10:00:22'),
(188, 139, 'action complete via WP Cron', '2021-11-04 10:00:22', '2021-11-04 10:00:22'),
(189, 140, 'action created', '2021-11-04 10:00:22', '2021-11-04 10:00:22'),
(190, 140, 'action started via WP Cron', '2021-11-05 10:40:11', '2021-11-05 10:40:11'),
(191, 140, 'action complete via WP Cron', '2021-11-05 10:40:11', '2021-11-05 10:40:11'),
(192, 141, 'action created', '2021-11-05 10:40:11', '2021-11-05 10:40:11'),
(193, 141, 'action started via WP Cron', '2021-11-06 10:45:25', '2021-11-06 10:45:25'),
(194, 141, 'action complete via WP Cron', '2021-11-06 10:45:25', '2021-11-06 10:45:25'),
(195, 142, 'action created', '2021-11-06 10:45:25', '2021-11-06 10:45:25'),
(196, 131, 'action started via WP Cron', '2021-11-07 03:57:08', '2021-11-07 03:57:08'),
(197, 131, 'action complete via WP Cron', '2021-11-07 03:57:08', '2021-11-07 03:57:08'),
(198, 143, 'action created', '2021-11-07 03:57:08', '2021-11-07 03:57:08'),
(199, 132, 'action started via WP Cron', '2021-11-07 03:57:08', '2021-11-07 03:57:08'),
(200, 132, 'action complete via WP Cron', '2021-11-07 03:57:08', '2021-11-07 03:57:08'),
(201, 144, 'action created', '2021-11-07 03:57:08', '2021-11-07 03:57:08'),
(202, 133, 'action started via WP Cron', '2021-11-07 03:57:08', '2021-11-07 03:57:08'),
(203, 133, 'action complete via WP Cron', '2021-11-07 03:57:08', '2021-11-07 03:57:08'),
(204, 145, 'action created', '2021-11-07 03:57:08', '2021-11-07 03:57:08'),
(205, 142, 'action started via WP Cron', '2021-11-07 11:21:06', '2021-11-07 11:21:06'),
(206, 142, 'action complete via WP Cron', '2021-11-07 11:21:06', '2021-11-07 11:21:06'),
(207, 146, 'action created', '2021-11-07 11:21:06', '2021-11-07 11:21:06'),
(208, 135, 'action started via WP Cron', '2021-11-08 01:17:53', '2021-11-08 01:17:53'),
(209, 135, 'action complete via WP Cron', '2021-11-08 01:17:53', '2021-11-08 01:17:53'),
(210, 147, 'action created', '2021-11-08 01:17:53', '2021-11-08 01:17:53'),
(211, 137, 'action started via WP Cron', '2021-11-08 05:36:29', '2021-11-08 05:36:29'),
(212, 137, 'action complete via WP Cron', '2021-11-08 05:36:31', '2021-11-08 05:36:31'),
(213, 148, 'action created', '2021-11-08 05:36:31', '2021-11-08 05:36:31'),
(214, 146, 'action started via WP Cron', '2021-11-08 13:35:18', '2021-11-08 13:35:18'),
(215, 146, 'action complete via WP Cron', '2021-11-08 13:35:18', '2021-11-08 13:35:18'),
(216, 149, 'action created', '2021-11-08 13:35:18', '2021-11-08 13:35:18'),
(217, 149, 'action started via WP Cron', '2021-11-09 13:40:10', '2021-11-09 13:40:10'),
(218, 149, 'action complete via WP Cron', '2021-11-09 13:40:10', '2021-11-09 13:40:10'),
(219, 150, 'action created', '2021-11-09 13:40:10', '2021-11-09 13:40:10'),
(220, 150, 'action started via WP Cron', '2021-11-10 17:17:43', '2021-11-10 17:17:43'),
(221, 150, 'action complete via WP Cron', '2021-11-10 17:17:43', '2021-11-10 17:17:43'),
(222, 151, 'action created', '2021-11-10 17:17:43', '2021-11-10 17:17:43'),
(223, 151, 'action started via WP Cron', '2021-11-11 18:16:05', '2021-11-11 18:16:05'),
(224, 151, 'action complete via WP Cron', '2021-11-11 18:16:05', '2021-11-11 18:16:05'),
(225, 152, 'action created', '2021-11-11 18:16:05', '2021-11-11 18:16:05'),
(226, 152, 'action started via WP Cron', '2021-11-12 18:38:09', '2021-11-12 18:38:09'),
(227, 152, 'action complete via WP Cron', '2021-11-12 18:38:09', '2021-11-12 18:38:09'),
(228, 153, 'action created', '2021-11-12 18:38:09', '2021-11-12 18:38:09'),
(229, 153, 'action started via WP Cron', '2021-11-13 18:43:02', '2021-11-13 18:43:02'),
(230, 153, 'action complete via WP Cron', '2021-11-13 18:43:02', '2021-11-13 18:43:02'),
(231, 154, 'action created', '2021-11-13 18:43:02', '2021-11-13 18:43:02'),
(232, 143, 'action started via WP Cron', '2021-11-14 03:58:30', '2021-11-14 03:58:30'),
(233, 143, 'action complete via WP Cron', '2021-11-14 03:58:30', '2021-11-14 03:58:30'),
(234, 155, 'action created', '2021-11-14 03:58:30', '2021-11-14 03:58:30'),
(235, 144, 'action started via WP Cron', '2021-11-14 03:58:30', '2021-11-14 03:58:30'),
(236, 144, 'action complete via WP Cron', '2021-11-14 03:58:30', '2021-11-14 03:58:30'),
(237, 156, 'action created', '2021-11-14 03:58:30', '2021-11-14 03:58:30'),
(238, 145, 'action started via WP Cron', '2021-11-14 03:58:30', '2021-11-14 03:58:30'),
(239, 145, 'action complete via WP Cron', '2021-11-14 03:58:30', '2021-11-14 03:58:30'),
(240, 157, 'action created', '2021-11-14 03:58:30', '2021-11-14 03:58:30'),
(241, 154, 'action started via WP Cron', '2021-11-14 18:53:21', '2021-11-14 18:53:21'),
(242, 154, 'action complete via WP Cron', '2021-11-14 18:53:21', '2021-11-14 18:53:21'),
(243, 158, 'action created', '2021-11-14 18:53:21', '2021-11-14 18:53:21'),
(244, 159, 'action created', '2021-11-14 20:58:12', '2021-11-14 20:58:12'),
(245, 160, 'action created', '2021-11-14 20:58:12', '2021-11-14 20:58:12'),
(246, 159, 'action started via WP Cron', '2021-11-14 20:59:50', '2021-11-14 20:59:50'),
(247, 159, 'action complete via WP Cron', '2021-11-14 20:59:50', '2021-11-14 20:59:50'),
(248, 160, 'action started via WP Cron', '2021-11-14 20:59:50', '2021-11-14 20:59:50'),
(249, 160, 'action complete via WP Cron', '2021-11-14 20:59:50', '2021-11-14 20:59:50'),
(250, 147, 'action started via WP Cron', '2021-11-15 01:48:51', '2021-11-15 01:48:51'),
(251, 147, 'action complete via WP Cron', '2021-11-15 01:48:51', '2021-11-15 01:48:51'),
(252, 161, 'action created', '2021-11-15 01:48:51', '2021-11-15 01:48:51'),
(253, 148, 'action started via WP Cron', '2021-11-15 06:03:23', '2021-11-15 06:03:23') ;
INSERT INTO `wp_actionscheduler_logs` ( `log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(254, 148, 'action complete via WP Cron', '2021-11-15 06:03:26', '2021-11-15 06:03:26'),
(255, 162, 'action created', '2021-11-15 06:03:26', '2021-11-15 06:03:26'),
(256, 158, 'action started via WP Cron', '2021-11-15 19:28:22', '2021-11-15 19:28:22'),
(257, 158, 'action complete via WP Cron', '2021-11-15 19:28:22', '2021-11-15 19:28:22'),
(258, 163, 'action created', '2021-11-15 19:28:22', '2021-11-15 19:28:22'),
(259, 163, 'action started via WP Cron', '2021-11-16 19:31:58', '2021-11-16 19:31:58'),
(260, 163, 'action complete via WP Cron', '2021-11-16 19:31:58', '2021-11-16 19:31:58'),
(261, 164, 'action created', '2021-11-16 19:31:58', '2021-11-16 19:31:58'),
(262, 164, 'action started via WP Cron', '2021-11-17 19:41:52', '2021-11-17 19:41:52'),
(263, 164, 'action complete via WP Cron', '2021-11-17 19:41:52', '2021-11-17 19:41:52'),
(264, 165, 'action created', '2021-11-17 19:41:52', '2021-11-17 19:41:52'),
(265, 165, 'action started via WP Cron', '2021-11-18 20:05:52', '2021-11-18 20:05:52'),
(266, 165, 'action complete via WP Cron', '2021-11-18 20:05:52', '2021-11-18 20:05:52'),
(267, 166, 'action created', '2021-11-18 20:05:52', '2021-11-18 20:05:52'),
(268, 166, 'action started via WP Cron', '2021-11-19 20:08:52', '2021-11-19 20:08:52'),
(269, 166, 'action complete via WP Cron', '2021-11-19 20:08:52', '2021-11-19 20:08:52'),
(270, 167, 'action created', '2021-11-19 20:08:52', '2021-11-19 20:08:52'),
(271, 167, 'action started via WP Cron', '2021-11-20 20:14:32', '2021-11-20 20:14:32'),
(272, 167, 'action complete via WP Cron', '2021-11-20 20:14:32', '2021-11-20 20:14:32'),
(273, 168, 'action created', '2021-11-20 20:14:32', '2021-11-20 20:14:32'),
(274, 155, 'action started via WP Cron', '2021-11-21 04:06:29', '2021-11-21 04:06:29'),
(275, 155, 'action complete via WP Cron', '2021-11-21 04:06:29', '2021-11-21 04:06:29'),
(276, 169, 'action created', '2021-11-21 04:06:29', '2021-11-21 04:06:29'),
(277, 156, 'action started via WP Cron', '2021-11-21 04:06:29', '2021-11-21 04:06:29'),
(278, 156, 'action complete via WP Cron', '2021-11-21 04:06:29', '2021-11-21 04:06:29'),
(279, 170, 'action created', '2021-11-21 04:06:29', '2021-11-21 04:06:29'),
(280, 157, 'action started via WP Cron', '2021-11-21 04:06:29', '2021-11-21 04:06:29'),
(281, 157, 'action complete via WP Cron', '2021-11-21 04:06:29', '2021-11-21 04:06:29'),
(282, 171, 'action created', '2021-11-21 04:06:29', '2021-11-21 04:06:29'),
(283, 168, 'action started via WP Cron', '2021-11-21 20:19:51', '2021-11-21 20:19:51'),
(284, 168, 'action complete via WP Cron', '2021-11-21 20:19:51', '2021-11-21 20:19:51'),
(285, 172, 'action created', '2021-11-21 20:19:51', '2021-11-21 20:19:51'),
(286, 161, 'action started via WP Cron', '2021-11-22 02:05:59', '2021-11-22 02:05:59'),
(287, 161, 'action complete via WP Cron', '2021-11-22 02:05:59', '2021-11-22 02:05:59'),
(288, 173, 'action created', '2021-11-22 02:05:59', '2021-11-22 02:05:59'),
(289, 162, 'action started via WP Cron', '2021-11-22 06:32:15', '2021-11-22 06:32:15'),
(290, 162, 'action complete via WP Cron', '2021-11-22 06:32:17', '2021-11-22 06:32:17'),
(291, 174, 'action created', '2021-11-22 06:32:17', '2021-11-22 06:32:17'),
(292, 172, 'action started via WP Cron', '2021-11-22 20:48:24', '2021-11-22 20:48:24'),
(293, 172, 'action complete via WP Cron', '2021-11-22 20:48:24', '2021-11-22 20:48:24'),
(294, 175, 'action created', '2021-11-22 20:48:24', '2021-11-22 20:48:24'),
(295, 175, 'action started via WP Cron', '2021-11-23 20:57:05', '2021-11-23 20:57:05'),
(296, 175, 'action complete via WP Cron', '2021-11-23 20:57:05', '2021-11-23 20:57:05'),
(297, 176, 'action created', '2021-11-23 20:57:05', '2021-11-23 20:57:05'),
(298, 176, 'action started via WP Cron', '2021-11-24 21:03:53', '2021-11-24 21:03:53'),
(299, 176, 'action complete via WP Cron', '2021-11-24 21:03:53', '2021-11-24 21:03:53'),
(300, 177, 'action created', '2021-11-24 21:03:53', '2021-11-24 21:03:53'),
(301, 177, 'action started via WP Cron', '2021-11-25 21:10:57', '2021-11-25 21:10:57'),
(302, 177, 'action complete via WP Cron', '2021-11-25 21:10:57', '2021-11-25 21:10:57'),
(303, 178, 'action created', '2021-11-25 21:10:57', '2021-11-25 21:10:57'),
(304, 178, 'action started via WP Cron', '2021-11-26 21:17:44', '2021-11-26 21:17:44'),
(305, 178, 'action complete via WP Cron', '2021-11-26 21:17:44', '2021-11-26 21:17:44'),
(306, 179, 'action created', '2021-11-26 21:17:44', '2021-11-26 21:17:44'),
(307, 179, 'action started via WP Cron', '2021-11-27 21:20:31', '2021-11-27 21:20:31'),
(308, 179, 'action complete via WP Cron', '2021-11-27 21:20:31', '2021-11-27 21:20:31'),
(309, 180, 'action created', '2021-11-27 21:20:31', '2021-11-27 21:20:31'),
(310, 169, 'action started via WP Cron', '2021-11-28 05:40:59', '2021-11-28 05:40:59'),
(311, 169, 'action complete via WP Cron', '2021-11-28 05:40:59', '2021-11-28 05:40:59'),
(312, 181, 'action created', '2021-11-28 05:40:59', '2021-11-28 05:40:59'),
(313, 170, 'action started via WP Cron', '2021-11-28 05:40:59', '2021-11-28 05:40:59'),
(314, 170, 'action complete via WP Cron', '2021-11-28 05:40:59', '2021-11-28 05:40:59'),
(315, 182, 'action created', '2021-11-28 05:40:59', '2021-11-28 05:40:59'),
(316, 171, 'action started via WP Cron', '2021-11-28 05:40:59', '2021-11-28 05:40:59'),
(317, 171, 'action complete via WP Cron', '2021-11-28 05:40:59', '2021-11-28 05:40:59'),
(318, 183, 'action created', '2021-11-28 05:40:59', '2021-11-28 05:40:59'),
(319, 180, 'action started via WP Cron', '2021-11-28 21:23:22', '2021-11-28 21:23:22'),
(320, 180, 'action complete via WP Cron', '2021-11-28 21:23:22', '2021-11-28 21:23:22'),
(321, 184, 'action created', '2021-11-28 21:23:22', '2021-11-28 21:23:22'),
(322, 173, 'action started via WP Cron', '2021-11-29 02:07:07', '2021-11-29 02:07:07'),
(323, 173, 'action complete via WP Cron', '2021-11-29 02:07:07', '2021-11-29 02:07:07'),
(324, 185, 'action created', '2021-11-29 02:07:07', '2021-11-29 02:07:07'),
(325, 174, 'action started via WP Cron', '2021-11-29 06:34:01', '2021-11-29 06:34:01'),
(326, 174, 'action complete via WP Cron', '2021-11-29 06:34:03', '2021-11-29 06:34:03'),
(327, 186, 'action created', '2021-11-29 06:34:03', '2021-11-29 06:34:03'),
(328, 184, 'action started via WP Cron', '2021-11-29 21:24:16', '2021-11-29 21:24:16'),
(329, 184, 'action complete via WP Cron', '2021-11-29 21:24:16', '2021-11-29 21:24:16'),
(330, 187, 'action created', '2021-11-29 21:24:16', '2021-11-29 21:24:16'),
(331, 188, 'action created', '2021-11-30 08:16:01', '2021-11-30 08:16:01'),
(332, 189, 'action created', '2021-11-30 08:16:01', '2021-11-30 08:16:01'),
(333, 188, 'action started via WP Cron', '2021-11-30 08:16:53', '2021-11-30 08:16:53'),
(334, 188, 'action complete via WP Cron', '2021-11-30 08:16:53', '2021-11-30 08:16:53'),
(335, 189, 'action started via WP Cron', '2021-11-30 08:16:53', '2021-11-30 08:16:53'),
(336, 189, 'action complete via WP Cron', '2021-11-30 08:16:54', '2021-11-30 08:16:54'),
(337, 190, 'action created', '2021-11-30 08:16:54', '2021-11-30 08:16:54'),
(338, 191, 'action created', '2021-11-30 08:16:54', '2021-11-30 08:16:54'),
(339, 190, 'action started via Async Request', '2021-11-30 08:16:54', '2021-11-30 08:16:54'),
(340, 190, 'action complete via Async Request', '2021-11-30 08:16:54', '2021-11-30 08:16:54'),
(341, 191, 'action started via Async Request', '2021-11-30 08:16:54', '2021-11-30 08:16:54'),
(342, 191, 'action complete via Async Request', '2021-11-30 08:16:54', '2021-11-30 08:16:54') ;

#
# End of data contents of table `wp_actionscheduler_logs`
# --------------------------------------------------------



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=7779 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'https://sockbrew.design', 'yes'),
(2, 'home', 'https://sockbrew.design', 'yes'),
(3, 'blogname', 'International Building Quality Centre', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'u3113923@uni.canberra.edu.au', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'j F Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'j F Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%category%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:173:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:62:"publications_category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:60:"index.php?publications_category=$matches[1]&feed=$matches[2]";s:57:"publications_category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:60:"index.php?publications_category=$matches[1]&feed=$matches[2]";s:38:"publications_category/([^/]+)/embed/?$";s:54:"index.php?publications_category=$matches[1]&embed=true";s:50:"publications_category/([^/]+)/page/?([0-9]{1,})/?$";s:61:"index.php?publications_category=$matches[1]&paged=$matches[2]";s:32:"publications_category/([^/]+)/?$";s:43:"index.php?publications_category=$matches[1]";s:39:"publication/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:49:"publication/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:69:"publication/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:64:"publication/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:64:"publication/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:45:"publication/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:28:"publication/([^/]+)/embed/?$";s:44:"index.php?publication=$matches[1]&embed=true";s:32:"publication/([^/]+)/trackback/?$";s:38:"index.php?publication=$matches[1]&tb=1";s:40:"publication/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?publication=$matches[1]&paged=$matches[2]";s:47:"publication/([^/]+)/comment-page-([0-9]{1,})/?$";s:51:"index.php?publication=$matches[1]&cpage=$matches[2]";s:36:"publication/([^/]+)(?:/([0-9]+))?/?$";s:50:"index.php?publication=$matches[1]&page=$matches[2]";s:28:"publication/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:38:"publication/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:58:"publication/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:53:"publication/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:53:"publication/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:34:"publication/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:33:"forum/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"forum/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"forum/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"forum/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"forum/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:39:"forum/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:22:"forum/([^/]+)/embed/?$";s:38:"index.php?forum=$matches[1]&embed=true";s:26:"forum/([^/]+)/trackback/?$";s:32:"index.php?forum=$matches[1]&tb=1";s:34:"forum/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?forum=$matches[1]&paged=$matches[2]";s:41:"forum/([^/]+)/comment-page-([0-9]{1,})/?$";s:45:"index.php?forum=$matches[1]&cpage=$matches[2]";s:30:"forum/([^/]+)(?:/([0-9]+))?/?$";s:44:"index.php?forum=$matches[1]&page=$matches[2]";s:22:"forum/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:32:"forum/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:52:"forum/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"forum/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"forum/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:28:"forum/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:40:"board-member/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:50:"board-member/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:70:"board-member/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"board-member/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"board-member/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:46:"board-member/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:29:"board-member/([^/]+)/embed/?$";s:45:"index.php?board-member=$matches[1]&embed=true";s:33:"board-member/([^/]+)/trackback/?$";s:39:"index.php?board-member=$matches[1]&tb=1";s:41:"board-member/([^/]+)/page/?([0-9]{1,})/?$";s:52:"index.php?board-member=$matches[1]&paged=$matches[2]";s:48:"board-member/([^/]+)/comment-page-([0-9]{1,})/?$";s:52:"index.php?board-member=$matches[1]&cpage=$matches[2]";s:37:"board-member/([^/]+)(?:/([0-9]+))?/?$";s:51:"index.php?board-member=$matches[1]&page=$matches[2]";s:29:"board-member/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:39:"board-member/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:59:"board-member/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"board-member/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"board-member/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:35:"board-member/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:37:"news-post/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"news-post/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"news-post/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"news-post/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"news-post/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:43:"news-post/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:26:"news-post/([^/]+)/embed/?$";s:42:"index.php?news-post=$matches[1]&embed=true";s:30:"news-post/([^/]+)/trackback/?$";s:36:"index.php?news-post=$matches[1]&tb=1";s:38:"news-post/([^/]+)/page/?([0-9]{1,})/?$";s:49:"index.php?news-post=$matches[1]&paged=$matches[2]";s:45:"news-post/([^/]+)/comment-page-([0-9]{1,})/?$";s:49:"index.php?news-post=$matches[1]&cpage=$matches[2]";s:34:"news-post/([^/]+)(?:/([0-9]+))?/?$";s:48:"index.php?news-post=$matches[1]&page=$matches[2]";s:26:"news-post/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:36:"news-post/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:56:"news-post/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"news-post/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"news-post/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:32:"news-post/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=8&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:31:".+?/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:41:".+?/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:61:".+?/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:".+?/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:".+?/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:37:".+?/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:22:"(.+?)/([^/]+)/embed/?$";s:63:"index.php?category_name=$matches[1]&name=$matches[2]&embed=true";s:26:"(.+?)/([^/]+)/trackback/?$";s:57:"index.php?category_name=$matches[1]&name=$matches[2]&tb=1";s:46:"(.+?)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]";s:41:"(.+?)/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]";s:34:"(.+?)/([^/]+)/page/?([0-9]{1,})/?$";s:70:"index.php?category_name=$matches[1]&name=$matches[2]&paged=$matches[3]";s:41:"(.+?)/([^/]+)/comment-page-([0-9]{1,})/?$";s:70:"index.php?category_name=$matches[1]&name=$matches[2]&cpage=$matches[3]";s:30:"(.+?)/([^/]+)(?:/([0-9]+))?/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&page=$matches[3]";s:20:".+?/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:30:".+?/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:50:".+?/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:".+?/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:".+?/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:".+?/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:38:"(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:33:"(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:14:"(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:26:"(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:33:"(.+?)/comment-page-([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&cpage=$matches[2]";s:8:"(.+?)/?$";s:35:"index.php?category_name=$matches[1]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:8:{i:0;s:34:"advanced-custom-fields-pro/acf.php";i:1;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:2;s:41:"password-protected/password-protected.php";i:3;s:37:"post-types-order/post-types-order.php";i:4;s:37:"user-role-editor/user-role-editor.php";i:5;s:29:"wp-mail-smtp/wp_mail_smtp.php";i:6;s:31:"wp-migrate-db/wp-migrate-db.php";i:7;s:24:"wpforms-lite/wpforms.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '10', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'sockbrew-theme', 'yes'),
(41, 'stylesheet', 'sockbrew-theme', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '49752', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '0', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:1:{s:37:"user-role-editor/user-role-editor.php";a:2:{i:0;s:16:"User_Role_Editor";i:1;s:9:"uninstall";}}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '8', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '214', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1646907089', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '49752', 'yes'),
(100, 'wp_user_roles', 'a:6:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:78:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:14:"ure_edit_roles";b:1;s:16:"ure_create_roles";b:1;s:16:"ure_delete_roles";b:1;s:23:"ure_create_capabilities";b:1;s:23:"ure_delete_capabilities";b:1;s:18:"ure_manage_options";b:1;s:15:"ure_reset_roles";b:1;s:18:"edit_wpforms_forms";b:1;s:25:"edit_others_wpforms_forms";b:1;s:21:"publish_wpforms_forms";b:1;s:26:"read_private_wpforms_forms";b:1;s:20:"delete_wpforms_forms";b:1;s:12:"create_posts";b:1;s:17:"install_languages";b:1;s:14:"resume_plugins";b:1;s:13:"resume_themes";b:1;s:23:"view_site_health_checks";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:16:"ibqc_team_member";a:2:{s:4:"name";s:16:"IBQC Team Member";s:12:"capabilities";a:32:{s:12:"create_posts";b:1;s:19:"delete_others_pages";b:1;s:19:"delete_others_posts";b:1;s:12:"delete_pages";b:1;s:12:"delete_posts";b:1;s:20:"delete_private_posts";b:1;s:22:"delete_published_pages";b:1;s:22:"delete_published_posts";b:1;s:17:"edit_others_pages";b:1;s:17:"edit_others_posts";b:1;s:25:"edit_others_wpforms_forms";b:1;s:10:"edit_pages";b:1;s:10:"edit_posts";b:1;s:18:"edit_private_pages";b:1;s:18:"edit_private_posts";b:1;s:20:"edit_published_pages";b:1;s:20:"edit_published_posts";b:1;s:7:"level_0";b:1;s:7:"level_1";b:1;s:7:"level_2";b:1;s:7:"level_3";b:1;s:7:"level_4";b:1;s:7:"level_5";b:1;s:7:"level_6";b:1;s:7:"level_7";b:1;s:13:"publish_pages";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:18:"read_private_pages";b:1;s:18:"read_private_posts";b:1;s:15:"unfiltered_html";b:1;s:12:"upload_files";b:1;}}}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'fresh_site', '0', 'yes'),
(102, 'WPLANG', 'en_AU', 'yes'),
(103, 'widget_block', 'a:7:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:227:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:146:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}i:7;a:1:{s:7:"content";s:104:"<!-- wp:search {"label":"","placeholder":"Search Terms","buttonText":"Search","buttonUseIcon":true} /-->";}s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:20:"custom-header-widget";a:1:{i:0;s:7:"block-7";}s:13:"array_version";i:3;}', 'yes'),
(105, 'cron', 'a:8:{i:1638260333;a:1:{s:26:"action_scheduler_run_queue";a:1:{s:32:"0d04ed39571b55704c122d726248bbac";a:3:{s:8:"schedule";s:12:"every_minute";s:4:"args";a:1:{i:0;s:7:"WP Cron";}s:8:"interval";i:60;}}}i:1638263489;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1638267089;a:5:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1638267101;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1638267102;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1638699089;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1638763200;a:1:{s:28:"wpforms_email_summaries_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:30:"wpforms_email_summaries_weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes'),
(106, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'recovery_keys', 'a:0:{}', 'yes'),
(120, 'theme_mods_twentytwentyone', 'a:3:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1632708576;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}}}s:18:"nav_menu_locations";a:0:{}}', 'yes'),
(121, 'https_detection_errors', 'a:1:{s:19:"bad_response_source";a:1:{i:0;s:55:"It looks like the response did not come from this site.";}}', 'yes'),
(137, 'can_compress_scripts', '0', 'no'),
(154, 'finished_updating_comment_type', '1', 'yes'),
(159, 'recently_activated', 'a:0:{}', 'yes'),
(170, 'new_admin_email', 'u3113923@uni.canberra.edu.au', 'yes'),
(180, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1638260296;}', 'no'),
(265, 'password_protected_version', '2.5', 'yes'),
(266, 'password_protected_status', '1', 'yes'),
(267, 'password_protected_feeds', '0', 'yes'),
(268, 'password_protected_rest', '0', 'yes'),
(269, 'password_protected_administrators', '1', 'yes'),
(270, 'password_protected_users', '0', 'yes'),
(271, 'password_protected_password', '4ed98017fc24cc1605d806fd8328a134', 'yes'),
(272, 'password_protected_allowed_ip_addresses', '', 'yes'),
(273, 'password_protected_remember_me', '1', 'yes'),
(274, 'password_protected_remember_me_lifetime', '14', 'yes'),
(283, 'widget_recent-comments', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(284, 'widget_recent-posts', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(287, 'theme_mods_a-custom-theme-for-sockbrew-design', 'a:3:{s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:0:{}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1632102331;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}}}}', 'yes'),
(289, 'current_theme', 'Sockbrew Theme', 'yes'),
(290, 'theme_switched', '', 'yes'),
(292, 'theme_mods_sockbrew-theme', 'a:3:{s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:1:{s:6:"menu-1";i:10;}s:11:"custom_logo";i:76;}', 'yes'),
(438, 'acf_version', '5.10.2', 'yes'),
(450, 'cptui_new_install', 'false', 'yes'),
(578, 'cptui_taxonomies', 'a:1:{s:21:"publications_category";a:25:{s:4:"name";s:21:"publications_category";s:5:"label";s:22:"Publication Categories";s:14:"singular_label";s:20:"Publication Category";s:11:"description";s:0:"";s:6:"public";s:4:"true";s:18:"publicly_queryable";s:4:"true";s:12:"hierarchical";s:5:"false";s:7:"show_ui";s:4:"true";s:12:"show_in_menu";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:1:"1";s:20:"rewrite_hierarchical";s:1:"0";s:17:"show_admin_column";s:5:"false";s:12:"show_in_rest";s:4:"true";s:18:"show_in_quick_edit";s:0:"";s:9:"rest_base";s:0:"";s:21:"rest_controller_class";s:0:"";s:6:"labels";a:19:{s:9:"menu_name";s:0:"";s:9:"all_items";s:0:"";s:9:"edit_item";s:0:"";s:9:"view_item";s:0:"";s:11:"update_item";s:0:"";s:12:"add_new_item";s:0:"";s:13:"new_item_name";s:0:"";s:11:"parent_item";s:0:"";s:17:"parent_item_colon";s:0:"";s:12:"search_items";s:0:"";s:13:"popular_items";s:0:"";s:26:"separate_items_with_commas";s:0:"";s:19:"add_or_remove_items";s:0:"";s:21:"choose_from_most_used";s:0:"";s:9:"not_found";s:0:"";s:8:"no_terms";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";s:13:"back_to_items";s:0:"";}s:11:"meta_box_cb";s:0:"";s:12:"default_term";s:0:"";s:12:"object_types";a:1:{i:0;s:11:"publication";}}}', 'yes'),
(586, 'category_children', 'a:0:{}', 'yes'),
(587, 'cptui_post_types', 'a:4:{s:11:"publication";a:30:{s:4:"name";s:11:"publication";s:5:"label";s:12:"Publications";s:14:"singular_label";s:11:"Publication";s:11:"description";s:0:"";s:6:"public";s:4:"true";s:18:"publicly_queryable";s:4:"true";s:7:"show_ui";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:16:"delete_with_user";s:5:"false";s:12:"show_in_rest";s:4:"true";s:9:"rest_base";s:0:"";s:21:"rest_controller_class";s:0:"";s:11:"has_archive";s:5:"false";s:18:"has_archive_string";s:0:"";s:19:"exclude_from_search";s:5:"false";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:5:"false";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:4:"true";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:0:"";s:8:"supports";a:4:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:9:"thumbnail";i:3;s:13:"custom-fields";}s:10:"taxonomies";a:1:{i:0;s:21:"publications_category";}s:6:"labels";a:29:{s:9:"menu_name";s:0:"";s:9:"all_items";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:9:"view_item";s:0:"";s:10:"view_items";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:17:"parent_item_colon";s:0:"";s:14:"featured_image";s:0:"";s:18:"set_featured_image";s:0:"";s:21:"remove_featured_image";s:0:"";s:18:"use_featured_image";s:0:"";s:8:"archives";s:0:"";s:16:"insert_into_item";s:0:"";s:21:"uploaded_to_this_item";s:0:"";s:17:"filter_items_list";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";s:10:"attributes";s:0:"";s:14:"name_admin_bar";s:0:"";s:14:"item_published";s:0:"";s:24:"item_published_privately";s:0:"";s:22:"item_reverted_to_draft";s:0:"";s:14:"item_scheduled";s:0:"";s:12:"item_updated";s:0:"";}s:15:"custom_supports";s:0:"";}s:5:"forum";a:30:{s:4:"name";s:5:"forum";s:5:"label";s:6:"Forums";s:14:"singular_label";s:5:"Forum";s:11:"description";s:33:"Posts type to be used for forums.";s:6:"public";s:4:"true";s:18:"publicly_queryable";s:4:"true";s:7:"show_ui";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:16:"delete_with_user";s:5:"false";s:12:"show_in_rest";s:4:"true";s:9:"rest_base";s:0:"";s:21:"rest_controller_class";s:0:"";s:11:"has_archive";s:5:"false";s:18:"has_archive_string";s:0:"";s:19:"exclude_from_search";s:5:"false";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:5:"false";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:4:"true";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:0:"";s:8:"supports";a:3:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:9:"thumbnail";}s:10:"taxonomies";a:1:{i:0;s:8:"category";}s:6:"labels";a:29:{s:9:"menu_name";s:6:"Forums";s:9:"all_items";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:9:"view_item";s:0:"";s:10:"view_items";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:17:"parent_item_colon";s:0:"";s:14:"featured_image";s:0:"";s:18:"set_featured_image";s:0:"";s:21:"remove_featured_image";s:0:"";s:18:"use_featured_image";s:0:"";s:8:"archives";s:0:"";s:16:"insert_into_item";s:0:"";s:21:"uploaded_to_this_item";s:0:"";s:17:"filter_items_list";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";s:10:"attributes";s:0:"";s:14:"name_admin_bar";s:0:"";s:14:"item_published";s:0:"";s:24:"item_published_privately";s:0:"";s:22:"item_reverted_to_draft";s:0:"";s:14:"item_scheduled";s:0:"";s:12:"item_updated";s:0:"";}s:15:"custom_supports";s:0:"";}s:12:"board-member";a:30:{s:4:"name";s:12:"board-member";s:5:"label";s:13:"Board Members";s:14:"singular_label";s:12:"Board Member";s:11:"description";s:0:"";s:6:"public";s:4:"true";s:18:"publicly_queryable";s:4:"true";s:7:"show_ui";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:16:"delete_with_user";s:5:"false";s:12:"show_in_rest";s:4:"true";s:9:"rest_base";s:0:"";s:21:"rest_controller_class";s:0:"";s:11:"has_archive";s:5:"false";s:18:"has_archive_string";s:0:"";s:19:"exclude_from_search";s:5:"false";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:5:"false";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:4:"true";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:0:"";s:8:"supports";a:3:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:9:"thumbnail";}s:10:"taxonomies";a:0:{}s:6:"labels";a:29:{s:9:"menu_name";s:0:"";s:9:"all_items";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:9:"view_item";s:0:"";s:10:"view_items";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:17:"parent_item_colon";s:0:"";s:14:"featured_image";s:0:"";s:18:"set_featured_image";s:0:"";s:21:"remove_featured_image";s:0:"";s:18:"use_featured_image";s:0:"";s:8:"archives";s:0:"";s:16:"insert_into_item";s:0:"";s:21:"uploaded_to_this_item";s:0:"";s:17:"filter_items_list";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";s:10:"attributes";s:0:"";s:14:"name_admin_bar";s:0:"";s:14:"item_published";s:0:"";s:24:"item_published_privately";s:0:"";s:22:"item_reverted_to_draft";s:0:"";s:14:"item_scheduled";s:0:"";s:12:"item_updated";s:0:"";}s:15:"custom_supports";s:0:"";}s:9:"news-post";a:30:{s:4:"name";s:9:"news-post";s:5:"label";s:10:"News Posts";s:14:"singular_label";s:9:"News Post";s:11:"description";s:0:"";s:6:"public";s:4:"true";s:18:"publicly_queryable";s:4:"true";s:7:"show_ui";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:16:"delete_with_user";s:5:"false";s:12:"show_in_rest";s:4:"true";s:9:"rest_base";s:0:"";s:21:"rest_controller_class";s:0:"";s:11:"has_archive";s:5:"false";s:18:"has_archive_string";s:0:"";s:19:"exclude_from_search";s:5:"false";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:5:"false";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:4:"true";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:0:"";s:8:"supports";a:3:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:9:"thumbnail";}s:10:"taxonomies";a:0:{}s:6:"labels";a:29:{s:9:"menu_name";s:0:"";s:9:"all_items";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:9:"view_item";s:0:"";s:10:"view_items";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:17:"parent_item_colon";s:0:"";s:14:"featured_image";s:0:"";s:18:"set_featured_image";s:0:"";s:21:"remove_featured_image";s:0:"";s:18:"use_featured_image";s:0:"";s:8:"archives";s:0:"";s:16:"insert_into_item";s:0:"";s:21:"uploaded_to_this_item";s:0:"";s:17:"filter_items_list";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";s:10:"attributes";s:0:"";s:14:"name_admin_bar";s:0:"";s:14:"item_published";s:0:"";s:24:"item_published_privately";s:0:"";s:22:"item_reverted_to_draft";s:0:"";s:14:"item_scheduled";s:0:"";s:12:"item_updated";s:0:"";}s:15:"custom_supports";s:0:"";}}', 'yes'),
(627, 'action_scheduler_hybrid_store_demarkation', '73', 'yes'),
(628, 'schema-ActionScheduler_StoreSchema', '4.0.1633823933', 'yes'),
(629, 'schema-ActionScheduler_LoggerSchema', '2.0.1633823933', 'yes'),
(630, 'wpforms_version', '1.7.0', 'yes'),
(631, 'wpforms_version_lite', '1.7.0', 'yes'),
(632, 'wpforms_activated', 'a:1:{s:4:"lite";i:1633823933;}', 'yes'),
(637, 'action_scheduler_lock_async-request-runner', '1638260347', 'yes'),
(638, 'widget_wpforms-widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(642, 'wpforms_admin_notices', 'a:2:{s:14:"review_request";a:2:{s:4:"time";i:1633823934;s:9:"dismissed";b:0;}s:19:"review_lite_request";a:2:{s:4:"time";i:1638260287;s:9:"dismissed";b:1;}}', 'yes'),
(644, 'wpforms_builder_opened_date', '1633823949', 'no'),
(645, 'wpforms_forms_first_created', '1633823962', 'no'),
(647, 'action_scheduler_migration_status', 'complete', 'yes'),
(649, 'wpforms_email_summaries_fetch_info_blocks_last_run', '1638078059', 'yes'),
(655, 'wpforms_notifications', 'a:4:{s:6:"update";i:1638260214;s:4:"feed";a:3:{i:0;a:6:{s:5:"title";s:58:"Cyber Monday: Last chance to get up to 65% OFF WPForms PRO";s:7:"content";s:313:"This Cyber Monday, it’s your final chance to get up to 65% off WPForms PRO! As soon as you upgrade, you’ll unlock our conditional logic, entry management, our new Save and Resume addon, Rich Text field, conversational forms, payments with Stripe/Square/PayPal +more. Don’t miss our biggest sale of the year!";s:4:"type";a:1:{i:0;s:4:"lite";}s:2:"id";i:125;s:4:"btns";a:1:{s:4:"main";a:2:{s:3:"url";s:153:"https://wpforms.com/wpforms-lite-upgrade/?utm_source=WordPress&utm_campaign=liteplugin&utm_medium=Plugin Notification&utm_content=CM Lite Get WPForms Pro";s:4:"text";s:15:"Get WPForms PRO";}}s:5:"start";s:19:"2021-11-28 00:00:00";}i:1;a:6:{s:5:"title";s:41:"NEW! Save and Resume Addon in WPForms Pro";s:7:"content";s:261:"The NEW Save and Resume addon is available now in WPForms Pro! Let your visitors save progress and easily resume their entry later. Users can complete the entry themselves or share the link via email. Upgrade to WPForms Pro today to start using Save and Resume!";s:4:"type";a:1:{i:0;s:4:"lite";}s:2:"id";i:112;s:4:"btns";a:2:{s:4:"main";a:2:{s:3:"url";s:194:"https://wpforms.com/introducing-the-new-save-and-resume-addon-for-wpforms/?utm_source=WordPress&utm_campaign=liteplugin&utm_medium=Plugin Notification&utm_content=Save and Resume Lite Learn More";s:4:"text";s:10:"Learn More";}s:3:"alt";a:2:{s:3:"url";s:166:"https://wpforms.com/wpforms-lite-upgrade/?utm_source=WordPress&utm_campaign=liteplugin&utm_medium=Plugin Notification&utm_content=Save and Resume Lite Get WPForms Pro";s:4:"text";s:15:"Get WPForms Pro";}}s:5:"start";s:19:"2021-10-28 10:00:00";}i:2;a:6:{s:5:"title";s:52:"NEW! Rich Text Field + Uncanny Automator Integration";s:7:"content";s:351:"Our new Rich Text field is now live in WPForms Pro! Get fully formatted entries with bold, headings, images, links, and more. Rich text is perfect for blog post submissions and you can let visitors preview their layout before submitting. PLUS: our new Uncanny Automator integration makes it easy to use your forms to trigger your own custom workflows.";s:4:"type";a:1:{i:0;s:4:"lite";}s:2:"id";i:107;s:4:"btns";a:2:{s:4:"main";a:2:{s:3:"url";s:188:"https://wpforms.com/introducing-wpforms-1-7-0-rich-text-uncanny-automator/?utm_source=WordPress&utm_campaign=liteplugin&utm_medium=Plugin Notification&utm_content=Rich Text Lite Learn More";s:4:"text";s:10:"Learn More";}s:3:"alt";a:2:{s:3:"url";s:160:"https://wpforms.com/wpforms-lite-upgrade/?utm_source=WordPress&utm_campaign=liteplugin&utm_medium=Plugin Notification&utm_content=Rich Text Lite Get WPForms Pro";s:4:"text";s:15:"Get WPForms Pro";}}s:5:"start";s:19:"2021-10-11 00:00:00";}}s:6:"events";a:0:{}s:9:"dismissed";a:0:{}}', 'yes'),
(657, 'wpforms_crypto_secret_key', 'Uz1eLoHGxbO/NOk3SRnk+k0zqyz7HGqaOOlsjrrKm9s=', 'yes'),
(687, 'wp_mail_smtp_initial_version', '3.1.0', 'no'),
(688, 'wp_mail_smtp_version', '3.1.0', 'no'),
(689, 'wp_mail_smtp', 'a:9:{s:4:"mail";a:6:{s:10:"from_email";s:24:"sockbrewdesign@gmail.com";s:9:"from_name";s:43:"IBQC: International Building Quality Centre";s:6:"mailer";s:5:"gmail";s:11:"return_path";b:0;s:16:"from_email_force";b:1;s:15:"from_name_force";b:0;}s:4:"smtp";a:7:{s:7:"autotls";s:3:"yes";s:4:"auth";s:3:"yes";s:4:"host";s:0:"";s:10:"encryption";s:4:"none";s:4:"port";s:0:"";s:4:"user";s:0:"";s:4:"pass";s:0:"";}s:7:"general";a:1:{s:29:"summary_report_email_disabled";b:0;}s:5:"gmail";a:2:{s:9:"client_id";s:3:"abc";s:13:"client_secret";s:3:"123";}s:7:"smtpcom";a:2:{s:7:"api_key";s:0:"";s:7:"channel";s:0:"";}s:10:"sendinblue";a:2:{s:7:"api_key";s:0:"";s:6:"domain";s:0:"";}s:7:"mailgun";a:3:{s:7:"api_key";s:0:"";s:6:"domain";s:0:"";s:6:"region";s:2:"US";}s:8:"sendgrid";a:2:{s:7:"api_key";s:0:"";s:6:"domain";s:0:"";}s:8:"postmark";a:2:{s:16:"server_api_token";s:0:"";s:14:"message_stream";s:0:"";}}', 'no'),
(690, 'wp_mail_smtp_activated_time', '1633825563', 'no'),
(691, 'wp_mail_smtp_activated', 'a:1:{s:4:"lite";i:1633825563;}', 'yes'),
(694, 'wp_mail_smtp_migration_version', '4', 'yes'),
(695, 'wp_mail_smtp_debug_events_db_version', '1', 'yes'),
(696, 'wp_mail_smtp_activation_prevent_redirect', '1', 'yes'),
(697, 'wp_mail_smtp_setup_wizard_stats', 'a:3:{s:13:"launched_time";i:1633825565;s:14:"completed_time";i:0;s:14:"was_successful";b:0;}', 'no'),
(704, 'wp_mail_smtp_review_notice', 'a:2:{s:4:"time";i:1633826039;s:9:"dismissed";b:0;}', 'yes'),
(705, 'wp_mail_smtp_notifications', 'a:4:{s:6:"update";i:1638260214;s:4:"feed";a:1:{i:0;a:6:{s:5:"title";s:60:"Cyber Monday: Last chance to get up to $150 OFF WP Mail SMTP";s:7:"content";s:289:"Don’t miss your chance to get $150 off WP Mail SMTP Pro! It’s the perfect time to unlock all of our awesome NEW features and save $$$. Get full control of your emails with detailed email logging, open and click tracking, email reports + more. Don’t miss our biggest sale of the year!";s:4:"type";a:1:{i:0;s:4:"lite";}s:2:"id";i:19;s:4:"btns";a:1:{s:4:"main";a:2:{s:3:"url";s:158:"https://wpmailsmtp.com/wpmailsmtp-lite-upgrade/?utm_source=WordPress&utm_campaign=liteplugin&utm_medium=Plugin Notification&utm_content=CM Lite Upgrade to Pro";s:4:"text";s:14:"Upgrade to Pro";}}s:5:"start";s:19:"2021-11-28 00:00:00";}}s:6:"events";a:0:{}s:9:"dismissed";a:0:{}}', 'yes'),
(718, 'site_logo', '76', 'yes'),
(989, 'wp_mail_smtp_debug', 'a:0:{}', 'no'),
(990, 'wp_mail_smtp_lite_sent_email_counter', '22', 'yes'),
(991, 'wp_mail_smtp_lite_weekly_sent_email_counter', 'a:8:{i:41;i:7;i:42;i:2;i:43;i:2;i:44;i:2;i:45;i:3;i:46;i:2;i:47;i:2;i:48;i:2;}', 'yes'),
(1594, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(1678, 'cpto_options', 'a:7:{s:23:"show_reorder_interfaces";a:6:{s:4:"post";s:4:"hide";s:10:"attachment";s:4:"hide";s:8:"wp_block";s:4:"hide";s:11:"publication";s:4:"hide";s:5:"forum";s:4:"hide";s:12:"board-member";s:4:"show";}s:8:"autosort";s:0:"";s:9:"adminsort";i:1;s:18:"use_query_ASC_DESC";s:0:"";s:17:"archive_drag_drop";i:1;s:10:"capability";s:13:"publish_posts";s:21:"navigation_sort_apply";s:0:"";}', 'yes'),
(1679, 'CPT_configured', 'TRUE', 'yes'),
(1807, 'user_role_editor', 'a:1:{s:11:"ure_version";s:6:"4.60.2";}', 'yes'),
(1808, 'wp_backup_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'no'),
(1809, 'ure_tasks_queue', 'a:0:{}', 'yes'),
(1816, 'ure_role_additional_options_values', 'a:1:{s:16:"ibqc_team_member";a:0:{}}', 'yes'),
(4882, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:28:"u3113923@uni.canberra.edu.au";s:7:"version";s:5:"5.8.2";s:9:"timestamp";i:1636583473;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=1401 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2, 3, '_wp_page_template', 'default'),
(4, 8, '_edit_lock', '1634865181:3'),
(5, 9, '_wp_attached_file', '2021/09/podcast.png'),
(6, 9, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:623;s:6:"height";i:324;s:4:"file";s:19:"2021/09/podcast.png";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:19:"podcast-300x156.png";s:5:"width";i:300;s:6:"height";i:156;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:19:"podcast-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(7, 11, '_edit_lock', '1634866574:3'),
(8, 12, '_wp_attached_file', '2021/09/construction-silhouette.jpg'),
(9, 12, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1374;s:6:"height";i:918;s:4:"file";s:35:"2021/09/construction-silhouette.jpg";s:5:"sizes";a:4:{s:6:"medium";a:4:{s:4:"file";s:35:"construction-silhouette-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:36:"construction-silhouette-1024x684.jpg";s:5:"width";i:1024;s:6:"height";i:684;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:35:"construction-silhouette-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:35:"construction-silhouette-768x513.jpg";s:5:"width";i:768;s:6:"height";i:513;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:3:"5.6";s:6:"credit";s:0:"";s:6:"camera";s:20:"Canon EOS 5D Mark II";s:7:"caption";s:23:"construction silhouette";s:17:"created_timestamp";s:10:"1342870292";s:9:"copyright";s:0:"";s:12:"focal_length";s:3:"300";s:3:"iso";s:3:"200";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:23:"construction silhouette";s:11:"orientation";s:1:"1";s:8:"keywords";a:28:{i:0;s:6:"manual";i:1;s:7:"housing";i:2;s:10:"profession";i:3;s:5:"built";i:4;s:11:"scaffolding";i:5;s:6:"helmet";i:6;s:10:"occupation";i:7;s:6:"people";i:8;s:3:"sun";i:9;s:6:"worker";i:10;s:11:"development";i:11;s:8:"concrete";i:12;s:8:"laborers";i:13;s:3:"men";i:14;s:5:"group";i:15;s:7:"hardhat";i:16;s:6:"sunset";i:17;s:4:"dawn";i:18;s:7:"working";i:19;s:5:"crane";i:20;s:8:"industry";i:21;s:10:"silhouette";i:22;s:4:"site";i:23;s:12:"construction";i:24;s:9:"structure";i:25;s:19:"construction worker";i:26;s:17:"construction site";i:27;s:10:"form works";}}}'),
(10, 13, '_wp_attached_file', '2021/09/construction-worker-truss-installation.jpg'),
(11, 13, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2268;s:6:"height";i:1514;s:4:"file";s:50:"2021/09/construction-worker-truss-installation.jpg";s:5:"sizes";a:7:{s:6:"medium";a:4:{s:4:"file";s:50:"construction-worker-truss-installation-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:51:"construction-worker-truss-installation-1024x684.jpg";s:5:"width";i:1024;s:6:"height";i:684;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:50:"construction-worker-truss-installation-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:50:"construction-worker-truss-installation-768x513.jpg";s:5:"width";i:768;s:6:"height";i:513;s:9:"mime-type";s:10:"image/jpeg";}s:9:"1536x1536";a:4:{s:4:"file";s:52:"construction-worker-truss-installation-1536x1025.jpg";s:5:"width";i:1536;s:6:"height";i:1025;s:9:"mime-type";s:10:"image/jpeg";}s:9:"2048x2048";a:4:{s:4:"file";s:52:"construction-worker-truss-installation-2048x1367.jpg";s:5:"width";i:2048;s:6:"height";i:1367;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:52:"construction-worker-truss-installation-1568x1047.jpg";s:5:"width";i:1568;s:6:"height";i:1047;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:38:"Construction worker truss installation";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:38:"Construction worker truss installation";s:11:"orientation";s:1:"1";s:8:"keywords";a:50:{i:0;s:8:"industry";i:1;s:10:"industrial";i:2;s:7:"foreman";i:3;s:10:"inspection";i:4;s:5:"truss";i:5;s:5:"civil";i:6;s:5:"tower";i:7;s:5:"crane";i:8;s:7:"harness";i:9;s:29:"personal protective equipment";i:10;s:7:"uniform";i:11;s:6:"safety";i:12;s:12:"construction";i:13;s:5:"steel";i:14;s:7:"workers";i:15;s:9:"structure";i:16;s:4:"site";i:17;s:6:"worker";i:18;s:8:"building";i:19;s:12:"architecture";i:20;s:9:"materials";i:21;s:3:"sky";i:22;s:11:"engineering";i:23;s:4:"work";i:24;s:8:"engineer";i:25;s:7:"support";i:26;s:6:"design";i:27;s:10:"background";i:28;s:10:"commercial";i:29;s:11:"development";i:30;s:5:"metal";i:31;s:8:"metallic";i:32;s:6:"estate";i:33;s:4:"roof";i:34;s:4:"beam";i:35;s:10:"structural";i:36;s:11:"scaffolding";i:37;s:9:"equipment";i:38;s:10:"connection";i:39;s:8:"business";i:40;s:10:"technology";i:41;s:5:"power";i:42;s:6:"energy";i:43;s:9:"machinery";i:44;s:8:"refinery";i:45;s:8:"chemical";i:46;s:8:"material";i:47;s:5:"heavy";i:48;s:7:"factory";i:49;s:7:"machine";}}}'),
(12, 16, '_edit_lock', '1634348241:3'),
(13, 17, '_wp_attached_file', '2021/09/view-modern-business-skyscrapers-glass-sky-view-landscape-commercial-building.jpg'),
(14, 17, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1642;s:6:"height";i:1095;s:4:"file";s:89:"2021/09/view-modern-business-skyscrapers-glass-sky-view-landscape-commercial-building.jpg";s:5:"sizes";a:6:{s:6:"medium";a:4:{s:4:"file";s:89:"view-modern-business-skyscrapers-glass-sky-view-landscape-commercial-building-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:90:"view-modern-business-skyscrapers-glass-sky-view-landscape-commercial-building-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:89:"view-modern-business-skyscrapers-glass-sky-view-landscape-commercial-building-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:89:"view-modern-business-skyscrapers-glass-sky-view-landscape-commercial-building-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:9:"1536x1536";a:4:{s:4:"file";s:91:"view-modern-business-skyscrapers-glass-sky-view-landscape-commercial-building-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:91:"view-modern-business-skyscrapers-glass-sky-view-landscape-commercial-building-1568x1046.jpg";s:5:"width";i:1568;s:6:"height";i:1046;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:2:"10";s:6:"credit";s:0:"";s:6:"camera";s:12:"Canon EOS 6D";s:7:"caption";s:103:"View of modern business skyscrapers glass and sky view landscape of commercial building in central city";s:17:"created_timestamp";s:10:"1541329359";s:9:"copyright";s:0:"";s:12:"focal_length";s:2:"25";s:3:"iso";s:3:"100";s:13:"shutter_speed";s:5:"0.008";s:5:"title";s:64:"View of modern business skyscrapers glass and sky view landscape";s:11:"orientation";s:1:"1";s:8:"keywords";a:50:{i:0;s:8:"abstract";i:1;s:5:"angle";i:2;s:12:"architecture";i:3;s:4:"asia";i:4;s:10:"background";i:5;s:4:"bank";i:6;s:9:"beautiful";i:7;s:4:"blue";i:8;s:6:"bottom";i:9;s:8:"building";i:10;s:8:"business";i:11;s:6:"center";i:12;s:7:"central";i:13;s:4:"city";i:14;s:9:"cityscape";i:15;s:6:"clouds";i:16;s:10:"commercial";i:17;s:7:"company";i:18;s:9:"corporate";i:19;s:3:"day";i:20;s:6:"design";i:21;s:8:"district";i:22;s:8:"downtown";i:23;s:6:"energy";i:24;s:7:"finance";i:25;s:9:"financial";i:26;s:6:"future";i:27;s:10:"futuristic";i:28;s:5:"glass";i:29;s:6:"global";i:30;s:4:"high";i:31;s:3:"job";i:32;s:9:"landscape";i:33;s:4:"life";i:34;s:3:"low";i:35;s:6:"modern";i:36;s:3:"new";i:37;s:6:"office";i:38;s:9:"singapore";i:39;s:3:"sky";i:40;s:10:"skyscraper";i:41;s:6:"street";i:42;s:7:"success";i:43;s:3:"sun";i:44;s:4:"tall";i:45;s:5:"tower";i:46;s:2:"up";i:47;s:5:"urban";i:48;s:4:"view";i:49;s:6:"window";}}}'),
(16, 21, '_wp_attached_file', '2021/09/leadership.png'),
(17, 21, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:768;s:6:"height";i:576;s:4:"file";s:22:"2021/09/leadership.png";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:22:"leadership-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:22:"leadership-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(22, 27, '_edit_lock', '1633883090:3'),
(30, 41, '_edit_lock', '1634255046:3'),
(31, 41, '_edit_last', '3'),
(32, 41, 'authors', 'IBQC Board Members'),
(33, 41, '_authors', 'field_61552362ff0dc'),
(34, 41, 'published_year', ''),
(35, 41, '_published_year', 'field_61552660d324f'),
(36, 41, 'citation_details', ''),
(37, 41, '_citation_details', 'field_615526c1d3250'),
(38, 41, 'abstract', 'Low-income countries or emerging economies face different building control challenges to high-income economies. Economic capacity restraints often limit their ability to adopt regulations characteristic of high income countries.'),
(39, 41, '_abstract', 'field_615526f3d3251'),
(40, 41, 'link_to_publication', 'http://www.ibqc.org.au/wp-content/uploads/2021/05/IBQC-Good-Practice-Guidelines-for-Low-Income-Countries-2021.pdf'),
(41, 41, '_link_to_publication', 'field_6155291a7f3ad'),
(42, 41, 'category', 'a:1:{i:0;s:1:"6";}'),
(43, 41, '_category', 'field_615529807f3ae'),
(44, 42, '_edit_lock', '1634282932:1'),
(45, 42, '_edit_last', '1'),
(46, 42, 'authors', 'IBQC Staff'),
(47, 42, '_authors', 'field_61552362ff0dc'),
(48, 42, 'published_year', '20201010'),
(49, 42, '_published_year', 'field_61552660d324f'),
(50, 42, 'citation_details', ''),
(51, 42, '_citation_details', 'field_615526c1d3250'),
(52, 42, 'abstract', 'To be successful, good practice building regulatory systems highlighted by the IBQC, must not only assure public safety, but must also support two other goals: regulatory efficiency and innovation. Regulatory regimes\r\nthat are not efficient will encourage industry practitioners with limited budgets and timeframes, to circumvent these systems. New and innovative building technologies can sometimes provide better safety, performance and lower costs. Regulatory systems that do not accommodate legitimate building innovations become irrelevant. Therefore, good practice regulatory systems must not only provide a very high level of public safety but must also be efficient and facilitate high quality design, system and material innovations fully compliant with safety standards. Good practice building regulatory regimes, therefore, must be a win-win-win proposition relative to safety, efficiency and innovation.'),
(53, 42, '_abstract', 'field_615526f3d3251'),
(54, 42, 'link_to_publication', 'http://www.ibqc.org.au/wp-content/uploads/2020/09/IBQC-Principles-for-Good-Practice-Building-Regulation.pdf'),
(55, 42, '_link_to_publication', 'field_6155291a7f3ad'),
(56, 42, 'category', 'a:1:{i:0;s:1:"8";}'),
(57, 42, '_category', 'field_615529807f3ae'),
(58, 43, '_edit_lock', '1634282912:1'),
(59, 43, '_edit_last', '1'),
(60, 43, 'authors', 'Lovegrove and Cotton'),
(61, 43, '_authors', 'field_61552362ff0dc'),
(62, 43, 'published_year', '20201030'),
(63, 43, '_published_year', 'field_61552660d324f'),
(64, 43, 'citation_details', ''),
(65, 43, '_citation_details', 'field_615526c1d3250'),
(66, 43, 'abstract', 'Proponents of good practice building regulation are increasingly extolling the virtues of building regulatory systems that adopt risk-based building classifications and calibrate the risk profile of buildings with mandatory inspection regimes.'),
(67, 43, '_abstract', 'field_615526f3d3251'),
(68, 43, 'link_to_publication', 'http://lclawyers.com.au/virtues-risk-based-building-classifications-mandatory-inspections/'),
(69, 43, '_link_to_publication', 'field_6155291a7f3ad'),
(70, 43, 'category', 'a:2:{i:0;s:1:"6";i:1;s:1:"7";}'),
(71, 43, '_category', 'field_615529807f3ae'),
(72, 45, '_edit_lock', '1632986723:1'),
(73, 45, '_wp_page_template', 'publications.php'),
(97, 43, 'publication_image', '204'),
(98, 43, '_publication_image', 'field_6160d5f290f30'),
(99, 42, 'publication_image', '141'),
(100, 42, '_publication_image', 'field_6160d5f290f30'),
(101, 41, 'publication_image', '143'),
(102, 41, '_publication_image', 'field_6160d5f290f30'),
(103, 69, '_edit_lock', '1634366650:1'),
(104, 69, '_wp_page_template', 'forums.php'),
(135, 73, 'wpforms_entries_count', '6'),
(136, 76, '_wp_attached_file', '2021/10/LOGO-2-1.png'),
(137, 76, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:109;s:6:"height";i:138;s:4:"file";s:20:"2021/10/LOGO-2-1.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(140, 52, '_edit_lock', '1634348730:1'),
(141, 61, '_edit_lock', '1634348847:1'),
(153, 83, '_wp_attached_file', '2021/10/hero.png'),
(154, 83, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1441;s:6:"height";i:596;s:4:"file";s:16:"2021/10/hero.png";s:5:"sizes";a:4:{s:6:"medium";a:4:{s:4:"file";s:16:"hero-300x124.png";s:5:"width";i:300;s:6:"height";i:124;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:17:"hero-1024x424.png";s:5:"width";i:1024;s:6:"height";i:424;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:16:"hero-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:16:"hero-768x318.png";s:5:"width";i:768;s:6:"height";i:318;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(155, 89, '_wp_attached_file', '2021/10/podcast.png'),
(156, 89, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:623;s:6:"height";i:324;s:4:"file";s:19:"2021/10/podcast.png";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:19:"podcast-300x156.png";s:5:"width";i:300;s:6:"height";i:156;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:19:"podcast-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(157, 92, '_wp_attached_file', '2021/10/view-modern-business-skyscrapers-glass-sky-view-landscape-commercial-building-1024x683-1.jpg'),
(158, 92, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1024;s:6:"height";i:683;s:4:"file";s:100:"2021/10/view-modern-business-skyscrapers-glass-sky-view-landscape-commercial-building-1024x683-1.jpg";s:5:"sizes";a:3:{s:6:"medium";a:4:{s:4:"file";s:100:"view-modern-business-skyscrapers-glass-sky-view-landscape-commercial-building-1024x683-1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:100:"view-modern-business-skyscrapers-glass-sky-view-landscape-commercial-building-1024x683-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:100:"view-modern-business-skyscrapers-glass-sky-view-landscape-commercial-building-1024x683-1-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(159, 99, '_wp_attached_file', '2021/10/construction-silhouette-1024x684-1.jpg'),
(160, 99, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1024;s:6:"height";i:684;s:4:"file";s:46:"2021/10/construction-silhouette-1024x684-1.jpg";s:5:"sizes";a:3:{s:6:"medium";a:4:{s:4:"file";s:46:"construction-silhouette-1024x684-1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:46:"construction-silhouette-1024x684-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:46:"construction-silhouette-1024x684-1-768x513.jpg";s:5:"width";i:768;s:6:"height";i:513;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(161, 100, '_wp_attached_file', '2021/10/construction-worker-truss-installation-1024x684-1.jpg'),
(162, 100, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1024;s:6:"height";i:684;s:4:"file";s:61:"2021/10/construction-worker-truss-installation-1024x684-1.jpg";s:5:"sizes";a:3:{s:6:"medium";a:4:{s:4:"file";s:61:"construction-worker-truss-installation-1024x684-1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:61:"construction-worker-truss-installation-1024x684-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:61:"construction-worker-truss-installation-1024x684-1-768x513.jpg";s:5:"width";i:768;s:6:"height";i:513;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(163, 8, '_wp_page_template', 'home.php'),
(164, 11, '_wp_page_template', 'about.php'),
(168, 104, '_edit_lock', '1634348649:1'),
(169, 118, '_edit_lock', '1634351724:1'),
(170, 119, '_wp_attached_file', '2021/10/Charles-Lemckert-Profile-Pic.jpg'),
(171, 119, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:800;s:6:"height";i:800;s:4:"file";s:40:"2021/10/Charles-Lemckert-Profile-Pic.jpg";s:5:"sizes";a:3:{s:6:"medium";a:4:{s:4:"file";s:40:"Charles-Lemckert-Profile-Pic-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:40:"Charles-Lemckert-Profile-Pic-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:40:"Charles-Lemckert-Profile-Pic-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(172, 118, '_edit_last', '3'),
(173, 118, 'board_member_title', 'Inaugural Board Chair'),
(174, 118, '_board_member_title', 'field_61677496eb69b'),
(175, 118, 'secondary_title', ' Professor of Building and Construction Management; Head of School of Design and the Built Environment, Faculty of Arts and Design, University of Canberra, Australia | Fellow of Institute of Engineers Australia (FIEAust)'),
(176, 118, '_secondary_title', 'field_61677442eb69a'),
(177, 118, 'bio', 'Charles Lemckert is a Fellow of the Institute of Engineers Australia in the College of Civil Engineering and a member of the Australian Institution of Building. He has over 25 years of experience in teaching undergraduate and postgraduate students. He has developed a number of innovative teaching strategies and was the project leader in developing an innovative real-time Internet mediated laboratory experimental program, which now forms an integral part of many educational programs.'),
(178, 118, '_bio', 'field_61677623eb6a1'),
(179, 118, 'board_member_image', '119'),
(180, 118, '_board_member_image', 'field_61677737eb6a6'),
(181, 118, 'professional_affiliations_0_role', 'Professional Affiliation'),
(182, 118, '_professional_affiliations_0_role', 'field_61677510eb69d'),
(183, 118, 'professional_affiliations_0_professional_body', 'Asia Oceania Geosciences Society') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(184, 118, '_professional_affiliations_0_professional_body', 'field_6167753aeb69e'),
(185, 118, 'professional_affiliations_0_pro_start_year', ''),
(186, 118, '_professional_affiliations_0_pro_start_year', 'field_6167754beb69f'),
(187, 118, 'professional_affiliations_1_role', 'Elected Committee Member'),
(188, 118, '_professional_affiliations_1_role', 'field_61677510eb69d'),
(189, 118, 'professional_affiliations_1_professional_body', 'Australian Association for Engineering Education'),
(190, 118, '_professional_affiliations_1_professional_body', 'field_6167753aeb69e'),
(191, 118, 'professional_affiliations_1_pro_start_year', '20131011'),
(192, 118, '_professional_affiliations_1_pro_start_year', 'field_6167754beb69f'),
(193, 118, 'professional_affiliations_1_pro_end_year', ''),
(194, 118, '_professional_affiliations_1_pro_end_year', 'field_616775bceb6a0'),
(195, 118, 'professional_affiliations_2_role', 'Elected Committee Member'),
(196, 118, '_professional_affiliations_2_role', 'field_61677510eb69d'),
(197, 118, 'professional_affiliations_2_professional_body', 'Water Education Network'),
(198, 118, '_professional_affiliations_2_professional_body', 'field_6167753aeb69e'),
(199, 118, 'professional_affiliations_2_pro_start_year', '20101009'),
(200, 118, '_professional_affiliations_2_pro_start_year', 'field_6167754beb69f'),
(201, 118, 'professional_affiliations_2_pro_end_year', '20171011'),
(202, 118, '_professional_affiliations_2_pro_end_year', 'field_616775bceb6a0'),
(203, 118, 'professional_affiliations', '3'),
(204, 118, '_professional_affiliations', 'field_61677500eb69c'),
(205, 118, 'awards_0_award_title', 'Invited Adjunct Professor Appointment'),
(206, 118, '_awards_0_award_title', 'field_61677660eb6a3'),
(207, 118, 'awards_0_award_issuer', 'Griffith University'),
(208, 118, '_awards_0_award_issuer', 'field_61677669eb6a4'),
(209, 118, 'awards_0_award_year', '20211002'),
(210, 118, '_awards_0_award_year', 'field_616776e2eb6a5'),
(211, 118, 'awards', '1'),
(212, 118, '_awards', 'field_61677654eb6a2'),
(224, 122, '_edit_lock', '1634366639:1'),
(225, 122, '_wp_page_template', 'board-members.php'),
(226, 124, '_menu_item_type', 'post_type'),
(227, 124, '_menu_item_menu_item_parent', '0'),
(228, 124, '_menu_item_object_id', '8'),
(229, 124, '_menu_item_object', 'page'),
(230, 124, '_menu_item_target', ''),
(231, 124, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(232, 124, '_menu_item_xfn', ''),
(233, 124, '_menu_item_url', ''),
(234, 124, '_menu_item_orphaned', '1634197848'),
(235, 125, '_menu_item_type', 'post_type'),
(236, 125, '_menu_item_menu_item_parent', '0'),
(237, 125, '_menu_item_object_id', '11'),
(238, 125, '_menu_item_object', 'page'),
(239, 125, '_menu_item_target', ''),
(240, 125, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(241, 125, '_menu_item_xfn', ''),
(242, 125, '_menu_item_url', ''),
(243, 125, '_menu_item_orphaned', '1634197848'),
(244, 126, '_menu_item_type', 'post_type'),
(245, 126, '_menu_item_menu_item_parent', '0'),
(246, 126, '_menu_item_object_id', '27'),
(247, 126, '_menu_item_object', 'page'),
(248, 126, '_menu_item_target', ''),
(249, 126, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(250, 126, '_menu_item_xfn', ''),
(251, 126, '_menu_item_url', ''),
(252, 126, '_menu_item_orphaned', '1634197848'),
(253, 127, '_menu_item_type', 'post_type'),
(254, 127, '_menu_item_menu_item_parent', '0'),
(255, 127, '_menu_item_object_id', '69'),
(256, 127, '_menu_item_object', 'page'),
(257, 127, '_menu_item_target', ''),
(258, 127, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(259, 127, '_menu_item_xfn', ''),
(260, 127, '_menu_item_url', ''),
(261, 127, '_menu_item_orphaned', '1634197848'),
(262, 128, '_menu_item_type', 'post_type'),
(263, 128, '_menu_item_menu_item_parent', '0'),
(264, 128, '_menu_item_object_id', '122'),
(265, 128, '_menu_item_object', 'page'),
(266, 128, '_menu_item_target', ''),
(267, 128, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(268, 128, '_menu_item_xfn', ''),
(269, 128, '_menu_item_url', ''),
(270, 128, '_menu_item_orphaned', '1634197848'),
(271, 129, '_menu_item_type', 'post_type'),
(272, 129, '_menu_item_menu_item_parent', '0'),
(273, 129, '_menu_item_object_id', '45'),
(274, 129, '_menu_item_object', 'page'),
(275, 129, '_menu_item_target', ''),
(276, 129, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(277, 129, '_menu_item_xfn', ''),
(278, 129, '_menu_item_url', ''),
(279, 129, '_menu_item_orphaned', '1634197848'),
(280, 130, '_menu_item_type', 'post_type'),
(281, 130, '_menu_item_menu_item_parent', '0'),
(282, 130, '_menu_item_object_id', '16'),
(283, 130, '_menu_item_object', 'page'),
(284, 130, '_menu_item_target', ''),
(285, 130, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(286, 130, '_menu_item_xfn', ''),
(287, 130, '_menu_item_url', ''),
(288, 130, '_menu_item_orphaned', '1634197848'),
(289, 131, '_menu_item_type', 'post_type'),
(290, 131, '_menu_item_menu_item_parent', '0'),
(291, 131, '_menu_item_object_id', '8'),
(292, 131, '_menu_item_object', 'page'),
(293, 131, '_menu_item_target', ''),
(294, 131, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(295, 131, '_menu_item_xfn', ''),
(296, 131, '_menu_item_url', ''),
(297, 131, '_menu_item_orphaned', '1634197888'),
(298, 132, '_menu_item_type', 'post_type'),
(299, 132, '_menu_item_menu_item_parent', '0'),
(300, 132, '_menu_item_object_id', '11'),
(301, 132, '_menu_item_object', 'page'),
(302, 132, '_menu_item_target', ''),
(303, 132, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(304, 132, '_menu_item_xfn', ''),
(305, 132, '_menu_item_url', ''),
(306, 132, '_menu_item_orphaned', '1634197888'),
(307, 133, '_menu_item_type', 'post_type'),
(308, 133, '_menu_item_menu_item_parent', '0'),
(309, 133, '_menu_item_object_id', '27'),
(310, 133, '_menu_item_object', 'page'),
(311, 133, '_menu_item_target', ''),
(312, 133, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(313, 133, '_menu_item_xfn', ''),
(314, 133, '_menu_item_url', ''),
(315, 133, '_menu_item_orphaned', '1634197888'),
(316, 134, '_menu_item_type', 'post_type'),
(317, 134, '_menu_item_menu_item_parent', '0'),
(318, 134, '_menu_item_object_id', '69'),
(319, 134, '_menu_item_object', 'page'),
(320, 134, '_menu_item_target', ''),
(321, 134, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(322, 134, '_menu_item_xfn', ''),
(323, 134, '_menu_item_url', ''),
(324, 134, '_menu_item_orphaned', '1634197888'),
(325, 135, '_menu_item_type', 'post_type'),
(326, 135, '_menu_item_menu_item_parent', '0'),
(327, 135, '_menu_item_object_id', '122'),
(328, 135, '_menu_item_object', 'page'),
(329, 135, '_menu_item_target', ''),
(330, 135, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(331, 135, '_menu_item_xfn', ''),
(332, 135, '_menu_item_url', ''),
(333, 135, '_menu_item_orphaned', '1634197888'),
(334, 136, '_menu_item_type', 'post_type'),
(335, 136, '_menu_item_menu_item_parent', '0'),
(336, 136, '_menu_item_object_id', '45'),
(337, 136, '_menu_item_object', 'page'),
(338, 136, '_menu_item_target', ''),
(339, 136, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(340, 136, '_menu_item_xfn', ''),
(341, 136, '_menu_item_url', ''),
(342, 136, '_menu_item_orphaned', '1634197888'),
(343, 137, '_menu_item_type', 'post_type'),
(344, 137, '_menu_item_menu_item_parent', '0'),
(345, 137, '_menu_item_object_id', '16'),
(346, 137, '_menu_item_object', 'page'),
(347, 137, '_menu_item_target', ''),
(348, 137, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(349, 137, '_menu_item_xfn', ''),
(350, 137, '_menu_item_url', ''),
(351, 137, '_menu_item_orphaned', '1634197888'),
(352, 141, '_wp_attached_file', '2021/09/buildingregulation.png'),
(353, 141, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:817;s:6:"height";i:1055;s:4:"file";s:30:"2021/09/buildingregulation.png";s:5:"sizes";a:4:{s:6:"medium";a:4:{s:4:"file";s:30:"buildingregulation-232x300.png";s:5:"width";i:232;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:31:"buildingregulation-793x1024.png";s:5:"width";i:793;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:30:"buildingregulation-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:30:"buildingregulation-768x992.png";s:5:"width";i:768;s:6:"height";i:992;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(354, 143, '_wp_attached_file', '2021/09/lowincome.png'),
(355, 143, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:814;s:6:"height";i:1054;s:4:"file";s:21:"2021/09/lowincome.png";s:5:"sizes";a:4:{s:6:"medium";a:4:{s:4:"file";s:21:"lowincome-232x300.png";s:5:"width";i:232;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:22:"lowincome-791x1024.png";s:5:"width";i:791;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:21:"lowincome-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:21:"lowincome-768x994.png";s:5:"width";i:768;s:6:"height";i:994;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(356, 144, '_edit_lock', '1634282699:1'),
(357, 145, '_wp_attached_file', '2021/10/enforcement.png'),
(358, 145, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:787;s:6:"height";i:1018;s:4:"file";s:23:"2021/10/enforcement.png";s:5:"sizes";a:3:{s:6:"medium";a:4:{s:4:"file";s:23:"enforcement-232x300.png";s:5:"width";i:232;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:23:"enforcement-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:23:"enforcement-768x993.png";s:5:"width";i:768;s:6:"height";i:993;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(359, 144, '_edit_last', '1'),
(360, 144, 'authors', 'Thomas Moullier, Andrei Mikhnev, Alejandro Espinosa-Wang and Michael de Lint, World Bank'),
(361, 144, '_authors', 'field_61552362ff0dc'),
(362, 144, 'published_year', '20131012'),
(363, 144, '_published_year', 'field_61552660d324f'),
(364, 144, 'citation_details', ''),
(365, 144, '_citation_details', 'field_615526c1d3250'),
(366, 144, 'abstract', 'Building occupants, home owners, and end users of public buildings typically represent a vast population that can potentially suffer from a significant information asymmetry with regard to the buildings they occupy. Asymmetry occurs when one party has both significantly more knowledge than the other and a position of advantage; familiar examples include the information advantage of a seller of used machinery over a buyer or of a mortgage company over an individual client. In construction, the degree of asymmetry is so high and so potentially harmful to the public that the only alternative is for governments to establish a good-practice regulatory framework with very robust and efficient compliance mechanisms.'),
(367, 144, '_abstract', 'field_615526f3d3251'),
(368, 144, 'link_to_publication', 'https://www.doingbusiness.org/content/dam/doingBusiness/media-api/topicsconfig-assets/docs/Construction-Regulation-Reforms-Guidelines-for-Reformers.pdf'),
(369, 144, '_link_to_publication', 'field_6155291a7f3ad'),
(370, 144, 'category', 'a:2:{i:0;s:1:"6";i:1;s:1:"8";}'),
(371, 144, '_category', 'field_615529807f3ae'),
(372, 144, 'publication_image', '145'),
(373, 144, '_publication_image', 'field_6160d5f290f30'),
(374, 146, '_edit_lock', '1634282670:1'),
(375, 147, '_wp_attached_file', '2021/10/mechanism.png'),
(376, 147, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:739;s:6:"height";i:974;s:4:"file";s:21:"2021/10/mechanism.png";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:21:"mechanism-228x300.png";s:5:"width";i:228;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:21:"mechanism-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(377, 146, '_edit_last', '3'),
(378, 146, 'authors', 'Marie Lily Delion, Anushavan Hambardzumyan, Joyce Antone, Ibrahim and Ana Maria Santillana Farakos, Doing Business, World Bank'),
(379, 146, '_authors', 'field_61552362ff0dc'),
(380, 146, 'published_year', ''),
(381, 146, '_published_year', 'field_61552660d324f'),
(382, 146, 'citation_details', ''),
(383, 146, '_citation_details', 'field_615526c1d3250'),
(384, 146, 'abstract', 'Construction regulations can help protect the public from faulty building practices.  But to do so they need to be clear as well as thorough. Where regulations lack clarity, there is a risk of confusion among both builders and authorities, which can lead to unnecessary delays, disputes and uncertainty. And if regulatory procedures are too complicated or costly, builders tend to proceed without a permit. By some estimates 60–80% of building projects in developing economies are undertaken without the proper permits and approvals.'),
(385, 146, '_abstract', 'field_615526f3d3251'),
(386, 146, 'link_to_publication', 'https://www.doingbusiness.org/content/dam/doingBusiness/media/Annual-Reports/English/DB16-Chapters/DB16-CS-DwCP.pdf'),
(387, 146, '_link_to_publication', 'field_6155291a7f3ad'),
(388, 146, 'category', 'a:1:{i:0;s:1:"9";}'),
(389, 146, '_category', 'field_615529807f3ae'),
(390, 146, 'publication_image', '147'),
(391, 146, '_publication_image', 'field_6160d5f290f30'),
(395, 148, '_edit_lock', '1634282669:1'),
(396, 149, '_wp_attached_file', '2021/10/constructionpermit.png'),
(397, 149, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:789;s:6:"height";i:1035;s:4:"file";s:30:"2021/10/constructionpermit.png";s:5:"sizes";a:4:{s:6:"medium";a:4:{s:4:"file";s:30:"constructionpermit-229x300.png";s:5:"width";i:229;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:31:"constructionpermit-781x1024.png";s:5:"width";i:781;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:30:"constructionpermit-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:31:"constructionpermit-768x1007.png";s:5:"width";i:768;s:6:"height";i:1007;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(398, 148, '_edit_last', '3'),
(399, 148, 'authors', 'Marie Lily Delion, Anushavan Hambardzumyan, Joyce Antone, Ibrahim and Ana Maria Santillana Farakos, Doing Business, World Bank'),
(400, 148, '_authors', 'field_61552362ff0dc'),
(401, 148, 'published_year', ''),
(402, 148, '_published_year', 'field_61552660d324f'),
(403, 148, 'citation_details', ''),
(404, 148, '_citation_details', 'field_615526c1d3250'),
(405, 148, 'abstract', 'The world has witnessed an unparalleled expansion of cities in recent decades. The urban population of developing economies is projected to double by 2030, while the area covered by cities could triple. In tandem with this trend, the construction industry is forecast to grow by more than 70%, reaching $15 trillion by 2025. With the population of cities rising around the world, municipal authorities are struggling to keep up with increased demand for their services. In developing economies, in particular, building departments operating under tight budgets and resource constraints are finding it increasingly difficult to enforce building codes, ensure that quality standards are met and adhere to efficient service delivery processing times.'),
(406, 148, '_abstract', 'field_615526f3d3251'),
(407, 148, 'link_to_publication', 'https://www.doingbusiness.org/content/dam/doingBusiness/media/Annual-Reports/English/DB18-Chapters/DB18-Construction-permits.pdf'),
(408, 148, '_link_to_publication', 'field_6155291a7f3ad'),
(409, 148, 'category', 'a:1:{i:0;s:1:"9";}'),
(410, 148, '_category', 'field_615529807f3ae'),
(411, 148, 'publication_image', '149'),
(412, 148, '_publication_image', 'field_6160d5f290f30'),
(413, 150, '_edit_lock', '1634282669:1'),
(414, 151, '_wp_attached_file', '2021/10/beyond.png'),
(415, 151, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:777;s:6:"height";i:1073;s:4:"file";s:18:"2021/10/beyond.png";s:5:"sizes";a:4:{s:6:"medium";a:4:{s:4:"file";s:18:"beyond-217x300.png";s:5:"width";i:217;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:19:"beyond-742x1024.png";s:5:"width";i:742;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:18:"beyond-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:19:"beyond-768x1061.png";s:5:"width";i:768;s:6:"height";i:1061;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(416, 150, '_edit_last', '1'),
(417, 150, 'authors', 'Honorary Consul Kim Lovegrove MSE RML FAIB'),
(418, 150, '_authors', 'field_61552362ff0dc'),
(419, 150, 'published_year', ''),
(420, 150, '_published_year', 'field_61552660d324f'),
(421, 150, 'citation_details', ''),
(422, 150, '_citation_details', 'field_615526c1d3250'),
(423, 150, 'abstract', 'Over the last 20 years the effectiveness of building regulations has been severely tested in light of a litany of regulatory failures in a number of jurisdictions. Interestingly many of the failures have occurred in advanced economies, economies that are not constrained by the extreme budgetary constraints of the developing nations. There has been a “pan jurisdictional” or geographically indiscriminate phenomena where nations from both hemispheres have experienced construction failures ranging from the significant to the extreme. The leaky ‘condo’ crises in the nineties cost Canada many billions of dollars, as did the leaky building syndrome in NZ which has cost that country considerably more. The Latvian supermarket roof collapse which killed 54 people was a negative legacy of the GFC austerity measures and the dismantling of the national building inspectorate.  Then there have been fire spread calamities such as the Brazilian night club 2013 inferno and Grenfell 2017, which claimed the lives of 242 and 72 lives respectively.'),
(424, 150, '_abstract', 'field_615526f3d3251'),
(425, 150, 'link_to_publication', 'http://lclawyers.com.au/best-practice-building-act-2020-beyond-look-like/'),
(426, 150, '_link_to_publication', 'field_6155291a7f3ad'),
(427, 150, 'category', 'a:1:{i:0;s:1:"7";}'),
(428, 150, '_category', 'field_615529807f3ae'),
(429, 150, 'publication_image', '151'),
(430, 150, '_publication_image', 'field_6160d5f290f30'),
(431, 61, '_edit_last', '1'),
(432, 152, '_edit_lock', '1634282608:1'),
(433, 152, '_edit_last', '3'),
(434, 152, 'authors', 'Thomas Moullier and Keiko Sakoda, World Bank'),
(435, 152, '_authors', 'field_61552362ff0dc'),
(436, 152, 'published_year', ''),
(437, 152, '_published_year', 'field_61552660d324f'),
(438, 152, 'citation_details', ''),
(439, 152, '_citation_details', 'field_615526c1d3250'),
(440, 152, 'abstract', 'On January 17, 1995, the devastating Great Hanshin-Awaji Earthquake struck southern Hyogo Prefecture, causing 6,437 deaths and the collapse of about 100,000 houses. When the post-disaster damage analysis was complete, it showed something remarkable: the large majority of collapsed buildings—76 percent—had been constructed before 1971. A much smaller share—21 percent—had been constructed between 1971 and 1981. Buildings built after 1981 accounted for just 3 percent of the collapsed buildings'),
(441, 152, '_abstract', 'field_615526f3d3251'),
(442, 152, 'link_to_publication', 'https://thedocs.worldbank.org/en/doc/162361520295760910-0090022018/original/jppublicationdrmhubtokyoconvertingdisasterexperienceintoasaferbuiltenvironment.pdf'),
(443, 152, '_link_to_publication', 'field_6155291a7f3ad'),
(444, 152, 'category', 'a:1:{i:0;s:1:"8";}'),
(445, 152, '_category', 'field_615529807f3ae'),
(446, 152, 'publication_image', ''),
(447, 152, '_publication_image', 'field_6160d5f290f30'),
(448, 153, '_edit_lock', '1634282606:1'),
(449, 154, '_wp_attached_file', '2021/10/mandatory.png'),
(450, 154, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:780;s:6:"height";i:1015;s:4:"file";s:21:"2021/10/mandatory.png";s:5:"sizes";a:3:{s:6:"medium";a:4:{s:4:"file";s:21:"mandatory-231x300.png";s:5:"width";i:231;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:21:"mandatory-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:21:"mandatory-768x999.png";s:5:"width";i:768;s:6:"height";i:999;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(451, 153, '_edit_last', '1'),
(452, 153, 'authors', 'Honorary Consul Kim Lovegrove MSE RML FAIB'),
(453, 153, '_authors', 'field_61552362ff0dc'),
(454, 153, 'published_year', '20201017'),
(455, 153, '_published_year', 'field_61552660d324f'),
(456, 153, 'citation_details', ''),
(457, 153, '_citation_details', 'field_615526c1d3250'),
(458, 153, 'abstract', 'Proponents of good practice building regulation are increasingly extolling the virtues of building regulatory systems that adopt risk-based building classifications and calibrate the risk profile of buildings with mandatory inspection regimes. Depending on the jurisdiction, the inspection regimes are either under-resourced or over-resourced. One model is the one-size-fits-all approach, where the legislation requires, say, five mandatory inspections regardless of whether the building is a complex or high-consequence building, such as a hospital, or a simple building structure such as a warehouse. A one-size-fits-all approach may over-resource inspections of low-risk buildings and can in some instances under-resource inspections of high-risk buildings.\r\n\r\n\r\n\r\n'),
(459, 153, '_abstract', 'field_615526f3d3251'),
(460, 153, 'link_to_publication', 'http://lclawyers.com.au/virtues-risk-based-building-classifications-mandatory-inspections/'),
(461, 153, '_link_to_publication', 'field_6155291a7f3ad'),
(462, 153, 'category', 'a:1:{i:0;s:1:"9";}'),
(463, 153, '_category', 'field_615529807f3ae'),
(464, 153, 'publication_image', '154'),
(465, 153, '_publication_image', 'field_6160d5f290f30'),
(466, 155, '_edit_lock', '1634282437:1'),
(467, 156, '_wp_attached_file', '2021/10/risk.png'),
(468, 156, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:806;s:6:"height";i:1055;s:4:"file";s:16:"2021/10/risk.png";s:5:"sizes";a:4:{s:6:"medium";a:4:{s:4:"file";s:16:"risk-229x300.png";s:5:"width";i:229;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:17:"risk-782x1024.png";s:5:"width";i:782;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:16:"risk-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:17:"risk-768x1005.png";s:5:"width";i:768;s:6:"height";i:1005;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(469, 155, '_edit_last', '3'),
(470, 155, 'authors', 'Marie Lily Delion and Joyce Ibrahim, Doing Business, World Bank'),
(471, 155, '_authors', 'field_61552362ff0dc'),
(472, 155, 'published_year', ''),
(473, 155, '_published_year', 'field_61552660d324f'),
(474, 155, 'citation_details', ''),
(475, 155, '_citation_details', 'field_615526c1d3250'),
(476, 155, 'abstract', 'Construction accounts for a large share of GDP in most economies. In 2005, during a period of high growth, it was the source of at least 7% of GDP in Bangladesh, India and the United Arab Emirates. Governments often use construction to stimulate economic activity because of its benefits for people across socioeconomic strata.1From New York to Shanghai, economies are competing to build the tallest, biggest, most beautiful buildings. '),
(477, 155, '_abstract', 'field_615526f3d3251'),
(478, 155, 'link_to_publication', 'https://www.doingbusiness.org/content/dam/doingBusiness/media/Annual-Reports/English/DB14-Chapters/DB14-What-role-should-risk-based-inspections-play.pdf'),
(479, 155, '_link_to_publication', 'field_6155291a7f3ad'),
(480, 155, 'category', 'a:1:{i:0;s:1:"6";}'),
(481, 155, '_category', 'field_615529807f3ae'),
(482, 155, 'publication_image', '156'),
(483, 155, '_publication_image', 'field_6160d5f290f30'),
(484, 157, '_edit_lock', '1634282566:1'),
(485, 158, '_wp_attached_file', '2021/10/confidence.png'),
(486, 158, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:516;s:6:"height";i:730;s:4:"file";s:22:"2021/10/confidence.png";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:22:"confidence-212x300.png";s:5:"width";i:212;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:22:"confidence-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(487, 157, '_edit_last', '1'),
(488, 157, 'authors', 'Professor Peter Shergold AC and Bronwyn Weir'),
(489, 157, '_authors', 'field_61552362ff0dc'),
(490, 157, 'published_year', '20181014'),
(491, 157, '_published_year', 'field_61552660d324f'),
(492, 157, 'citation_details', ''),
(493, 157, '_citation_details', 'field_615526c1d3250'),
(494, 157, 'abstract', 'In mid-2017 the Building Ministers’ Forum (BMF) asked us to undertake an assessment of the effectiveness of compliance \r\nand enforcement systems for the building and construction industry across Australia. Whilst our assessment has been \r\nthorough, this report focusses in a succinct way on shortcomings in the implementation of the National Construction \r\nCode (NCC). They will not come as a surprise to the BMF or building industry stakeholders as most have been considered \r\nin detail in a number recent government reports. We are confident that, assisted by this report, jurisdictions, working \r\ncooperatively, can address these shortcomings.'),
(495, 157, '_abstract', 'field_615526f3d3251'),
(496, 157, 'link_to_publication', 'https://www.industry.gov.au/sites/default/files/July%202018/document/pdf/building_ministers_forum_expert_assessment_-_building_confidence.pdf'),
(497, 157, '_link_to_publication', 'field_6155291a7f3ad') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(498, 157, 'category', 'a:2:{i:0;s:1:"7";i:1;s:1:"8";}'),
(499, 157, '_category', 'field_615529807f3ae'),
(500, 157, 'publication_image', '158'),
(501, 157, '_publication_image', 'field_6160d5f290f30'),
(502, 159, '_edit_lock', '1634282485:1'),
(503, 160, '_wp_attached_file', '2021/10/uae.png'),
(504, 160, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:752;s:6:"height";i:996;s:4:"file";s:15:"2021/10/uae.png";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:15:"uae-227x300.png";s:5:"width";i:227;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:15:"uae-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(505, 159, '_edit_last', '1'),
(506, 159, 'authors', ' Bronwyn Weir (see Page 12-13)'),
(507, 159, '_authors', 'field_61552362ff0dc'),
(508, 159, 'published_year', '20201022'),
(509, 159, '_published_year', 'field_61552660d324f'),
(510, 159, 'citation_details', ''),
(511, 159, '_citation_details', 'field_615526c1d3250'),
(512, 159, 'abstract', 'Not a day seems to pass without reading \r\nthat automation and artificial intelligence \r\nwill replace humans in the workplace. For \r\ninstance, a BBC News webpage asks ‘Will \r\na robot take your job?’, and if you type in \r\n‘chartered surveyor’ it will tell you that it is \r\nfairly likely at 63 per cent (bbc.in/2C45IKK). \r\nMeanwhile, the RICS report The Impact \r\nof Emerging Technologies on the Surveying \r\nProfession, published by Remit Consulting \r\nin July 2017, says 88 per cent of a chartered \r\nsurveyor’s duties will be automated in the \r\nnext ten years (rics.org/insighttech). '),
(513, 159, '_abstract', 'field_615526f3d3251'),
(514, 159, 'link_to_publication', 'https://www.rics.org/globalassets/rics-website/media/news/journals/built-environment/built_environment_journal_february_march_v2.pdf'),
(515, 159, '_link_to_publication', 'field_6155291a7f3ad'),
(516, 159, 'category', 'a:1:{i:0;s:1:"7";}'),
(517, 159, '_category', 'field_615529807f3ae'),
(518, 159, 'publication_image', '160'),
(519, 159, '_publication_image', 'field_6160d5f290f30'),
(520, 161, '_edit_lock', '1634282461:1'),
(521, 162, '_wp_attached_file', '2021/10/9607.png'),
(522, 162, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:674;s:6:"height";i:959;s:4:"file";s:16:"2021/10/9607.png";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:16:"9607-211x300.png";s:5:"width";i:211;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:16:"9607-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(523, 161, '_edit_last', '1'),
(524, 161, 'authors', 'Dame Judith Hackitt'),
(525, 161, '_authors', 'field_61552362ff0dc'),
(526, 161, 'published_year', '20181020'),
(527, 161, '_published_year', 'field_61552660d324f'),
(528, 161, 'citation_details', ''),
(529, 161, '_citation_details', 'field_615526c1d3250'),
(530, 161, 'abstract', 'The interim report identified that the current \r\nsystem of building regulations and fire safety is \r\nnot fit for purpose and that a culture change \r\nis required to support the delivery of buildings \r\nthat are safe, both now and in the future. The \r\nsystem failure identified in the interim report has \r\nallowed a culture of indifference to perpetuate.'),
(531, 161, '_abstract', 'field_615526f3d3251'),
(532, 161, 'link_to_publication', 'https://assets.publishing.service.gov.uk/government/uploads/system/uploads/attachment_data/file/707785/Building_a_Safer_Future_-_web.pdf'),
(533, 161, '_link_to_publication', 'field_6155291a7f3ad'),
(534, 161, 'category', 'a:2:{i:0;s:1:"7";i:1;s:1:"8";}'),
(535, 161, '_category', 'field_615529807f3ae'),
(536, 161, 'publication_image', '162'),
(537, 161, '_publication_image', 'field_6160d5f290f30'),
(538, 163, '_edit_lock', '1634282436:1'),
(539, 164, '_wp_attached_file', '2021/10/9551.png'),
(540, 164, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:678;s:6:"height";i:959;s:4:"file";s:16:"2021/10/9551.png";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:16:"9551-212x300.png";s:5:"width";i:212;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:16:"9551-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(541, 163, '_edit_last', '1'),
(542, 163, 'authors', 'Dame Judith Hackitt'),
(543, 163, '_authors', 'field_61552362ff0dc'),
(544, 163, 'published_year', '20171006'),
(545, 163, '_published_year', 'field_61552660d324f'),
(546, 163, 'citation_details', ''),
(547, 163, '_citation_details', 'field_615526c1d3250'),
(548, 163, 'abstract', 'The Independent Review of Building Regulations \r\nand Fire Safety aims to make recommendations \r\nthat will ensure there is a sufficiently robust \r\nregulatory system for the future and provide \r\nfurther assurance to residents that the buildings \r\nthey live in are safe and will remain so.\r\nThis interim report sets out the findings to date \r\nand the direction of travel for the final report'),
(549, 163, '_abstract', 'field_615526f3d3251'),
(550, 163, 'link_to_publication', 'https://assets.publishing.service.gov.uk/government/uploads/system/uploads/attachment_data/file/668831/Independent_Review_of_Building_Regulations_and_Fire_Safety_web_accessible.pdf'),
(551, 163, '_link_to_publication', 'field_6155291a7f3ad'),
(552, 163, 'category', 'a:2:{i:0;s:1:"7";i:1;s:1:"8";}'),
(553, 163, '_category', 'field_615529807f3ae'),
(554, 163, 'publication_image', '164'),
(555, 163, '_publication_image', 'field_6160d5f290f30'),
(556, 165, '_edit_lock', '1634282406:1'),
(557, 166, '_wp_attached_file', '2021/10/hackitt.png'),
(558, 166, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:676;s:6:"height";i:862;s:4:"file";s:19:"2021/10/hackitt.png";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:19:"hackitt-235x300.png";s:5:"width";i:235;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:19:"hackitt-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(559, 165, '_edit_last', '1'),
(560, 165, 'authors', 'Graham Spinardi, Angus Law'),
(561, 165, '_authors', 'field_61552362ff0dc'),
(562, 165, 'published_year', '20191018'),
(563, 165, '_published_year', 'field_61552660d324f'),
(564, 165, 'citation_details', ''),
(565, 165, '_citation_details', 'field_615526c1d3250'),
(566, 165, 'abstract', 'The key findings of the Hackitt review into Building Regulations and Fire Safety are described and discussed in relation to outcomes-based regulation, competency, and drafting of guidance. The Hackitt review identifies a systemic failure of the construction industry underpinned by ignorance, indifference, lack of clarity on roles and responsibility, and inadequate oversight. With regard to design and approval there are three key aspects of the Hackitt recommendations that appear commendable in their intentions, but potentially problematic in their implementation. These concern the outcomes-based emphasis, the need to improve competence, and proposed change in the nature and ownership of guidance documents. The first two of these are intertwined, as the focus on outcomes-based regulation depends entirely on addressing the competency issue; the latter has the potential to result in guidance that becomes bloated in an attempt to satisfy multiple commercial interests, and opens up a debate about whether rules-based guidance should continue to be used.\r\n\r\n'),
(567, 165, '_abstract', 'field_615526f3d3251'),
(568, 165, 'link_to_publication', 'https://www.sciencedirect.com/science/article/pii/S0379711219302176'),
(569, 165, '_link_to_publication', 'field_6155291a7f3ad'),
(570, 165, 'category', 'a:2:{i:0;s:1:"7";i:1;s:1:"8";}'),
(571, 165, '_category', 'field_615529807f3ae'),
(572, 165, 'publication_image', '166'),
(573, 165, '_publication_image', 'field_6160d5f290f30'),
(574, 167, '_edit_lock', '1634258314:3'),
(575, 168, '_wp_attached_file', '2021/10/safety.png'),
(576, 168, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:790;s:6:"height";i:1121;s:4:"file";s:18:"2021/10/safety.png";s:5:"sizes";a:4:{s:6:"medium";a:4:{s:4:"file";s:18:"safety-211x300.png";s:5:"width";i:211;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:19:"safety-722x1024.png";s:5:"width";i:722;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:18:"safety-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:19:"safety-768x1090.png";s:5:"width";i:768;s:6:"height";i:1090;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(577, 167, '_edit_last', '3'),
(578, 167, 'authors', 'Dr Angus Law, Dr Graham Spinardi, Dr Rory Hadden and Dr Stephen Welch'),
(579, 167, '_authors', 'field_61552362ff0dc'),
(580, 167, 'published_year', ''),
(581, 167, '_published_year', 'field_61552660d324f'),
(582, 167, 'citation_details', ''),
(583, 167, '_citation_details', 'field_615526c1d3250'),
(584, 167, 'abstract', 'This document provides a collective response from several University of Edinburgh academics to the questions posed as part of Dame Judith Hackitt’s Call for Evidence, Review of Building Regulations and Fire Safety. The University of Edinburgh has been an internationally leading centre for fire safety engineering research and education since the mid 1970s, and was the first institution globally to offer masters degrees in this discipline (in 1974). The fire safety engineering group at Edinburgh currently comprises 9 academic staff and more than 25 full time PhD students.\r\n'),
(585, 167, '_abstract', 'field_615526f3d3251'),
(586, 167, 'link_to_publication', 'https://era.ed.ac.uk/bitstream/handle/1842/29545/UoE%20-%20Submission%20of%20Evidence.pdf?sequence=1&isAllowed=y'),
(587, 167, '_link_to_publication', 'field_6155291a7f3ad'),
(588, 167, 'category', 'a:1:{i:0;s:1:"7";}'),
(589, 167, '_category', 'field_615529807f3ae'),
(590, 167, 'publication_image', '168'),
(591, 167, '_publication_image', 'field_6160d5f290f30'),
(592, 169, '_edit_lock', '1634282382:1'),
(593, 170, '_wp_attached_file', '2021/10/steering.png'),
(594, 170, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:789;s:6:"height";i:1118;s:4:"file";s:20:"2021/10/steering.png";s:5:"sizes";a:4:{s:6:"medium";a:4:{s:4:"file";s:20:"steering-212x300.png";s:5:"width";i:212;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:21:"steering-723x1024.png";s:5:"width";i:723;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:20:"steering-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:21:"steering-768x1088.png";s:5:"width";i:768;s:6:"height";i:1088;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(595, 169, '_edit_last', '1'),
(596, 169, 'authors', 'Competence Steering Group'),
(597, 169, '_authors', 'field_61552362ff0dc') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(598, 169, 'published_year', '20191011'),
(599, 169, '_published_year', 'field_61552660d324f'),
(600, 169, 'citation_details', ''),
(601, 169, '_citation_details', 'field_615526c1d3250'),
(602, 169, 'abstract', 'This report represents twelve months’ work by more than 150 organisations from across the construction, built environment, fire safety and owner/manager sectors, which have come together to improve the competence of those procuring, designing, constructing, inspecting, assessing, managing and maintaining Higher Risk Residential Buildings (HRRBs).'),
(603, 169, '_abstract', 'field_615526f3d3251'),
(604, 169, 'link_to_publication', 'https://cic.org.uk/admin/resources/raising-the-barinterimfinal-1.pdf'),
(605, 169, '_link_to_publication', 'field_6155291a7f3ad'),
(606, 169, 'category', 'a:1:{i:0;s:1:"7";}'),
(607, 169, '_category', 'field_615529807f3ae'),
(608, 169, 'publication_image', '170'),
(609, 169, '_publication_image', 'field_6160d5f290f30'),
(610, 171, '_edit_lock', '1634258513:3'),
(611, 172, '_wp_attached_file', '2021/10/159.png'),
(612, 172, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:764;s:6:"height";i:1005;s:4:"file";s:15:"2021/10/159.png";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:15:"159-228x300.png";s:5:"width";i:228;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:15:"159-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(613, 171, '_edit_last', '3'),
(614, 171, 'authors', 'Svetlana Bagaudinova, Dana Omran and Umar Shavurov, Doing Business'),
(615, 171, '_authors', 'field_61552362ff0dc'),
(616, 171, 'published_year', ''),
(617, 171, '_published_year', 'field_61552660d324f'),
(618, 171, 'citation_details', ''),
(619, 171, '_citation_details', 'field_615526c1d3250'),
(620, 171, 'abstract', 'One October evening in 2004, Kakha Bendukidze, the minister of economy, \r\nand his deputy, Vakhtang Lejava, were discussing Georgia’s byzantine system of \r\nconstruction licenses and permits. The construction sector was heating up in \r\nTbilisi, but bureaucratic hurdles were weighing down on entrepreneurs. Lejava \r\nsuggested establishing a one-stop shop and speeding up the process of construction permits by adopting a “silence-is-consent” rule. \r\nMinister Bendukidze, a maverick reformer, argued that only a clean break from \r\nthe past would do. This conversation led to the Law on Licensing and Permits \r\nand Regulation 140 on issuing construction permits, both issued in 2005. The result: the number of activities requiring a business license fell from 909 to 159.'),
(621, 171, '_abstract', 'field_615526f3d3251'),
(622, 171, 'link_to_publication', 'https://www.doingbusiness.org/content/dam/doingBusiness/media/Reforms/Case-Studies/2007/Georgia-Permits-2007.pdf'),
(623, 171, '_link_to_publication', 'field_6155291a7f3ad'),
(624, 171, 'category', 'a:1:{i:0;s:1:"6";}'),
(625, 171, '_category', 'field_615529807f3ae'),
(626, 171, 'publication_image', '172'),
(627, 171, '_publication_image', 'field_6160d5f290f30'),
(628, 173, '_edit_lock', '1634282356:1'),
(629, 174, '_wp_attached_file', '2021/10/scratch.png'),
(630, 174, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:765;s:6:"height";i:1006;s:4:"file";s:19:"2021/10/scratch.png";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:19:"scratch-228x300.png";s:5:"width";i:228;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:19:"scratch-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(631, 173, '_edit_last', '1'),
(632, 173, 'authors', 'Carolin Geginat and Jana Malinska, Doing Business'),
(633, 173, '_authors', 'field_61552362ff0dc'),
(634, 173, 'published_year', '20081011'),
(635, 173, '_published_year', 'field_61552660d324f'),
(636, 173, 'citation_details', ''),
(637, 173, '_citation_details', 'field_615526c1d3250'),
(638, 173, 'abstract', 'With the Czech construction market booming, public building offices were \r\nswamped. Projects were becoming bigger and more complex by the day, and the \r\nbuilding officers who had to approve them often felt that they lacked the experience to do so. The officers got a moment to breathe only when, say, the applicant forgot a stamp \r\nor a document in the application. The officer interrupted the process, notified \r\nthe applicant, and put the project back at the bottom of the pile until the application was resubmitted. The result was that builders faced long waits for approval, \r\nand building officers were frustrated because the pile of applications in front of \r\nthem never seemed to shrink. '),
(639, 173, '_abstract', 'field_615526f3d3251'),
(640, 173, 'link_to_publication', 'https://www.doingbusiness.org/content/dam/doingBusiness/media/Reforms/Case-Studies/2008/DB08-CS-Czech.pdf'),
(641, 173, '_link_to_publication', 'field_6155291a7f3ad'),
(642, 173, 'category', 'a:1:{i:0;s:1:"6";}'),
(643, 173, '_category', 'field_615529807f3ae'),
(644, 173, 'publication_image', '174'),
(645, 173, '_publication_image', 'field_6160d5f290f30'),
(646, 175, '_edit_lock', '1634282323:1'),
(647, 176, '_wp_attached_file', '2021/10/newprofession.png'),
(648, 176, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:768;s:6:"height";i:1007;s:4:"file";s:25:"2021/10/newprofession.png";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:25:"newprofession-229x300.png";s:5:"width";i:229;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:25:"newprofession-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(649, 175, '_edit_last', '1'),
(650, 175, 'authors', 'Alejandro Espinosa, Doing Business'),
(651, 175, '_authors', 'field_61552362ff0dc'),
(652, 175, 'published_year', '20091023'),
(653, 175, '_published_year', 'field_61552660d324f'),
(654, 175, 'citation_details', ''),
(655, 175, '_citation_details', 'field_615526c1d3250'),
(656, 175, 'abstract', 'With the Czech construction market booming, public building offices were \r\nswamped. Projects were becoming bigger and more complex by the day, and the \r\nbuilding officers who had to approve them often felt that they lacked the experience to do so. \r\nThe officers got a moment to breathe only when, say, the applicant forgot a stamp \r\nor a document in the application. The officer interrupted the process, notified \r\nthe applicant, and put the project back at the bottom of the pile until the application was resubmitted. The result was that builders faced long waits for approval, \r\nand building officers were frustrated because the pile of applications in front of \r\nthem never seemed to shrink. '),
(657, 175, '_abstract', 'field_615526f3d3251'),
(658, 175, 'link_to_publication', 'https://www.doingbusiness.org/content/dam/doingBusiness/media/Reforms/Case-Studies/2009/DB09-CS-Colombia.pdf'),
(659, 175, '_link_to_publication', 'field_6155291a7f3ad'),
(660, 175, 'category', 'a:2:{i:0;s:1:"7";i:1;s:1:"9";}'),
(661, 175, '_category', 'field_615529807f3ae'),
(662, 175, 'publication_image', '176'),
(663, 175, '_publication_image', 'field_6160d5f290f30'),
(664, 177, '_edit_lock', '1634282283:1'),
(665, 178, '_wp_attached_file', '2021/10/dealing.png'),
(666, 178, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:768;s:6:"height";i:1007;s:4:"file";s:19:"2021/10/dealing.png";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:19:"dealing-229x300.png";s:5:"width";i:229;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:19:"dealing-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(667, 177, '_edit_last', '1'),
(668, 177, 'authors', 'Alejandro Espinosa, Doing Business'),
(669, 177, '_authors', 'field_61552362ff0dc'),
(670, 177, 'published_year', '20091009'),
(671, 177, '_published_year', 'field_61552660d324f'),
(672, 177, 'citation_details', ''),
(673, 177, '_citation_details', 'field_615526c1d3250'),
(674, 177, 'abstract', 'In 1995 obtaining a building permit in Colombia’s capital Bogota was a burdensome and exhausting process. Construction companies had to wait 1,080 days, on average, to obtain clearances from the city’s Planning Office.\r\nTo put this in context, out of 181 economies now examined in Doing Business 2009, only one, Haiti, had construction procedures that took more than 1,000 days.'),
(675, 177, '_abstract', 'field_615526f3d3251'),
(676, 177, 'link_to_publication', 'https://www.doingbusiness.org/content/dam/doingBusiness/media/Reforms/Case-Studies/2009/DB09-CS-Colombia.pdf'),
(677, 177, '_link_to_publication', 'field_6155291a7f3ad'),
(678, 177, 'category', 'a:1:{i:0;s:1:"7";}'),
(679, 177, '_category', 'field_615529807f3ae'),
(680, 177, 'publication_image', '178'),
(681, 177, '_publication_image', 'field_6160d5f290f30'),
(682, 179, '_edit_lock', '1634282232:1'),
(683, 180, '_wp_attached_file', '2021/10/zoning.png'),
(684, 180, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:805;s:6:"height";i:1051;s:4:"file";s:18:"2021/10/zoning.png";s:5:"sizes";a:4:{s:6:"medium";a:4:{s:4:"file";s:18:"zoning-230x300.png";s:5:"width";i:230;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:19:"zoning-784x1024.png";s:5:"width";i:784;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:18:"zoning-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:19:"zoning-768x1003.png";s:5:"width";i:768;s:6:"height";i:1003;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(685, 179, '_edit_last', '1'),
(686, 179, 'authors', 'Marie Lily Delion, Anushavan Hambardzumyan, Joyce Ibrahim, Ana Maria Santillana Farakos and Melissa Scanlan, Doing Business'),
(687, 179, '_authors', 'field_61552362ff0dc'),
(688, 179, 'published_year', '20151022'),
(689, 179, '_published_year', 'field_61552660d324f'),
(690, 179, 'citation_details', ''),
(691, 179, '_citation_details', 'field_615526c1d3250'),
(692, 179, 'abstract', 'Sound regulation of construction \r\nhelps strengthen property rights, \r\nprotects the public from faulty \r\nbuilding practices and contributes to \r\nthe process of capital formation.\r\n But \r\nif procedures are too complicated or \r\ncostly, builders tend to proceed without \r\na permit.\r\n By some estimates 60–80% \r\nof building projects in developing economies are undertaken without the proper \r\npermits and approvals.'),
(693, 179, '_abstract', 'field_615526f3d3251'),
(694, 179, 'link_to_publication', 'https://www.doingbusiness.org/content/dam/doingBusiness/media/Annual-Reports/English/DB15-Chapters/DB15-CaseStudy-Zoning-Urban-Planning.pdf'),
(695, 179, '_link_to_publication', 'field_6155291a7f3ad'),
(696, 179, 'category', 'a:1:{i:0;s:1:"6";}'),
(697, 179, '_category', 'field_615529807f3ae') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(698, 179, 'publication_image', '180'),
(699, 179, '_publication_image', 'field_6160d5f290f30'),
(700, 181, '_edit_lock', '1634282210:1'),
(701, 182, '_wp_attached_file', '2021/10/edinburgh.png'),
(702, 182, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:785;s:6:"height";i:1114;s:4:"file";s:21:"2021/10/edinburgh.png";s:5:"sizes";a:4:{s:6:"medium";a:4:{s:4:"file";s:21:"edinburgh-211x300.png";s:5:"width";i:211;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:22:"edinburgh-722x1024.png";s:5:"width";i:722;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:21:"edinburgh-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:22:"edinburgh-768x1090.png";s:5:"width";i:768;s:6:"height";i:1090;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(703, 181, '_edit_last', '1'),
(704, 181, 'authors', 'David Rush et al.'),
(705, 181, '_authors', 'field_61552362ff0dc'),
(706, 181, 'published_year', '20191019'),
(707, 181, '_published_year', 'field_61552660d324f'),
(708, 181, 'citation_details', ''),
(709, 181, '_citation_details', 'field_615526c1d3250'),
(710, 181, 'abstract', 'It is estimated more than 150,000 people die from fires or burn-related injuries every year. Over 95% of fire \r\ndeaths and burn injuries are in low- and middle-income countries (LMICs)(WHO, 2018). For those who live within \r\ninformal settlements, the risk that fire will be a cause of trauma, injury or death is particularly high. And yet, too \r\nlittle is known about the triggers, incidence and impact of such fires.'),
(711, 181, '_abstract', 'field_615526f3d3251'),
(712, 181, 'link_to_publication', 'https://www.research.ed.ac.uk/portal/files/105783994/GAR_19_FRR_final.pdf'),
(713, 181, '_link_to_publication', 'field_6155291a7f3ad'),
(714, 181, 'category', 'a:1:{i:0;s:1:"6";}'),
(715, 181, '_category', 'field_615529807f3ae'),
(716, 181, 'publication_image', '182'),
(717, 181, '_publication_image', 'field_6160d5f290f30'),
(718, 183, '_edit_lock', '1634282188:1'),
(719, 184, '_wp_attached_file', '2021/10/firesafety.png'),
(720, 184, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:740;s:6:"height";i:1117;s:4:"file";s:22:"2021/10/firesafety.png";s:5:"sizes";a:3:{s:6:"medium";a:4:{s:4:"file";s:22:"firesafety-199x300.png";s:5:"width";i:199;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:23:"firesafety-678x1024.png";s:5:"width";i:678;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:22:"firesafety-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(721, 183, '_edit_last', '1'),
(722, 183, 'authors', 'Peter Johnson,  Dr David Lange, Prof Jose Torero, Ashley Brinson, Marianne  Foley'),
(723, 183, '_authors', 'field_61552362ff0dc'),
(724, 183, 'published_year', '20201023'),
(725, 183, '_published_year', 'field_61552660d324f'),
(726, 183, 'citation_details', ''),
(727, 183, '_citation_details', 'field_615526c1d3250'),
(728, 183, 'abstract', 'The Shergold/Weir “Building Confidence” \r\nreport emphasises the need for fundamental \r\nreform to restore trust in the construction \r\nindustry. A critical aspect to this confidence \r\nis the provision of buildings that are safe, \r\nwith fire safety being a fundamental issue \r\nto be considered. The reports which have \r\nbeen published as part of this Warren Centre \r\nproject focus on how to best deliver fire safety \r\nand define a path that links the current suboptimal situation to a future position of building \r\nsafety and quality assurance. At the core of \r\nthe recommendations of these reports is the \r\nadequate definition and accreditation of the \r\nFire Safety Engineer and clear recognition as \r\nthe professional responsible for delivering the \r\ndesign of the Fire Safety Strategy that is the \r\nbasis for the fire safety of a building.'),
(729, 183, '_abstract', 'field_615526f3d3251'),
(730, 183, 'link_to_publication', 'https://www.sydney.edu.au/content/dam/corporate/documents/faculty-of-engineering-and-information-technologies/industry-and-government/the-warren-centre/the-final-report-fire-safety-engineering-the-warren-centre.pdf'),
(731, 183, '_link_to_publication', 'field_6155291a7f3ad'),
(732, 183, 'category', 'a:2:{i:0;s:1:"6";i:1;s:1:"7";}'),
(733, 183, '_category', 'field_615529807f3ae'),
(734, 183, 'publication_image', '184'),
(735, 183, '_publication_image', 'field_6160d5f290f30'),
(736, 185, '_edit_lock', '1634282161:1'),
(737, 186, '_wp_attached_file', '2021/10/redesign.png'),
(738, 186, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:775;s:6:"height";i:935;s:4:"file";s:20:"2021/10/redesign.png";s:5:"sizes";a:3:{s:6:"medium";a:4:{s:4:"file";s:20:"redesign-249x300.png";s:5:"width";i:249;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:20:"redesign-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:20:"redesign-768x927.png";s:5:"width";i:768;s:6:"height";i:927;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(739, 185, '_edit_last', '1'),
(740, 185, 'authors', 'Honorary Consul Kim Lovegrove MSE RML FAIB'),
(741, 185, '_authors', 'field_61552362ff0dc'),
(742, 185, 'published_year', '20201017'),
(743, 185, '_published_year', 'field_61552660d324f'),
(744, 185, 'citation_details', ''),
(745, 185, '_citation_details', 'field_615526c1d3250'),
(746, 185, 'abstract', 'In many parts of the globe, fire engineering (‘FE’) or fire protection engineering (‘FPE’) is emerging as an increasingly critical discipline. A number of high profile vertical fire spread incidents in recent years have brought in to focus the importance of this profession. Rigorously orchestrated fire engineered design and installation inputs are critical determinants in the arresting of compromised fire suppression outcomes.'),
(747, 185, '_abstract', 'field_615526f3d3251'),
(748, 185, 'link_to_publication', 'http://lclawyers.com.au/fire-engineering-challenges-changes-redesign-regulation/'),
(749, 185, '_link_to_publication', 'field_6155291a7f3ad'),
(750, 185, 'category', 'a:2:{i:0;s:1:"7";i:1;s:1:"8";}'),
(751, 185, '_category', 'field_615529807f3ae'),
(752, 185, 'publication_image', '186'),
(753, 185, '_publication_image', 'field_6160d5f290f30'),
(754, 187, '_edit_lock', '1634282134:1'),
(755, 188, '_wp_attached_file', '2021/10/prescription.png'),
(756, 188, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:791;s:6:"height";i:1122;s:4:"file";s:24:"2021/10/prescription.png";s:5:"sizes";a:4:{s:6:"medium";a:4:{s:4:"file";s:24:"prescription-211x300.png";s:5:"width";i:211;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:25:"prescription-722x1024.png";s:5:"width";i:722;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:24:"prescription-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:25:"prescription-768x1089.png";s:5:"width";i:768;s:6:"height";i:1089;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(757, 187, '_edit_last', '1'),
(758, 187, 'authors', ' Angus Law and Neal Butterworth'),
(759, 187, '_authors', 'field_61552362ff0dc'),
(760, 187, 'published_year', '20191011'),
(761, 187, '_published_year', 'field_61552660d324f'),
(762, 187, 'citation_details', ''),
(763, 187, '_citation_details', 'field_615526c1d3250'),
(764, 187, 'abstract', 'This paper presents a discussion of the recent ‘ban’ on combustible cladding that has been implemented in England\r\nfollowing the Grenfell Tower fire. The ban is discussed in terms of its context within the existing regulatory system\r\nin England and is analysed in terms of the intended and unintended consequences. Key intended consequences are\r\nidentified as the prohibition of ‘Grenfell-type’ cladding, the banning of desktop studies for relevant buildings and\r\nthe banning of some forms of engineered timber construction. Unintended consequences include the devaluation of\r\nprivate leaseholder’s homes, the potential for the problems with the construction industry to be perceived as ‘fixed’\r\nand a raft of somewhat absurd administrative effects. The authors conclude that the ban has likely been effective in\r\nits overall aim but that its success is, ironically, inherently bound up with the efficacy of the very regulations that it\r\nwas intended to fix. The authors also identify that the new ban is potentially susceptible to ‘gaming’ by\r\nunscrupulous parties within the construction industry.'),
(765, 187, '_abstract', 'field_615526f3d3251'),
(766, 187, 'link_to_publication', 'https://www.icevirtuallibrary.com/doi/pdf/10.1680/jfoen.19.00004'),
(767, 187, '_link_to_publication', 'field_6155291a7f3ad'),
(768, 187, 'category', 'a:2:{i:0;s:1:"7";i:1;s:1:"8";}'),
(769, 187, '_category', 'field_615529807f3ae'),
(770, 187, 'publication_image', '188'),
(771, 187, '_publication_image', 'field_6160d5f290f30'),
(772, 189, '_edit_lock', '1634282102:1'),
(773, 190, '_wp_attached_file', '2021/10/safer.png'),
(774, 190, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:674;s:6:"height";i:957;s:4:"file";s:17:"2021/10/safer.png";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:17:"safer-211x300.png";s:5:"width";i:211;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:17:"safer-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(775, 189, '_edit_last', '1'),
(776, 189, 'authors', 'Dame Judith Hackitt'),
(777, 189, '_authors', 'field_61552362ff0dc'),
(778, 189, 'published_year', '20181012'),
(779, 189, '_published_year', 'field_61552660d324f'),
(780, 189, 'citation_details', ''),
(781, 189, '_citation_details', 'field_615526c1d3250'),
(782, 189, 'abstract', 'The interim report identified that the current \r\nsystem of building regulations and fire safety is \r\nnot fit for purpose and that a culture change \r\nis required to support the delivery of buildings \r\nthat are safe, both now and in the future. The \r\nsystem failure identified in the interim report has \r\nallowed a culture of indifference to perpetuate. '),
(783, 189, '_abstract', 'field_615526f3d3251'),
(784, 189, 'link_to_publication', 'https://assets.publishing.service.gov.uk/government/uploads/system/uploads/attachment_data/file/707785/Building_a_Safer_Future_-_web.pdf'),
(785, 189, '_link_to_publication', 'field_6155291a7f3ad'),
(786, 189, 'category', 'a:2:{i:0;s:1:"6";i:1;s:1:"8";}'),
(787, 189, '_category', 'field_615529807f3ae'),
(788, 189, 'publication_image', '190'),
(789, 189, '_publication_image', 'field_6160d5f290f30'),
(790, 191, '_edit_lock', '1634282074:1'),
(791, 192, '_wp_attached_file', '2021/10/future.png'),
(792, 192, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:674;s:6:"height";i:961;s:4:"file";s:18:"2021/10/future.png";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:18:"future-210x300.png";s:5:"width";i:210;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:18:"future-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(793, 191, '_edit_last', '1'),
(794, 191, 'authors', 'Dame Judith Hackitt'),
(795, 191, '_authors', 'field_61552362ff0dc'),
(796, 191, 'published_year', '20171013'),
(797, 191, '_published_year', 'field_61552660d324f') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(798, 191, 'citation_details', ''),
(799, 191, '_citation_details', 'field_615526c1d3250'),
(800, 191, 'abstract', 'The Independent Review of Building Regulations \r\nand Fire Safety aims to make recommendations \r\nthat will ensure there is a sufficiently robust \r\nregulatory system for the future and provide \r\nfurther assurance to residents that the buildings \r\nthey live in are safe and will remain so.\r\nThis interim report sets out the findings to date \r\nand the direction of travel for the final report. '),
(801, 191, '_abstract', 'field_615526f3d3251'),
(802, 191, 'link_to_publication', 'https://assets.publishing.service.gov.uk/government/uploads/system/uploads/attachment_data/file/668831/Independent_Review_of_Building_Regulations_and_Fire_Safety_web_accessible.pdf'),
(803, 191, '_link_to_publication', 'field_6155291a7f3ad'),
(804, 191, 'category', 'a:2:{i:0;s:1:"6";i:1;s:1:"8";}'),
(805, 191, '_category', 'field_615529807f3ae'),
(806, 191, 'publication_image', '192'),
(807, 191, '_publication_image', 'field_6160d5f290f30'),
(808, 193, '_edit_lock', '1634282389:1'),
(809, 194, '_wp_attached_file', '2021/10/journal.png'),
(810, 194, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:687;s:6:"height";i:875;s:4:"file";s:19:"2021/10/journal.png";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:19:"journal-236x300.png";s:5:"width";i:236;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:19:"journal-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(811, 193, '_edit_last', '1'),
(812, 193, 'authors', 'Graham Spinardi, Angus Law'),
(813, 193, '_authors', 'field_61552362ff0dc'),
(814, 193, 'published_year', '20191010'),
(815, 193, '_published_year', 'field_61552660d324f'),
(816, 193, 'citation_details', ''),
(817, 193, '_citation_details', 'field_615526c1d3250'),
(818, 193, 'abstract', 'The key findings of the Hackitt review into Building Regulations and Fire Safety are described and discussed in relation to outcomes-based regulation, competency, and drafting of guidance. The Hackitt review identifies a systemic failure of the construction industry underpinned by ignorance, indifference, lack of clarity on roles and responsibility, and inadequate oversight. With regard to design and approval there are three key aspects of the Hackitt recommendations that appear commendable in their intentions, but potentially problematic in their implementation. These concern the outcomes-based emphasis, the need to improve competence, and proposed change in the nature and ownership of guidance documents. The first two of these are intertwined, as the focus on outcomes-based regulation depends entirely on addressing the competency issue; the latter has the potential to result in guidance that becomes bloated in an attempt to satisfy multiple commercial interests, and opens up a debate about whether rules-based guidance should continue to be used.'),
(819, 193, '_abstract', 'field_615526f3d3251'),
(820, 193, 'link_to_publication', 'https://www.sciencedirect.com/science/article/pii/S0379711219302176'),
(821, 193, '_link_to_publication', 'field_6155291a7f3ad'),
(822, 193, 'category', 'a:1:{i:0;s:1:"8";}'),
(823, 193, '_category', 'field_615529807f3ae'),
(824, 193, 'publication_image', '194'),
(825, 193, '_publication_image', 'field_6160d5f290f30'),
(826, 195, '_edit_lock', '1634282385:1'),
(827, 196, '_wp_attached_file', '2021/10/evidence.png'),
(828, 196, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:790;s:6:"height";i:1117;s:4:"file";s:20:"2021/10/evidence.png";s:5:"sizes";a:4:{s:6:"medium";a:4:{s:4:"file";s:20:"evidence-212x300.png";s:5:"width";i:212;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:21:"evidence-724x1024.png";s:5:"width";i:724;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:20:"evidence-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:21:"evidence-768x1086.png";s:5:"width";i:768;s:6:"height";i:1086;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(829, 195, '_edit_last', '1'),
(830, 195, 'authors', 'Dr Angus Law, Dr Graham Spinardi, Dr Rory Hadden and Dr Stephen Welch,'),
(831, 195, '_authors', 'field_61552362ff0dc'),
(832, 195, 'published_year', ''),
(833, 195, '_published_year', 'field_61552660d324f'),
(834, 195, 'citation_details', ''),
(835, 195, '_citation_details', 'field_615526c1d3250'),
(836, 195, 'abstract', 'This document provides a collective response from several University of Edinburgh \r\nacademics to the questions posed as part of Dame Judith Hackitt’s Call for Evidence, \r\nReview of Building Regulations and Fire Safety. The University of Edinburgh has been an \r\ninternationally leading centre for fire safety engineering research and education since the \r\nmid 1970s, and was the first institution globally to offer masters degrees in this discipline (in \r\n1974). The fire safety engineering group at Edinburgh currently comprises 9 academic staff \r\nand more than 25 full time PhD students'),
(837, 195, '_abstract', 'field_615526f3d3251'),
(838, 195, 'link_to_publication', 'https://era.ed.ac.uk/bitstream/handle/1842/29545/UoE%20-%20Submission%20of%20Evidence.pdf?sequence=1&isAllowed=y'),
(839, 195, '_link_to_publication', 'field_6155291a7f3ad'),
(840, 195, 'category', 'a:1:{i:0;s:1:"8";}'),
(841, 195, '_category', 'field_615529807f3ae'),
(842, 195, 'publication_image', '196'),
(843, 195, '_publication_image', 'field_6160d5f290f30'),
(844, 197, '_edit_lock', '1634282373:1'),
(845, 198, '_wp_attached_file', '2021/10/university.png'),
(846, 198, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:791;s:6:"height";i:1125;s:4:"file";s:22:"2021/10/university.png";s:5:"sizes";a:4:{s:6:"medium";a:4:{s:4:"file";s:22:"university-211x300.png";s:5:"width";i:211;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:23:"university-720x1024.png";s:5:"width";i:720;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:22:"university-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:23:"university-768x1092.png";s:5:"width";i:768;s:6:"height";i:1092;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(847, 197, '_edit_last', '1'),
(848, 197, 'authors', 'Performance, and Professionalism (2016), Graham Spinardi'),
(849, 197, '_authors', 'field_61552362ff0dc'),
(850, 197, 'published_year', '20151010'),
(851, 197, '_published_year', 'field_61552660d324f'),
(852, 197, 'citation_details', ''),
(853, 197, '_citation_details', 'field_615526c1d3250'),
(854, 197, 'abstract', 'Fire safety regulation is changing as adherence to prescriptive requirements is being replaced or \r\ncomplemented by an approach based on performance based design (PBD). However, this shift in \r\nregulatory practice raises important issues concerning the ability of regulators to provide competent \r\noversight of fire safety engineering. This stems from the inevitable ‘expertise asymmetry’ that exists \r\nbetween regulators and those who are regulated, and means that regulators must rely on, and trust, data \r\nand analysis that is produced by industry. This dilemma could logically be resolved if fire safety \r\nengineering was accorded the status of a self-regulating profession whose competence and ethics were \r\ntrusted by regulators. However, there are two main barriers to this: doubts about whether fire safety \r\nengineering is yet sufficiently mature as a profession; and concerns about whether the probabilistic \r\nnature of fire risks make fire safety engineering unsuitable for self-regulation.\r\n'),
(855, 197, '_abstract', 'field_615526f3d3251'),
(856, 197, 'link_to_publication', 'https://www.research.ed.ac.uk/portal/files/23116459/SpinardiFortyFirePaperFinalOct2015.pdf'),
(857, 197, '_link_to_publication', 'field_6155291a7f3ad'),
(858, 197, 'category', 'a:1:{i:0;s:1:"8";}'),
(859, 197, '_category', 'field_615529807f3ae'),
(860, 197, 'publication_image', '198'),
(861, 197, '_publication_image', 'field_6160d5f290f30'),
(862, 199, '_edit_lock', '1634511258:2'),
(863, 200, '_wp_attached_file', '2021/10/last.png'),
(864, 200, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:785;s:6:"height";i:1117;s:4:"file";s:16:"2021/10/last.png";s:5:"sizes";a:4:{s:6:"medium";a:4:{s:4:"file";s:16:"last-211x300.png";s:5:"width";i:211;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:17:"last-720x1024.png";s:5:"width";i:720;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:16:"last-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:17:"last-768x1093.png";s:5:"width";i:768;s:6:"height";i:1093;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(865, 199, '_edit_last', '1'),
(866, 199, 'authors', 'Graham Spinardi, Luke Bisby, Jose L Torer'),
(867, 199, '_authors', 'field_61552362ff0dc'),
(868, 199, 'published_year', '20161015'),
(869, 199, '_published_year', 'field_61552660d324f'),
(870, 199, 'citation_details', ''),
(871, 199, '_citation_details', 'field_615526c1d3250'),
(872, 199, 'abstract', 'This communication presents an overview of contemporary sociological issues in fire safety. The \r\nmost obviously social aspects of fire safety – those that relate to the socioeconomic distribution of \r\nfire casualties and damage – are discussed first. The means that society uses to mitigate fire risks \r\nthrough regulation are treated next; focusing on the shift towards fire engineered solutions and the \r\nparticular challenges this poses for the social distribution and communication of fire safety \r\nknowledge and expertise. Finally, the social construction of fire safety knowledge is discussed, \r\nraising questions about whether the confidence in the application of this knowledge by the full range \r\nof participants in the fire safety design and approvals process is always justified, given the specific \r\nassumptions involved in both the production of the knowledge and its extension to applications \r\nsignificantly removed from the original knowledge production; and the requisite competence that is \r\ntherefore needed to apply this knowledge. The overarching objective is to argue that the fire safety \r\nprofessions ought to be more reflexive and informed about the nature of the knowledge and expertise \r\nthat they develop and apply, and to suggest that fire safety scientists and engineers ought to actively \r\ncollaborate with social scientists in research designed to study the way people interact with fire safety \r\ntechnology.\r\n'),
(873, 199, '_abstract', 'field_615526f3d3251'),
(874, 199, 'link_to_publication', 'https://www.pure.ed.ac.uk/ws/portalfiles/portal/27028618/Spinardi_Etal_Sociology_Fire_Review_2016_Review_Sociological_Issues_Fire_Safety_Regulation.pdf'),
(875, 199, '_link_to_publication', 'field_6155291a7f3ad'),
(876, 199, 'category', 'a:1:{i:0;s:1:"8";}'),
(877, 199, '_category', 'field_615529807f3ae'),
(878, 199, 'publication_image', '200'),
(879, 199, '_publication_image', 'field_6160d5f290f30'),
(880, 202, '_edit_lock', '1634366442:4'),
(881, 203, '_wp_attached_file', '2021/10/1.jpg'),
(882, 203, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:150;s:6:"height";i:150;s:4:"file";s:13:"2021/10/1.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:13:"1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:3:"5.6";s:6:"credit";s:0:"";s:6:"camera";s:19:"Canon EOS REBEL T3i";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1456107883";s:9:"copyright";s:0:"";s:12:"focal_length";s:2:"55";s:3:"iso";s:4:"2000";s:13:"shutter_speed";s:6:"0.0125";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(883, 202, '_edit_last', '4'),
(884, 202, 'board_member_title', 'Inaugural Board Chair'),
(885, 202, '_board_member_title', 'field_61677496eb69b'),
(886, 202, 'secondary_title', 'Royal Medal of the Lion (RML) | Order of the Star of Honor of Ethiopia (MSE)'),
(887, 202, '_secondary_title', 'field_61677442eb69a'),
(888, 202, 'bio', 'Kim, in his capacity as a Senior Consultant to the World Bank, assists the World Bank with the provision of international best practice law reform advice on building regulations.\r\nHe has been deployed in law reform advisory capacities in Mumbai, Shanghai, Beijing and Tokyo. Kim is an Adjunct Professor at the University of Canberra and a past Conjoint Professor of Building Regulation and Certification at the University of Newcastle (New South Wales).\r\nHeaded up the team that had carriage of the National Model Building Act that became the blueprint for regulatory law reform in the nineties.'),
(889, 202, '_bio', 'field_61677623eb6a1'),
(890, 202, 'board_member_image', '203'),
(891, 202, '_board_member_image', 'field_61677737eb6a6'),
(892, 202, 'professional_affiliations_0_role', 'Adjunct Professor'),
(893, 202, '_professional_affiliations_0_role', 'field_61677510eb69d'),
(894, 202, 'professional_affiliations_0_professional_body', 'University of Canberra'),
(895, 202, '_professional_affiliations_0_professional_body', 'field_6167753aeb69e'),
(896, 202, 'professional_affiliations_0_pro_start_year', ''),
(897, 202, '_professional_affiliations_0_pro_start_year', 'field_6167754beb69f') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(898, 202, 'professional_affiliations_1_role', 'Past Chair'),
(899, 202, '_professional_affiliations_1_role', 'field_61677510eb69d'),
(900, 202, 'professional_affiliations_1_professional_body', 'Building Professionals Board Victoria'),
(901, 202, '_professional_affiliations_1_professional_body', 'field_6167753aeb69e'),
(902, 202, 'professional_affiliations_1_pro_start_year', ''),
(903, 202, '_professional_affiliations_1_pro_start_year', 'field_6167754beb69f'),
(904, 202, 'professional_affiliations_2_role', 'Past President'),
(905, 202, '_professional_affiliations_2_role', 'field_61677510eb69d'),
(906, 202, 'professional_affiliations_2_professional_body', 'the Australian Institute of Building (Vic Chapter) and the New Zealand Institute of Building (Northern Chapter)'),
(907, 202, '_professional_affiliations_2_professional_body', 'field_6167753aeb69e'),
(908, 202, 'professional_affiliations_2_pro_start_year', ''),
(909, 202, '_professional_affiliations_2_pro_start_year', 'field_6167754beb69f'),
(910, 202, 'professional_affiliations_3_role', 'Past Deputy Director'),
(911, 202, '_professional_affiliations_3_role', 'field_61677510eb69d'),
(912, 202, 'professional_affiliations_3_professional_body', 'Australian Building Codes Board (Mid-90s)'),
(913, 202, '_professional_affiliations_3_professional_body', 'field_6167753aeb69e'),
(914, 202, 'professional_affiliations_3_pro_start_year', ''),
(915, 202, '_professional_affiliations_3_pro_start_year', 'field_6167754beb69f'),
(916, 202, 'professional_affiliations_4_role', 'Past Deputy Director'),
(917, 202, '_professional_affiliations_4_role', 'field_61677510eb69d'),
(918, 202, 'professional_affiliations_4_professional_body', 'Department of Building Control (VIC) (Early 90s) – Predecessor of the VBA'),
(919, 202, '_professional_affiliations_4_professional_body', 'field_6167753aeb69e'),
(920, 202, 'professional_affiliations_4_pro_start_year', ''),
(921, 202, '_professional_affiliations_4_pro_start_year', 'field_6167754beb69f'),
(922, 202, 'professional_affiliations_5_role', 'Past Ethiopian Honorary Consul'),
(923, 202, '_professional_affiliations_5_role', 'field_61677510eb69d'),
(924, 202, 'professional_affiliations_5_professional_body', 'Victoria'),
(925, 202, '_professional_affiliations_5_professional_body', 'field_6167753aeb69e'),
(926, 202, 'professional_affiliations_5_pro_start_year', ''),
(927, 202, '_professional_affiliations_5_pro_start_year', 'field_6167754beb69f'),
(928, 202, 'professional_affiliations', '6'),
(929, 202, '_professional_affiliations', 'field_61677500eb69c'),
(930, 202, 'awards', ''),
(931, 202, '_awards', 'field_61677654eb6a2'),
(932, 204, '_wp_attached_file', '2021/09/The-Virtues-of-Risk-Based-Building-Classifications-Mandatory-Inspections.png'),
(933, 204, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:777;s:6:"height";i:1001;s:4:"file";s:84:"2021/09/The-Virtues-of-Risk-Based-Building-Classifications-Mandatory-Inspections.png";s:5:"sizes";a:3:{s:6:"medium";a:4:{s:4:"file";s:84:"The-Virtues-of-Risk-Based-Building-Classifications-Mandatory-Inspections-233x300.png";s:5:"width";i:233;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:84:"The-Virtues-of-Risk-Based-Building-Classifications-Mandatory-Inspections-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:84:"The-Virtues-of-Risk-Based-Building-Classifications-Mandatory-Inspections-768x989.png";s:5:"width";i:768;s:6:"height";i:989;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(934, 206, '_menu_item_type', 'post_type'),
(935, 206, '_menu_item_menu_item_parent', '0'),
(936, 206, '_menu_item_object_id', '8'),
(937, 206, '_menu_item_object', 'page'),
(938, 206, '_menu_item_target', ''),
(939, 206, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(940, 206, '_menu_item_xfn', ''),
(941, 206, '_menu_item_url', ''),
(942, 206, '_menu_item_orphaned', '1634342299'),
(943, 207, '_menu_item_type', 'post_type'),
(944, 207, '_menu_item_menu_item_parent', '0'),
(945, 207, '_menu_item_object_id', '11'),
(946, 207, '_menu_item_object', 'page'),
(947, 207, '_menu_item_target', ''),
(948, 207, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(949, 207, '_menu_item_xfn', ''),
(950, 207, '_menu_item_url', ''),
(952, 208, '_menu_item_type', 'post_type'),
(953, 208, '_menu_item_menu_item_parent', '0'),
(954, 208, '_menu_item_object_id', '27'),
(955, 208, '_menu_item_object', 'page'),
(956, 208, '_menu_item_target', ''),
(957, 208, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(958, 208, '_menu_item_xfn', ''),
(959, 208, '_menu_item_url', ''),
(961, 209, '_menu_item_type', 'post_type'),
(962, 209, '_menu_item_menu_item_parent', '0'),
(963, 209, '_menu_item_object_id', '69'),
(964, 209, '_menu_item_object', 'page'),
(965, 209, '_menu_item_target', ''),
(966, 209, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(967, 209, '_menu_item_xfn', ''),
(968, 209, '_menu_item_url', ''),
(970, 210, '_menu_item_type', 'post_type'),
(971, 210, '_menu_item_menu_item_parent', '0'),
(972, 210, '_menu_item_object_id', '122'),
(973, 210, '_menu_item_object', 'page'),
(974, 210, '_menu_item_target', ''),
(975, 210, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(976, 210, '_menu_item_xfn', ''),
(977, 210, '_menu_item_url', ''),
(979, 211, '_menu_item_type', 'post_type'),
(980, 211, '_menu_item_menu_item_parent', '0'),
(981, 211, '_menu_item_object_id', '45'),
(982, 211, '_menu_item_object', 'page'),
(983, 211, '_menu_item_target', ''),
(984, 211, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(985, 211, '_menu_item_xfn', ''),
(986, 211, '_menu_item_url', ''),
(988, 212, '_menu_item_type', 'post_type'),
(989, 212, '_menu_item_menu_item_parent', '0'),
(990, 212, '_menu_item_object_id', '16'),
(991, 212, '_menu_item_object', 'page'),
(992, 212, '_menu_item_target', ''),
(993, 212, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(994, 212, '_menu_item_xfn', ''),
(995, 212, '_menu_item_url', ''),
(996, 213, '_wp_attached_file', '2021/10/favicon.png'),
(997, 213, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:19:"2021/10/favicon.png";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:19:"favicon-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:19:"favicon-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(998, 214, '_wp_attached_file', '2021/10/cropped-favicon.png'),
(999, 214, '_wp_attachment_context', 'site-icon'),
(1000, 214, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:27:"2021/10/cropped-favicon.png";s:5:"sizes";a:6:{s:6:"medium";a:4:{s:4:"file";s:27:"cropped-favicon-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:27:"cropped-favicon-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:13:"site_icon-270";a:4:{s:4:"file";s:27:"cropped-favicon-270x270.png";s:5:"width";i:270;s:6:"height";i:270;s:9:"mime-type";s:9:"image/png";}s:13:"site_icon-192";a:4:{s:4:"file";s:27:"cropped-favicon-192x192.png";s:5:"width";i:192;s:6:"height";i:192;s:9:"mime-type";s:9:"image/png";}s:13:"site_icon-180";a:4:{s:4:"file";s:27:"cropped-favicon-180x180.png";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:9:"image/png";}s:12:"site_icon-32";a:4:{s:4:"file";s:25:"cropped-favicon-32x32.png";s:5:"width";i:32;s:6:"height";i:32;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1006, 216, '_edit_lock', '1634348070:1'),
(1007, 217, '_wp_attached_file', '2021/10/IBQC-Forum-Overview-Agenda.pdf') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1008, 216, '_edit_last', '1'),
(1009, 216, 'forum_date', '20201009'),
(1010, 216, '_forum_date', 'field_615a418f66d63'),
(1011, 216, 'description', 'On 9 October 2020, the University of Canberra and the International Code Council hosted the inaugural annual Forum of the International Building Quality Centre (IBQC). \r\n\r\nThis first Forum was held virtually from 2-4pm GMT and featured a keynote speech from Dame Judith Hackitt, former Chair of the UK Health and Safety Executive and the Independent Review of Building Regulations and Fire Safety following the Grenfell Tower fire. Dame Judith is now an advisor to UK Government and to Victoria, Australia Government on delivery of major reform to Building Regulations. \r\n\r\nClosing remarks were delivered by Ms. Sylvia Solf of The World Bank. Various IBQC Board Members will offer insight into the practices that enable safety, efficiency and innovation as discussed in the Principles for Good Practice Building Regulation publication.'),
(1012, 216, '_description', 'field_615a41c566d64'),
(1013, 216, 'link_to_program', '217'),
(1014, 216, '_link_to_program', 'field_615a41e466d65'),
(1015, 216, 'youtube_link', 'https://www.youtube.com/watch?v=zUzxbEgUGg0'),
(1016, 216, '_youtube_link', 'field_615a421f66d66'),
(1017, 216, 'topics_and_speakers_0_speaker_name', 'Dame Judith Hackitt'),
(1018, 216, '_topics_and_speakers_0_speaker_name', 'field_6160c8ac83e11'),
(1019, 216, 'topics_and_speakers_0_speaker_credentials', 'Chair of Make UK, Chemical Engineer'),
(1020, 216, '_topics_and_speakers_0_speaker_credentials', 'field_6160c91183e13'),
(1021, 216, 'topics_and_speakers_0_speaker_topic', 'Keynote Address'),
(1022, 216, '_topics_and_speakers_0_speaker_topic', 'field_6160c8cd83e12'),
(1023, 216, 'topics_and_speakers_1_speaker_name', 'Adjunct Professor Kim Lovegrove'),
(1024, 216, '_topics_and_speakers_1_speaker_name', 'field_6160c8ac83e11'),
(1025, 216, 'topics_and_speakers_1_speaker_credentials', 'Senior Construction Lawyer, Lovegrove and Cotton Lawyers and Adjunct Professor at the University of Canberra'),
(1026, 216, '_topics_and_speakers_1_speaker_credentials', 'field_6160c91183e13'),
(1027, 216, 'topics_and_speakers_1_speaker_topic', '“Best practice dispute resolution mechanisms and mandatory auditing”'),
(1028, 216, '_topics_and_speakers_1_speaker_topic', 'field_6160c8cd83e12'),
(1029, 216, 'topics_and_speakers_2_speaker_name', 'Mr. Alejandro Espinosa-Wang'),
(1030, 216, '_topics_and_speakers_2_speaker_name', 'field_6160c8ac83e11'),
(1031, 216, 'topics_and_speakers_2_speaker_credentials', 'Senior Private Sector Specialist, The World Bank'),
(1032, 216, '_topics_and_speakers_2_speaker_credentials', 'field_6160c91183e13'),
(1033, 216, 'topics_and_speakers_2_speaker_topic', '“A mandatory statutory process which provides for rigorous inspections of work by Competent Practitioners”'),
(1034, 216, '_topics_and_speakers_2_speaker_topic', 'field_6160c8cd83e12'),
(1035, 216, 'topics_and_speakers_3_speaker_name', 'Ms. Stephanie Barwise QC'),
(1036, 216, '_topics_and_speakers_3_speaker_name', 'field_6160c8ac83e11'),
(1037, 216, 'topics_and_speakers_3_speaker_credentials', 'AtkinChambers Barristers'),
(1038, 216, '_topics_and_speakers_3_speaker_credentials', 'field_6160c91183e13'),
(1039, 216, 'topics_and_speakers_3_speaker_topic', '“Building approvals systems”'),
(1040, 216, '_topics_and_speakers_3_speaker_topic', 'field_6160c8cd83e12'),
(1041, 216, 'topics_and_speakers_4_speaker_name', 'Ms. Bronwyn Weir'),
(1042, 216, '_topics_and_speakers_4_speaker_name', 'field_6160c8ac83e11'),
(1043, 216, 'topics_and_speakers_4_speaker_credentials', 'Director at Weir Legal and Consulting Pty Ltd'),
(1044, 216, '_topics_and_speakers_4_speaker_credentials', 'field_6160c91183e13'),
(1045, 216, 'topics_and_speakers_4_speaker_topic', '“Regulating for building product safety and compliance”'),
(1046, 216, '_topics_and_speakers_4_speaker_topic', 'field_6160c8cd83e12'),
(1047, 216, 'topics_and_speakers_5_speaker_name', 'Professor José Torero'),
(1048, 216, '_topics_and_speakers_5_speaker_name', 'field_6160c8ac83e11'),
(1049, 216, 'topics_and_speakers_5_speaker_credentials', 'Professor of Civil Engineering and Head of the Civil Engineering Department, University College London'),
(1050, 216, '_topics_and_speakers_5_speaker_credentials', 'field_6160c91183e13'),
(1051, 216, 'topics_and_speakers_5_speaker_topic', '“Professional competency certification: what is required in design and practice”'),
(1052, 216, '_topics_and_speakers_5_speaker_topic', 'field_6160c8cd83e12'),
(1053, 216, 'topics_and_speakers_6_speaker_name', 'Mr. Michael DeLint'),
(1054, 216, '_topics_and_speakers_6_speaker_name', 'field_6160c8ac83e11'),
(1055, 216, 'topics_and_speakers_6_speaker_credentials', 'Director, Regulatory Reform and Technical Standards, Residential Construction of Ontario'),
(1056, 216, '_topics_and_speakers_6_speaker_credentials', 'field_6160c91183e13'),
(1057, 216, 'topics_and_speakers_6_speaker_topic', '“Best practice solutions for developing economies: adapting the Principles”'),
(1058, 216, '_topics_and_speakers_6_speaker_topic', 'field_6160c8cd83e12'),
(1059, 216, 'topics_and_speakers_7_speaker_name', 'Adjunct Professor Robert Whittaker'),
(1060, 216, '_topics_and_speakers_7_speaker_name', 'field_6160c8ac83e11'),
(1061, 216, 'topics_and_speakers_7_speaker_credentials', 'Director of Holdum Whittaker and Adjunct Professor at the University of Canberra'),
(1062, 216, '_topics_and_speakers_7_speaker_credentials', 'field_6160c91183e13'),
(1063, 216, 'topics_and_speakers_7_speaker_topic', '“The importance of clear & transparent legislative & regulatory frameworks to achieving building safety”'),
(1064, 216, '_topics_and_speakers_7_speaker_topic', 'field_6160c8cd83e12'),
(1065, 216, 'topics_and_speakers_8_speaker_name', 'Ms. Sylvia Solf'),
(1066, 216, '_topics_and_speakers_8_speaker_name', 'field_6160c8ac83e11'),
(1067, 216, 'topics_and_speakers_8_speaker_credentials', 'Global Product Specialist, Trade and Competitiveness, The World Bank'),
(1068, 216, '_topics_and_speakers_8_speaker_credentials', 'field_6160c91183e13'),
(1069, 216, 'topics_and_speakers_8_speaker_topic', 'Closing Address'),
(1070, 216, '_topics_and_speakers_8_speaker_topic', 'field_6160c8cd83e12'),
(1071, 216, 'topics_and_speakers', '9'),
(1072, 216, '_topics_and_speakers', 'field_6160c6a283e10'),
(1073, 218, '_edit_lock', '1634348729:3'),
(1074, 104, '_edit_last', '1'),
(1075, 219, '_wp_attached_file', '2021/10/2.jpg'),
(1076, 219, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:150;s:6:"height";i:150;s:4:"file";s:13:"2021/10/2.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:13:"2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"2";s:6:"credit";s:0:"";s:6:"camera";s:9:"moto g(6)";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1589554659";s:9:"copyright";s:0:"";s:12:"focal_length";s:5:"3.519";s:3:"iso";s:4:"1381";s:13:"shutter_speed";s:17:"0.071428571428571";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1077, 218, '_edit_last', '3'),
(1078, 218, 'board_member_title', ''),
(1079, 218, '_board_member_title', 'field_61677496eb69b'),
(1080, 218, 'secondary_title', ''),
(1081, 218, '_secondary_title', 'field_61677442eb69a'),
(1082, 218, 'bio', 'Admitted as a Member of the Order of Australia for his ‘…significant contribution to the building and construction industry as a leader and educator’  – promulgated by HE the Governor-General in the Commonwealth Government Gazette, QB 2014.\r\n\r\nElected a Fellow of the Royal Society of New South Wales (Est 1821, Royal Assent 1866, Act of Parliament 1881) – promulgated by HE the Governor of NSW in the NSW Government Gazette, 6 Feb 2018.\r\n\r\nAwarded a Doctor of Construction Management Honoris Causa by Central Queensland University (CQUniversity), announced 2020.\r\n\r\nA building and construction management graduate of UTS (1988) from where he also acquired post graduate qualifications in education, Robert remains actively Licensed  as a Class A Builder in the Australian Capital Territory (ACT, No.: 2015713) where he also holds a dormant license as a Principal Building Surveyor. He is also an accredited Quantity Surveyor and Building Economist – being also accredited in all these disciplines at Level 1 on the National Building Professionals Register (NBPR).\r\n\r\nHe served seven years on the Discipline Committee of the New South Wales’ Building Professionals Board – that State’s regulator of Building Surveyors and Certifying Engineers. Robert has also been extensively involved in the formulation of legislation and regulation affecting the construction industry in that State (including the 205 Building Professionals Board Act and most recently both the Strata Defects Inspection regime and the regulations for the Building Designers and Practitioners Act), needless to say he is registered to carry out Strata Defects Inspections in that State.\r\n\r\nHe is a member of the industry advisory committees for construction and project management, quantity surveying and building surveying (inc. fire engineering) at all of the above (where applicable) and at CQUniversity – and has provided formal advice to Massey University.'),
(1083, 218, '_bio', 'field_61677623eb6a1'),
(1084, 218, 'board_member_image', '219'),
(1085, 218, '_board_member_image', 'field_61677737eb6a6'),
(1086, 218, 'professional_affiliations_0_role', 'Director of Research and Education Foundation Trust'),
(1087, 218, '_professional_affiliations_0_role', 'field_61677510eb69d'),
(1088, 218, 'professional_affiliations_0_professional_body', 'REFT'),
(1089, 218, '_professional_affiliations_0_professional_body', 'field_6167753aeb69e'),
(1090, 218, 'professional_affiliations_0_pro_start_year', ''),
(1091, 218, '_professional_affiliations_0_pro_start_year', 'field_6167754beb69f'),
(1092, 218, 'professional_affiliations_1_role', 'Director of Research and Education Foundation Trust'),
(1093, 218, '_professional_affiliations_1_role', 'field_61677510eb69d'),
(1094, 218, 'professional_affiliations_1_professional_body', 'The College of Building'),
(1095, 218, '_professional_affiliations_1_professional_body', 'field_6167753aeb69e'),
(1096, 218, 'professional_affiliations_1_pro_start_year', ''),
(1097, 218, '_professional_affiliations_1_pro_start_year', 'field_6167754beb69f'),
(1098, 218, 'professional_affiliations_2_role', 'Director of Research and Education Foundation Trust'),
(1099, 218, '_professional_affiliations_2_role', 'field_61677510eb69d'),
(1100, 218, 'professional_affiliations_2_professional_body', 'The Australian Institute of Building (AIB, Incorporated by Royal Charter)'),
(1101, 218, '_professional_affiliations_2_professional_body', 'field_6167753aeb69e'),
(1102, 218, 'professional_affiliations_2_pro_start_year', ''),
(1103, 218, '_professional_affiliations_2_pro_start_year', 'field_6167754beb69f'),
(1104, 218, 'professional_affiliations_3_role', 'Current Director and Past Chair'),
(1105, 218, '_professional_affiliations_3_role', 'field_61677510eb69d'),
(1106, 218, 'professional_affiliations_3_professional_body', 'the National Building Professionals Register'),
(1107, 218, '_professional_affiliations_3_professional_body', 'field_6167753aeb69e') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1108, 218, 'professional_affiliations_3_pro_start_year', ''),
(1109, 218, '_professional_affiliations_3_pro_start_year', 'field_6167754beb69f'),
(1110, 218, 'professional_affiliations_4_role', 'Past Director and Past Deputy Chair'),
(1111, 218, '_professional_affiliations_4_role', 'field_61677510eb69d'),
(1112, 218, 'professional_affiliations_4_professional_body', 'Centre for Best Practice of Building Construction – the forerunner of the IBQC'),
(1113, 218, '_professional_affiliations_4_professional_body', 'field_6167753aeb69e'),
(1114, 218, 'professional_affiliations_4_pro_start_year', ''),
(1115, 218, '_professional_affiliations_4_pro_start_year', 'field_6167754beb69f'),
(1116, 218, 'professional_affiliations_5_role', 'Past National President'),
(1117, 218, '_professional_affiliations_5_role', 'field_61677510eb69d'),
(1118, 218, 'professional_affiliations_5_professional_body', 'The Australian Institute of Building'),
(1119, 218, '_professional_affiliations_5_professional_body', 'field_6167753aeb69e'),
(1120, 218, 'professional_affiliations_5_pro_start_year', ''),
(1121, 218, '_professional_affiliations_5_pro_start_year', 'field_6167754beb69f'),
(1122, 218, 'professional_affiliations_6_role', 'Past Chapter President'),
(1123, 218, '_professional_affiliations_6_role', 'field_61677510eb69d'),
(1124, 218, 'professional_affiliations_6_professional_body', 'ACT/NSW'),
(1125, 218, '_professional_affiliations_6_professional_body', 'field_6167753aeb69e'),
(1126, 218, 'professional_affiliations_6_pro_start_year', ''),
(1127, 218, '_professional_affiliations_6_pro_start_year', 'field_6167754beb69f'),
(1128, 218, 'professional_affiliations_7_role', 'Fellow'),
(1129, 218, '_professional_affiliations_7_role', 'field_61677510eb69d'),
(1130, 218, 'professional_affiliations_7_professional_body', 'The Australian Institute of Building '),
(1131, 218, '_professional_affiliations_7_professional_body', 'field_6167753aeb69e'),
(1132, 218, 'professional_affiliations_7_pro_start_year', ''),
(1133, 218, '_professional_affiliations_7_pro_start_year', 'field_6167754beb69f'),
(1134, 218, 'professional_affiliations_8_role', 'Fellow'),
(1135, 218, '_professional_affiliations_8_role', 'field_61677510eb69d'),
(1136, 218, 'professional_affiliations_8_professional_body', 'The New Zealand Institute of Building'),
(1137, 218, '_professional_affiliations_8_professional_body', 'field_6167753aeb69e'),
(1138, 218, 'professional_affiliations_8_pro_start_year', ''),
(1139, 218, '_professional_affiliations_8_pro_start_year', 'field_6167754beb69f'),
(1140, 218, 'professional_affiliations_9_role', 'Fellow'),
(1141, 218, '_professional_affiliations_9_role', 'field_61677510eb69d'),
(1142, 218, 'professional_affiliations_9_professional_body', 'The Australian Institute of Quantity Surveyors'),
(1143, 218, '_professional_affiliations_9_professional_body', 'field_6167753aeb69e'),
(1144, 218, 'professional_affiliations_9_pro_start_year', ''),
(1145, 218, '_professional_affiliations_9_pro_start_year', 'field_6167754beb69f'),
(1146, 218, 'professional_affiliations_10_role', 'Companion'),
(1147, 218, '_professional_affiliations_10_role', 'field_61677510eb69d'),
(1148, 218, 'professional_affiliations_10_professional_body', 'Engineers Australia'),
(1149, 218, '_professional_affiliations_10_professional_body', 'field_6167753aeb69e'),
(1150, 218, 'professional_affiliations_10_pro_start_year', ''),
(1151, 218, '_professional_affiliations_10_pro_start_year', 'field_6167754beb69f'),
(1152, 218, 'professional_affiliations_11_role', 'Member '),
(1153, 218, '_professional_affiliations_11_role', 'field_61677510eb69d'),
(1154, 218, 'professional_affiliations_11_professional_body', 'The Australian Institute of Building Surveyors'),
(1155, 218, '_professional_affiliations_11_professional_body', 'field_6167753aeb69e'),
(1156, 218, 'professional_affiliations_11_pro_start_year', ''),
(1157, 218, '_professional_affiliations_11_pro_start_year', 'field_6167754beb69f'),
(1158, 218, 'professional_affiliations_12_role', 'Professor of Practice'),
(1159, 218, '_professional_affiliations_12_role', 'field_61677510eb69d'),
(1160, 218, 'professional_affiliations_12_professional_body', 'University of Newcastle'),
(1161, 218, '_professional_affiliations_12_professional_body', 'field_6167753aeb69e'),
(1162, 218, 'professional_affiliations_12_pro_start_year', ''),
(1163, 218, '_professional_affiliations_12_pro_start_year', 'field_6167754beb69f'),
(1164, 218, 'professional_affiliations_13_role', 'Adjunct Professor'),
(1165, 218, '_professional_affiliations_13_role', 'field_61677510eb69d'),
(1166, 218, 'professional_affiliations_13_professional_body', 'University of Canberra'),
(1167, 218, '_professional_affiliations_13_professional_body', 'field_6167753aeb69e'),
(1168, 218, 'professional_affiliations_13_pro_start_year', ''),
(1169, 218, '_professional_affiliations_13_pro_start_year', 'field_6167754beb69f'),
(1170, 218, 'professional_affiliations_14_role', 'Adjunct Professor'),
(1171, 218, '_professional_affiliations_14_role', 'field_61677510eb69d'),
(1172, 218, 'professional_affiliations_14_professional_body', 'Western Sydney University'),
(1173, 218, '_professional_affiliations_14_professional_body', 'field_6167753aeb69e'),
(1174, 218, 'professional_affiliations_14_pro_start_year', ''),
(1175, 218, '_professional_affiliations_14_pro_start_year', 'field_6167754beb69f'),
(1176, 218, 'professional_affiliations', '15'),
(1177, 218, '_professional_affiliations', 'field_61677500eb69c'),
(1178, 218, 'awards_0_award_title', 'Chapter Honour Award'),
(1179, 218, '_awards_0_award_title', 'field_61677660eb6a3'),
(1180, 218, 'awards_0_award_issuer', 'Australian Institute of Building New South Wales'),
(1181, 218, '_awards_0_award_issuer', 'field_61677669eb6a4'),
(1182, 218, 'awards_0_award_year', ''),
(1183, 218, '_awards_0_award_year', 'field_616776e2eb6a5'),
(1184, 218, 'awards', '1'),
(1185, 218, '_awards', 'field_61677654eb6a2'),
(1186, 220, '_edit_lock', '1634351821:1'),
(1187, 221, '_wp_attached_file', '2021/10/3.jpg'),
(1188, 221, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:150;s:6:"height";i:150;s:4:"file";s:13:"2021/10/3.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:13:"3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"4";s:6:"credit";s:0:"";s:6:"camera";s:11:"NIKON D3200";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1483296306";s:9:"copyright";s:0:"";s:12:"focal_length";s:2:"66";s:3:"iso";s:4:"2200";s:13:"shutter_speed";s:17:"0.016666666666667";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(1189, 220, '_edit_last', '1'),
(1190, 220, 'board_member_title', ''),
(1191, 220, '_board_member_title', 'field_61677496eb69b'),
(1192, 220, 'secondary_title', 'Director at Weir Legal and Consulting Pty Ltd'),
(1193, 220, '_secondary_title', 'field_61677442eb69a'),
(1194, 220, 'bio', 'Bronwyn is the co-author of the Building Confidence Report. Her appointment with Professor Shergold to undertake this work reflects her reputation as a legal advisor on building regulations for more than 20 years.\r\n\r\nBronwyn has been advising the NSW and WA governments on their implementation of the Building Confidence Report and she is also part of the Expert Advisory Group appointed to advise the ABCB on its work to develop a national framework for the implementation of the report.\r\n\r\nOther related work includes advising on the Vic Government’s response to combustible cladding and on security of payment reforms for the Queensland government. In addition to building regulation, Bronwyn has also advised regulators in many other sectors including human services, education and natural resources.'),
(1195, 220, '_bio', 'field_61677623eb6a1'),
(1196, 220, 'board_member_image', '221'),
(1197, 220, '_board_member_image', 'field_61677737eb6a6'),
(1198, 220, 'professional_affiliations', ''),
(1199, 220, '_professional_affiliations', 'field_61677500eb69c'),
(1200, 220, 'awards', ''),
(1201, 220, '_awards', 'field_61677654eb6a2'),
(1202, 222, '_edit_lock', '1634348829:3'),
(1203, 223, '_wp_attached_file', '2021/10/4.jpg'),
(1204, 223, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:221;s:6:"height";i:221;s:4:"file";s:13:"2021/10/4.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:13:"4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1587733439";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(1205, 222, '_edit_last', '3'),
(1206, 222, 'board_member_title', ''),
(1207, 222, '_board_member_title', 'field_61677496eb69b') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1208, 222, 'secondary_title', ''),
(1209, 222, '_secondary_title', 'field_61677442eb69a'),
(1210, 222, 'bio', 'Dominic Sims, CBO, is the Chief Executive Officer of the International Code Council. He was appointed to the position in 2012. As CEO, Sims is responsible for the overall activities and financial performance of the association, including its six subsidiaries.\r\n\r\nThe Code Council is a member-focused association dedicated to developing model codes and standards used in the design, build and compliance process to construct safe, affordable and resilient buildings. Every state in the U.S. and many global markets adopt the International Codes.\r\n\r\nDuring his 15-year tenure, Sims has also served the Code Council as Chief Operating Officer and Senior Vice President. He has served on and/or chaired numerous national Committees and Task Forces across a span of topics, including code development, government affairs and resiliency.\r\n\r\nPrior to his work with the Code Council, Sims served as the CEO of the Southern Building Code Congress International (SBCCI) and guided its consolidation between regional code organizations that formed the Code Council in 2003. Sims has served on the boards of SBCCI, the Federal Alliance for Safe Homes (FLASH) and several other professional associations. Before joining SBCCI, he was Executive Director of the Palm Beach County, Florida Planning, Zoning and Building Department, where he had responsibility for comprehensive development, construction, and licensing and compliance activities for a high-growth region in the United States.\r\n\r\nHaving worked in the building safety field since 1983, Sims has held numerous positions, both elected and appointed at the federal, state and local levels including the White House Panel on Seismic Safety, The Society for Standards Professionals (SES) Standards Committee and American National Standards Institute (ANSI) National Policy Committee.\r\n\r\nHis experience includes service as a Councilman/Vice Mayor for the town of Jupiter, Florida and Vice Chairman of the Governor’s Building Code Study Commission –which helped form his views on the importance of being active in public policy discussions concerning building safety.'),
(1211, 222, '_bio', 'field_61677623eb6a1'),
(1212, 222, 'board_member_image', '223'),
(1213, 222, '_board_member_image', 'field_61677737eb6a6'),
(1214, 222, 'professional_affiliations', ''),
(1215, 222, '_professional_affiliations', 'field_61677500eb69c'),
(1216, 222, 'awards', ''),
(1217, 222, '_awards', 'field_61677654eb6a2'),
(1218, 52, '_edit_last', '1'),
(1219, 224, '_edit_lock', '1634349045:3'),
(1220, 225, '_wp_attached_file', '2021/10/5.jpg'),
(1221, 225, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:150;s:6:"height";i:150;s:4:"file";s:13:"2021/10/5.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:13:"5-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"8";s:6:"credit";s:19:"Digital-Photo.co.uk";s:6:"camera";s:11:"NIKON D800E";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1453287916";s:9:"copyright";s:32:"Digital-Photo.co.uk 0845 5050911";s:12:"focal_length";s:2:"85";s:3:"iso";s:3:"400";s:13:"shutter_speed";s:4:"0.01";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(1222, 224, '_edit_last', '3'),
(1223, 224, 'board_member_title', ''),
(1224, 224, '_board_member_title', 'field_61677496eb69b'),
(1225, 224, 'secondary_title', ''),
(1226, 224, '_secondary_title', 'field_61677442eb69a'),
(1227, 224, 'bio', 'Dame Judith Hackitt is a chemical engineer and is currently Chair of Make UK, the manufacturers’ organisation formerly known as EEF. She is also Chair of Enginuity the UK skills body for Engineering and Manufacturing  formerly known as Semta and senior non-executive director of the High Value Manufacturing Catapult an organisation which exists to support and encourage innovation in Advanced Manufacturing. She is also a Board member of HS2 Ltd.\r\n\r\nDame Judith worked in the chemicals manufacturing industry for 23 years and then worked in an advocacy role for the sector at national and international level. Dame Judith became Chair of the UK Health and Safety Executive (HSE) in October 2007, until March 2016.\r\n\r\nShe was made a Dame in the 2015-16 New Year Honours for services to health and safety and engineering, in particular for being a role model for young women. She had previously been awarded a CBE in 2006 for services to the chemical industries. She was elected a Fellow of the Royal Academy of Engineering in 2010 and currently serves as a trustee of the Academy. She is also a Fellow of the Institution of Chemical Engineers and served as President of the Institution of Chemical Engineers (2013-14).  \r\n\r\nFollowing the tragic fire which occurred at Grenfell Tower in London in June 2017, Dame Judith conducted an independent review into Building Regulations and Fire Safety related to high rise buildings for the Government. She began her review in July 2017 and plans to implement her recommendations in full were announced in the Queen’s speech in October 2019. She now works as an adviser to Government  chairing the Industry Safety Steering Group holding industry to account to deliver the culture change needed and the Transition Board which is overseeing the setting up of the new Building Safety Regulator. She speaks and writes regularly on the need for industry to step up to its responsibilities for safety and quality.'),
(1228, 224, '_bio', 'field_61677623eb6a1'),
(1229, 224, 'board_member_image', '225'),
(1230, 224, '_board_member_image', 'field_61677737eb6a6'),
(1231, 224, 'professional_affiliations_0_role', 'Chair '),
(1232, 224, '_professional_affiliations_0_role', 'field_61677510eb69d'),
(1233, 224, 'professional_affiliations_0_professional_body', 'UK Health and Safety Executive'),
(1234, 224, '_professional_affiliations_0_professional_body', 'field_6167753aeb69e'),
(1235, 224, 'professional_affiliations_0_pro_start_year', ''),
(1236, 224, '_professional_affiliations_0_pro_start_year', 'field_6167754beb69f'),
(1237, 224, 'professional_affiliations', '1'),
(1238, 224, '_professional_affiliations', 'field_61677500eb69c'),
(1239, 224, 'awards', ''),
(1240, 224, '_awards', 'field_61677654eb6a2'),
(1241, 226, '_edit_lock', '1634351731:1'),
(1242, 227, '_wp_attached_file', '2021/10/6.png'),
(1243, 227, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:300;s:6:"height";i:300;s:4:"file";s:13:"2021/10/6.png";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:13:"6-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:13:"6-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1244, 226, '_edit_last', '1'),
(1245, 226, 'board_member_title', ''),
(1246, 226, '_board_member_title', 'field_61677496eb69b'),
(1247, 226, 'secondary_title', 'Director, Regulatory reform and Technical Standards | RESCON (Residental Construction of Ontario) | Consultant, World Bank (since 2007) | Director, Regulatory Reform and Technical Standards'),
(1248, 226, '_secondary_title', 'field_61677442eb69a'),
(1249, 226, 'bio', 'Extensive international experience in streamlining planning and building regulatory regimes.\r\n\r\nMichael is an experienced public policy professional familiar with the development and building regulatory issues in Ontario and internationally. He has worked as a project manager and adviser for many key Ontario Government initiatives related to the building regulatory system.\r\n\r\nLead author of a 2018 RESCON report on streamlining Ontario’s development and building approval process.\r\n\r\nPrepared reports for the World Bank on ways to streamline planning and building regulatory systems following missions to over 15 different countries.\r\n\r\nContributing author to two World Bank books. Presented papers at Society for Applied Anthropology Conferences in Pittsburgh and in Vancouver, on risk and resilience in developing countries.'),
(1250, 226, '_bio', 'field_61677623eb6a1'),
(1251, 226, 'board_member_image', '227'),
(1252, 226, '_board_member_image', 'field_61677737eb6a6'),
(1253, 226, 'professional_affiliations_0_role', 'Past Senior Consultant'),
(1254, 226, '_professional_affiliations_0_role', 'field_61677510eb69d'),
(1255, 226, 'professional_affiliations_0_professional_body', 'World Bank Group'),
(1256, 226, '_professional_affiliations_0_professional_body', 'field_6167753aeb69e'),
(1257, 226, 'professional_affiliations_0_pro_start_year', ''),
(1258, 226, '_professional_affiliations_0_pro_start_year', 'field_6167754beb69f'),
(1259, 226, 'professional_affiliations_1_role', 'Professional Land Economist'),
(1260, 226, '_professional_affiliations_1_role', 'field_61677510eb69d'),
(1261, 226, 'professional_affiliations_1_professional_body', 'Ontario Association of Land Economists'),
(1262, 226, '_professional_affiliations_1_professional_body', 'field_6167753aeb69e'),
(1263, 226, 'professional_affiliations_1_pro_start_year', ''),
(1264, 226, '_professional_affiliations_1_pro_start_year', 'field_6167754beb69f'),
(1265, 226, 'professional_affiliations_2_role', 'Panel Member'),
(1266, 226, '_professional_affiliations_2_role', 'field_61677510eb69d'),
(1267, 226, 'professional_affiliations_2_professional_body', 'Centre for Best Practice Building Control (CBPBC), Melbourne, Australia'),
(1268, 226, '_professional_affiliations_2_professional_body', 'field_6167753aeb69e'),
(1269, 226, 'professional_affiliations_2_pro_start_year', ''),
(1270, 226, '_professional_affiliations_2_pro_start_year', 'field_6167754beb69f'),
(1271, 226, 'professional_affiliations_3_role', 'Member'),
(1272, 226, '_professional_affiliations_3_role', 'field_61677510eb69d'),
(1273, 226, 'professional_affiliations_3_professional_body', 'Association of Ontario Land Economists'),
(1274, 226, '_professional_affiliations_3_professional_body', 'field_6167753aeb69e'),
(1275, 226, 'professional_affiliations_3_pro_start_year', ''),
(1276, 226, '_professional_affiliations_3_pro_start_year', 'field_6167754beb69f'),
(1277, 226, 'professional_affiliations', '4'),
(1278, 226, '_professional_affiliations', 'field_61677500eb69c'),
(1279, 226, 'awards_0_award_title', 'Bill Davis Ontario Merit Award'),
(1280, 226, '_awards_0_award_title', 'field_61677660eb6a3'),
(1281, 226, 'awards_0_award_issuer', 'Ontario Building Officials Association'),
(1282, 226, '_awards_0_award_issuer', 'field_61677669eb6a4'),
(1283, 226, 'awards_0_award_year', ''),
(1284, 226, '_awards_0_award_year', 'field_616776e2eb6a5'),
(1285, 226, 'awards_1_award_title', 'Leadership Award'),
(1286, 226, '_awards_1_award_title', 'field_61677660eb6a3'),
(1287, 226, 'awards_1_award_issuer', 'Reach for Excellence, Ministry of Municipal Affairs and Housing'),
(1288, 226, '_awards_1_award_issuer', 'field_61677669eb6a4'),
(1289, 226, 'awards_1_award_year', ''),
(1290, 226, '_awards_1_award_year', 'field_616776e2eb6a5'),
(1291, 226, 'awards', '2'),
(1292, 226, '_awards', 'field_61677654eb6a2'),
(1293, 228, '_edit_lock', '1634351779:1'),
(1294, 229, '_wp_attached_file', '2021/10/7.png'),
(1295, 229, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:150;s:6:"height";i:150;s:4:"file";s:13:"2021/10/7.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:13:"7-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1296, 228, '_edit_last', '1'),
(1297, 228, 'board_member_title', ''),
(1298, 228, '_board_member_title', 'field_61677496eb69b'),
(1299, 228, 'secondary_title', 'Chief Executive Officer, The Australian Building Codes Board'),
(1300, 228, '_secondary_title', 'field_61677442eb69a'),
(1301, 228, 'bio', 'As Chief Executive of the Australian Building Codes Board, championed improved access, awareness and understanding of the National Construction Code to help improve compliance and lift productivity.\r\n\r\nAs past Deputy Commissioner of the Victorian Building and Plumbing Industry Commissions, where he was involved in developing a number of reforms resulting in the establishment of the Victorian Building Authority.\r\n\r\nFor eight years served as the inaugural Chief Planning Executive for the ACT Planning & Land Authority where he was responsible for building and plumbing control, as well as designed and implemented what at the time were the most comprehensive planning reforms in the country.\r\n\r\nPast Executive Director of Planning SA, where he developed significant reforms to land use planning and before that he was the Director of City Planning and Special Projects at the City of Greater Geelong, where he oversaw the redevelopment of that city’s waterfront and CBD.\r\n\r\nHolds qualifications in town planning, urban design and ecologically sustainable development, is a Registered Planner and a Graduate of the Australian Institute of Company Directors.'),
(1302, 228, '_bio', 'field_61677623eb6a1'),
(1303, 228, 'board_member_image', '229'),
(1304, 228, '_board_member_image', 'field_61677737eb6a6'),
(1305, 228, 'professional_affiliations', ''),
(1306, 228, '_professional_affiliations', 'field_61677500eb69c'),
(1307, 228, 'awards', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1308, 228, '_awards', 'field_61677654eb6a2'),
(1309, 230, '_edit_lock', '1634351803:1'),
(1310, 231, '_wp_attached_file', '2021/10/8.jpg'),
(1311, 231, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:150;s:6:"height";i:150;s:4:"file";s:13:"2021/10/8.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:13:"8-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(1312, 230, '_edit_last', '1'),
(1313, 230, 'board_member_title', ''),
(1314, 230, '_board_member_title', 'field_61677496eb69b'),
(1315, 230, 'secondary_title', 'Senior Private Sector Specialist, The World Bank'),
(1316, 230, '_secondary_title', 'field_61677442eb69a'),
(1317, 230, 'bio', 'Alejandro Espinosa-Wang is a private sector development specialist. Alejandro joined the World Bank Group in 2006.\r\n\r\nHe currently works with the Trade and Competitiveness global practice. Before joining Trade and Competitiveness he worked in the Doing Business team where he led the research group for the indicators on dealing with construction permits. Espinosa-Wang also worked as a research assistant at the Inter-American Development Bank in Washington, D.C.\r\n\r\nEspinosa holds a degree in government and international relations from the Universidad Externado de Colombia, a certificate in economic policy from American University, and a master’s degree in applied economics from Johns Hopkins University.'),
(1318, 230, '_bio', 'field_61677623eb6a1'),
(1319, 230, 'board_member_image', '231'),
(1320, 230, '_board_member_image', 'field_61677737eb6a6'),
(1321, 230, 'professional_affiliations', ''),
(1322, 230, '_professional_affiliations', 'field_61677500eb69c'),
(1323, 230, 'awards', ''),
(1324, 230, '_awards', 'field_61677654eb6a2'),
(1325, 232, '_edit_lock', '1634349407:3'),
(1326, 233, '_wp_attached_file', '2021/10/9.png'),
(1327, 233, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:300;s:6:"height";i:300;s:4:"file";s:13:"2021/10/9.png";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:13:"9-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:13:"9-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1328, 232, '_edit_last', '3'),
(1329, 232, 'board_member_title', ''),
(1330, 232, '_board_member_title', 'field_61677496eb69b'),
(1331, 232, 'secondary_title', ''),
(1332, 232, '_secondary_title', 'field_61677442eb69a'),
(1333, 232, 'bio', 'Professor José L. Torero is Professor Civil Engineering and Head of the Department of Civil, Environmental and Geomatic Engineering at University College London. He works in the fields of safety, environmental remediation and sanitation where he specializes in complex environments such as developing nations, complex urban environments, novel architectures, critical infrastructure, aircraft and spacecraft. He holds a BSc for the Pontificia Universidad Católica del Perú (1989), and an MSc (1991) and PhD (1992) from the University of California, Berkeley. He received a Doctor Honoris Causa by Ghent University (Belgium) in 2016. José is a Chartered Engineer (UK), a Registered Professional Engineer in Queensland, a fellow of the Australian Academy of Technological Sciences and Engineering, the Royal Academy of Engineering (UK), the Royal Society of Edinburgh (UK), the Queensland Academy of Arts and Sciences (Australia), the Institution of Civil Engineers (UK), the Institution of Fire Engineers (UK), the Society of Fire Protection Engineers (USA), the Combustion Institute (USA) and the Royal Society of New South Wales (Australia).'),
(1334, 232, '_bio', 'field_61677623eb6a1'),
(1335, 232, 'board_member_image', '233'),
(1336, 232, '_board_member_image', 'field_61677737eb6a6'),
(1337, 232, 'professional_affiliations', ''),
(1338, 232, '_professional_affiliations', 'field_61677500eb69c'),
(1339, 232, 'awards', ''),
(1340, 232, '_awards', 'field_61677654eb6a2'),
(1341, 234, '_edit_lock', '1634349441:3'),
(1342, 235, '_wp_attached_file', '2021/10/10.png'),
(1343, 235, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:150;s:6:"height";i:150;s:4:"file";s:14:"2021/10/10.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:14:"10-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1344, 234, '_edit_last', '3'),
(1345, 234, 'board_member_title', ''),
(1346, 234, '_board_member_title', 'field_61677496eb69b'),
(1347, 234, 'secondary_title', ''),
(1348, 234, '_secondary_title', 'field_61677442eb69a'),
(1349, 234, 'bio', 'Stephanie Barwise QC is a preeminent UK-based silk. Her practice comprises construction, civil and geotechnical engineering involving landslip/subsidence and augured/bored piles, mechanical and electrical engineering and infrastructure projects including roads, bridges, mass transit railroads, on and off shore refineries and biofuels plants, ship building and refits, wind farms, IT problems in computer automated cranes and trains, and procurement including major PFI projects such as hospitals and schools. Her practice also extends to military equipment such as man-portable, automated bomb diffusing equipment, battleships and nuclear bunkers.\r\n\r\nAmongst the first of the 1988 call to take silk, Stephanie has been consistently recognised as a leader in her field in legal directories such as Chambers and Partners UK Bar Guide and The Legal 500. Stephanie won “Construction Set of the Year” in the Chambers and Partners UK Bar Awards 2019 and was included in The Lawyer’s ‘Hot 100’ list for 2019.\r\n\r\nStephanie appeared for the manufacturer of both trains and the signal in the Ladbroke Grove Rail Inquiry. She is currently representing the larger of the two groups of victims (survivors, bereaved relatives and former residents of Grenfell Tower) in The Grenfell Tower Public Inquiry, a group represented by three firms of solicitors.\r\n\r\nStephanie has represented the UK government and foreign governments, as well as a wide variety of other clients in high-value and complex claims. '),
(1350, 234, '_bio', 'field_61677623eb6a1'),
(1351, 234, 'board_member_image', '235'),
(1352, 234, '_board_member_image', 'field_61677737eb6a6'),
(1353, 234, 'professional_affiliations', ''),
(1354, 234, '_professional_affiliations', 'field_61677500eb69c'),
(1355, 234, 'awards', ''),
(1356, 234, '_awards', 'field_61677654eb6a2'),
(1357, 236, '_edit_lock', '1634351839:1'),
(1358, 237, '_wp_attached_file', '2021/10/11.jpg'),
(1359, 237, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:150;s:6:"height";i:150;s:4:"file";s:14:"2021/10/11.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:14:"11-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1360, 236, '_edit_last', '1'),
(1361, 236, 'board_member_title', ''),
(1362, 236, '_board_member_title', 'field_61677496eb69b'),
(1363, 236, 'secondary_title', 'Chief Executive Officer, EcoBuild Africa'),
(1364, 236, '_secondary_title', 'field_61677442eb69a'),
(1365, 236, 'bio', 'Arch. Prof. Alfred Omenya is a practicing architect and sustainable human settlements expert. He is the Principal Researcher and CEO at Eco-Build Africa, a leading consultancy on sustainable urban development for developing countries. He has been Associate Professor and Head of School of the Built Environment at the Technical University of Kenya. He previously taught at the University of the Witwatersrand (RSA) and the University of Nairobi (Kenya) where he still serves as external examiner. He has supervised numerous Masters and PhD students. He helped establish schools of the built environment in Rwanda, Malawi and South Africa. He has published over 100 academic papers and remains external examiner in various universities. He collaborates with leading universities globally in research including the Harvard Graduate School, ETH Zurich, University of Manchester (UK), University of Florida (Gainesville US) among others.\r\n\r\nHe started professional practice at Planning Systems Services (Kenya) and also worked with Sync Consult Pty (South Africa). He has designed hundreds of commercial, residential and hospitality projects in Kenya, Uganda and a few in South Africa. He was the lead consultant for the New Green Master plan for United Nations Headquarters in Nairobi, Kenya and was identified by the International Union of Architects as a major opinion shaper on the future of sustainable architecture. Prof. Omenya was also lead author for the African Union Vision 2063 on Urban Development.\r\n\r\nOmenya has consulted for international organisations including: the World Bank, African Union, UNEP, UK-Aid / DfID, Oxfam GB, Sida, etc. He was lead author of the UN-Habitat’s State of African Cities Report series for many years. He co-authored “the Definition of Housing Terms for the Republic of South Africa”, “Guidelines for County Spatial Planning for the Republic of Kenya”, and “the African Union Climate Change Strategy”. In 2018 and 2019 he published two research reports on the State of Housing in Kenya. He is currently the lead consultant in development of Building Regulations incorporating Sustainability, Climate Change and Disaster Risk Management for the Republic of Malawi, the Islamic Republic of Afghanistan and Republic of Uganda. Locally Prof. Omenya is supporting the Kenya Urban Support Programme (KUSP), the Sustainable Urban Economic Development Programme for Kenya (SUED) and the Programme Management Office for Post-Covid 19 Recovery.'),
(1366, 236, '_bio', 'field_61677623eb6a1'),
(1367, 236, 'board_member_image', '237'),
(1368, 236, '_board_member_image', 'field_61677737eb6a6'),
(1369, 236, 'professional_affiliations', ''),
(1370, 236, '_professional_affiliations', 'field_61677500eb69c'),
(1371, 236, 'awards', ''),
(1372, 236, '_awards', 'field_61677654eb6a2'),
(1373, 239, '_edit_lock', '1634364063:1'),
(1374, 239, '_edit_last', '1'),
(1375, 242, '_edit_lock', '1634366616:1'),
(1376, 244, '_edit_lock', '1634419993:1'),
(1377, 244, '_edit_last', '1'),
(1378, 244, 'news_content', 'In the final episode of Season 3 of the ICC Pulse Podcast, Judy Zakreski, Code Council Vice President of Global Services talks with Professor Kim Lovegrove and Professor Alfred Omenya on the newly-released Good Practice Guidelines and Principles for the Development of Building Regulations in Low Income Countries. '),
(1379, 244, '_news_content', 'field_616a522d8aa14'),
(1380, 244, 'news_post_title_image', '89'),
(1381, 244, '_news_post_title_image', 'field_616a52c250180'),
(1382, 244, 'clickable_link_button_0_button_details', 'Listen Here: Episode 42'),
(1383, 244, '_clickable_link_button_0_button_details', 'field_616a5446ebc92'),
(1384, 244, 'clickable_link_button_0_url', 'https://iccpulsepodcast.libsyn.com/episode-42-international-building-quality-centre-ibqc-guidelines-for-developing-countries'),
(1385, 244, '_clickable_link_button_0_url', 'field_616a5478ebc93'),
(1386, 244, 'clickable_link_button', '1'),
(1387, 244, '_clickable_link_button', 'field_616a53a9ebc91'),
(1388, 244, 'clickable_link_button_0_button_text', 'Listen Here: Episode 42'),
(1389, 244, '_clickable_link_button_0_button_text', 'field_616a5446ebc92'),
(1396, 242, '_wp_page_template', 'news.php'),
(1399, 11, '_edit_last', '2') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=262 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(3, 1, '2021-09-11 10:11:29', '2021-09-11 10:11:29', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Our website address is: http://dev.sockbrew.design.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymised string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognise and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2021-09-11 10:11:29', '2021-09-11 10:11:29', '', 0, 'http://dev.sockbrew.design/?page_id=3', 0, 'page', '', 0),
(8, 3, '2021-09-20 14:37:16', '2021-09-20 04:37:16', '<!-- wp:cover {"url":"https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png","id":83,"minHeight":600} -->\n<div class="wp-block-cover has-background-dim" style="min-height:600px"><img class="wp-block-cover__image-background wp-image-83" alt="" src="https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"60px"}}} -->\n<p class="has-text-align-center" style="font-size:60px"> Welcome to the IBQC </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {"align":"center","placeholder":"Write title…","fontSize":"medium"} -->\n<p class="has-text-align-center has-medium-font-size"> A pre-eminent International Centre of Excellence in terms of the identification of building regulatory systems and regimes that are international exemplars. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:buttons {"contentJustification":"center"} -->\n<div class="wp-block-buttons is-content-justification-center"><!-- wp:button {"className":"is-style-outline"} -->\n<div class="wp-block-button is-style-outline"><a class="wp-block-button__link" href="/about-ibqc/">Find out more</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons --></div></div>\n<!-- /wp:cover -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2021-10-16 17:33:04', '2021-10-16 07:33:04', '', 0, 'https://dev.sockbrew.design/?page_id=8', 0, 'page', '', 0),
(9, 3, '2021-09-20 14:37:11', '2021-09-20 04:37:11', '', 'podcast', '', 'inherit', 'open', 'closed', '', 'podcast', '', '', '2021-09-20 14:37:11', '2021-09-20 04:37:11', '', 8, 'https://dev.sockbrew.design/wp-content/uploads/2021/09/podcast.png', 0, 'attachment', 'image/png', 0),
(10, 3, '2021-09-20 14:37:16', '2021-09-20 04:37:16', '<!-- wp:paragraph {"fontSize":"huge"} -->\n<p class="has-huge-font-size">Welcome to the IBQC</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>A pre-eminent International Centre of Excellence in terms of the identification of building regulatory systems and regimes that are international exemplars.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {"fontSize":"extra-large"} -->\n<p class="has-extra-large-font-size">Latest news</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {"fontSize":"large"} -->\n<p class="has-large-font-size">ICC Pulse Podcast Episode 42: International Building Quality Centre (IBQC) Guidelines for Developing Countries</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>In the final episode of Season 3 of the ICC Pulse Podcast, Judy Zakreski, Code Council Vice President of Global Services talks with Professor Kim Lovegrove and Professor Alfred Omenya on the newly-released Good Practice Guidelines and Principles for the Development of Building Regulations in Low Income Countries.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"id":9,"sizeSlug":"full","linkDestination":"none"} -->\n<figure class="wp-block-image size-full"><img src="https://dev.sockbrew.design/wp-content/uploads/2021/09/podcast.png" alt="" class="wp-image-9"/></figure>\n<!-- /wp:image -->', 'Home', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2021-09-20 14:37:16', '2021-09-20 04:37:16', '', 8, 'https://dev.sockbrew.design/?p=10', 0, 'revision', '', 0),
(11, 3, '2021-09-20 14:41:16', '2021-09-20 04:41:16', '<!-- wp:columns -->\n<div class="wp-block-columns"><!-- wp:column -->\n<div class="wp-block-column"><!-- wp:paragraph -->\n<p> The motivation for the establishment of the IBQC was founded on the recognition that many jurisdictions in recent times have been visited with tremendous challenges on account of building regulations that have not delivered the level of safety and security expected by the public.<br><br>Indeed, there have been regulatory failures that have culminated in the loss of life along with seriously deleterious economic impacts upon citizens.<br><br>These challenges have culminated in recognition by industry stakeholders that a rethinking of the philosophies and traditions that underpin the design of modern-day building control is both timely and necessary.<br><br>The IBQC serves as a collaborative medium through which systems, practices, regulations, codes and laws that provide best practice solutions and answers are identified, endorsed and encouraged. </p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class="wp-block-column"><!-- wp:image {"align":"center","id":99,"sizeSlug":"full","linkDestination":"none"} -->\n<div class="wp-block-image"><figure class="aligncenter size-full"><img src="https://dev.sockbrew.design/wp-content/uploads/2021/10/construction-silhouette-1024x684-1.jpg" alt="" class="wp-image-99"/></figure></div>\n<!-- /wp:image --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->\n\n<!-- wp:columns -->\n<div class="wp-block-columns"><!-- wp:column -->\n<div class="wp-block-column"><!-- wp:image {"align":"center","id":100,"sizeSlug":"full","linkDestination":"none"} -->\n<div class="wp-block-image"><figure class="aligncenter size-full"><img src="https://dev.sockbrew.design/wp-content/uploads/2021/10/construction-worker-truss-installation-1024x684-1.jpg" alt="" class="wp-image-100"/></figure></div>\n<!-- /wp:image --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class="wp-block-column"><!-- wp:paragraph -->\n<p> The IBQC will also, through research and comparative analysis, benchmark and identify jurisdictions that have pioneered and implemented best practice and emerging construction technology, probity regimes and enlightened construction systems and practices. In doing so, it will have regard to that which is best for the present and that which is best for the future.<br><br>As the IBQC will be hosted by the University of Canberra, there will exist the opportunity for students to avail themselves of the resources of the Centre with a view to carrying out further research on best practice regulatory ecology and establishing postgraduate study pathways.<br><br>The IBQC has developed an online library that continues to evolve into a compilation of best practice research publications and papers to generate a resource for students, law reformers, policymakers, practitioners and academics.<br><br>The IBQC aspires to become a sounding board providing an opinion on the viability of regulatory initiatives in terms of their benchmarking with best-practice research on point. </p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2021-10-16 22:34:50', '2021-10-16 12:34:50', '', 0, 'https://dev.sockbrew.design/?page_id=11', 0, 'page', '', 0),
(12, 3, '2021-09-20 14:40:36', '2021-09-20 04:40:36', '', 'construction silhouette', 'construction silhouette', 'inherit', 'open', 'closed', '', 'construction-silhouette', '', '', '2021-09-20 14:40:36', '2021-09-20 04:40:36', '', 11, 'https://dev.sockbrew.design/wp-content/uploads/2021/09/construction-silhouette.jpg', 0, 'attachment', 'image/jpeg', 0),
(13, 3, '2021-09-20 14:41:04', '2021-09-20 04:41:04', '', 'Construction worker truss installation', 'Construction worker truss installation', 'inherit', 'open', 'closed', '', 'construction-worker-truss-installation', '', '', '2021-09-20 14:41:04', '2021-09-20 04:41:04', '', 11, 'https://dev.sockbrew.design/wp-content/uploads/2021/09/construction-worker-truss-installation.jpg', 0, 'attachment', 'image/jpeg', 0),
(14, 3, '2021-09-20 14:41:16', '2021-09-20 04:41:16', '<!-- wp:paragraph -->\n<p>The motivation for the establishment of the IBQC was founded on the recognition that many jurisdictions in recent times have been visited with tremendous challenges on account of building regulations that have not delivered the level of safety and security expected by the public.<br><br>Indeed, there have been regulatory failures that have culminated in the loss of life along with seriously deleterious economic impacts upon citizens.<br><br>These challenges have culminated in recognition by industry stakeholders that a rethinking of the philosophies and traditions that underpin the design of modern-day building control is both timely and necessary.<br><br>The IBQC serves as a collaborative medium through which systems, practices, regulations, codes and laws that provide best practice solutions and answers are identified, endorsed and encouraged.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"id":12,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="https://dev.sockbrew.design/wp-content/uploads/2021/09/construction-silhouette-1024x684.jpg" alt="" class="wp-image-12"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image {"id":13,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="https://dev.sockbrew.design/wp-content/uploads/2021/09/construction-worker-truss-installation-1024x684.jpg" alt="" class="wp-image-13"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>The IBQC will also, through research and comparative analysis, benchmark and identify jurisdictions that have pioneered and implemented best practice and emerging construction technology, probity regimes and enlightened construction systems and practices. In doing so, it will have regard to that which is best for the present and that which is best for the future.<br><br>As the IBQC will be hosted by the University of Canberra, there will exist the opportunity for students to avail themselves of the resources of the Centre with a view to carrying out further research on best practice regulatory ecology and establishing postgraduate study pathways.<br><br>The IBQC has developed an online library that continues to evolve into a compilation of best practice research publications and papers to generate a resource for students, law reformers, policymakers, practitioners and academics.<br><br>The IBQC aspires to become a sounding board providing an opinion on the viability of regulatory initiatives in terms of their benchmarking with best-practice research on point.</p>\n<!-- /wp:paragraph -->', 'About IBQC', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2021-09-20 14:41:16', '2021-09-20 04:41:16', '', 11, 'https://dev.sockbrew.design/?p=14', 0, 'revision', '', 0),
(16, 3, '2021-09-20 14:52:01', '2021-09-20 04:52:01', '<!-- wp:quote {"className":"is-style-large"} -->\n<blockquote class="wp-block-quote is-style-large"><p>To establish a pre-eminent International Centre of Excellence in terms of the identification of building regulatory systems and regimes that are international exemplars.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:separator {"customColor":"#84a7b5","className":"is-style-wide"} -->\n<hr class="wp-block-separator has-text-color has-background is-style-wide" style="background-color:#84a7b5;color:#84a7b5"/>\n<!-- /wp:separator -->\n\n<!-- wp:paragraph -->\n<p>To be a sounding board or point of reference for law reformers, policymakers and stakeholders intent on designing building regulation that provides the greatest opportunity for the realisation of codes and laws that maximise:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li>Public safety;</li><li>Cost-effective and efficient construction systems; and</li><li>Sustainability within the context of the built environment.</li></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>The IBQC will also pave the way for students, who are intent on developing expertise in best practice construction regulation, practices and systems, to embark upon postgraduate studies on point.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The IBQC will be a medium through which comparative analyses can be applied to reforming jurisdictions to enable the potential client to have concepts peer-reviewed.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>This will provide the University of Canberra with the opportunity of commissioning research on point, albeit such research will be remunerative for the University.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The paramount vision being that, through its research and its members, the IBQC will have a positive and material impact on building regulation and practices in Australia and jurisdictions across the world.</p>\n<!-- /wp:paragraph -->', 'Vision', '', 'publish', 'closed', 'closed', '', 'vision', '', '', '2021-10-16 09:50:40', '2021-10-15 23:50:40', '', 0, 'https://dev.sockbrew.design/?page_id=16', 0, 'page', '', 0),
(17, 3, '2021-09-20 14:51:52', '2021-09-20 04:51:52', '', 'View of modern business skyscrapers glass and sky view landscape', 'View of modern business skyscrapers glass and sky view landscape of commercial building in central city', 'inherit', 'open', 'closed', '', 'view-of-modern-business-skyscrapers-glass-and-sky-view-landscape', '', '', '2021-09-20 14:51:52', '2021-09-20 04:51:52', '', 16, 'https://dev.sockbrew.design/wp-content/uploads/2021/09/view-modern-business-skyscrapers-glass-sky-view-landscape-commercial-building.jpg', 0, 'attachment', 'image/jpeg', 0),
(18, 3, '2021-09-20 14:52:01', '2021-09-20 04:52:01', '<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>To establish a pre-eminent International Centre of Excellence in terms of the identification of building regulatory systems and regimes that are international exemplars.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:image {"id":17,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="https://dev.sockbrew.design/wp-content/uploads/2021/09/view-modern-business-skyscrapers-glass-sky-view-landscape-commercial-building-1024x683.jpg" alt="" class="wp-image-17"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>To be a sounding board or point of reference for law reformers, policymakers and stakeholders intent on designing building regulation that provides the greatest opportunity for the realisation of codes and laws that maximise:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li>Public safety;</li><li>Cost-effective and efficient construction systems; and</li><li>Sustainability within the context of the built environment.</li></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>The IBQC will also pave the way for students, who are intent on developing expertise in best practice construction regulation, practices and systems, to embark upon postgraduate studies on point.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The IBQC will be a medium through which comparative analyses can be applied to reforming jurisdictions to enable the potential client to have concepts peer-reviewed.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>This will provide the University of Canberra with the opportunity of commissioning research on point, albeit such research will be remunerative for the University.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The paramount vision being that, through its research and its members, the IBQC will have a positive and material impact on building regulation and practices in Australia and jurisdictions across the world.</p>\n<!-- /wp:paragraph -->', 'Vision', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2021-09-20 14:52:01', '2021-09-20 04:52:01', '', 16, 'https://dev.sockbrew.design/?p=18', 0, 'revision', '', 0),
(21, 3, '2021-09-26 21:23:11', '2021-09-26 11:23:11', '', 'leadership', '', 'inherit', 'open', 'closed', '', 'leadership', '', '', '2021-09-26 21:23:11', '2021-09-26 11:23:11', '', 0, 'https://dev.sockbrew.design/wp-content/uploads/2021/09/leadership.png', 0, 'attachment', 'image/png', 0),
(27, 3, '2021-09-26 21:34:16', '2021-09-26 11:34:16', '<!-- wp:paragraph -->\n<p>Please contact us any time you have a question or issue and we will have a member of our team answer your query.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:wpforms/form-selector {"formId":"73"} /-->', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2021-10-10 10:06:10', '2021-10-10 00:06:10', '', 0, 'https://dev.sockbrew.design/?page_id=27', 0, 'page', '', 0),
(28, 3, '2021-09-26 21:34:16', '2021-09-26 11:34:16', '<!-- wp:paragraph -->\n<p>Please contact us any time you have a question or issue and we will have a member of our team answer your query.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {"fontSize":"extra-small"} -->\n<p class="has-extra-small-font-size">Name</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {"fontSize":"extra-small"} -->\n<p class="has-extra-small-font-size">Company</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {"fontSize":"extra-small"} -->\n<p class="has-extra-small-font-size">Email</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {"fontSize":"extra-small"} -->\n<p class="has-extra-small-font-size">Phone</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {"fontSize":"extra-small"} -->\n<p class="has-extra-small-font-size">Message</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:buttons -->\n<div class="wp-block-buttons"><!-- wp:button -->\n<div class="wp-block-button"><a class="wp-block-button__link">Submit</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons -->', 'Contact', '', 'inherit', 'closed', 'closed', '', '27-revision-v1', '', '', '2021-09-26 21:34:16', '2021-09-26 11:34:16', '', 27, 'https://dev.sockbrew.design/?p=28', 0, 'revision', '', 0),
(41, 3, '2021-09-30 17:18:45', '2021-09-30 07:18:45', '', 'IBQC Good Practice Guidelines for Low Income Countries', '', 'publish', 'closed', 'closed', '', 'ibqc-good-practice-guidelines-for-low-income-countries', '', '', '2021-10-15 09:44:06', '2021-10-14 23:44:06', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=41', 0, 'publication', '', 0),
(42, 1, '2021-09-30 17:19:38', '2021-09-30 07:19:38', '', 'Principles for Good Practice Building Regulation', '', 'publish', 'closed', 'closed', '', 'principles-for-good-practice-building-regulation', '', '', '2021-10-15 17:28:52', '2021-10-15 07:28:52', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=42', 0, 'publication', '', 0),
(43, 1, '2021-09-30 17:20:39', '2021-09-30 07:20:39', '', 'The Virtues of Risk-Based Building Classifications & Mandatory Inspections', '', 'publish', 'closed', 'closed', '', 'the-virtues-of-risk-based-building-classifications-mandatory-inspections', '', '', '2021-10-15 17:28:32', '2021-10-15 07:28:32', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=43', 0, 'publication', '', 0),
(45, 1, '2021-09-30 17:27:46', '2021-09-30 07:27:46', '', 'Publications', '', 'publish', 'closed', 'closed', '', 'publications', '', '', '2021-09-30 17:27:46', '2021-09-30 07:27:46', '', 0, 'https://dev.sockbrew.design/?page_id=45', 0, 'page', '', 0),
(46, 1, '2021-09-30 17:27:46', '2021-09-30 07:27:46', '', 'Publications', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2021-09-30 17:27:46', '2021-09-30 07:27:46', '', 45, 'https://dev.sockbrew.design/?p=46', 0, 'revision', '', 0),
(52, 1, '2021-10-09 21:14:52', '2021-10-09 11:14:52', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:5:"forum";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:8:"seamless";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:14:{i:0;s:9:"permalink";i:1;s:11:"the_content";i:2;s:7:"excerpt";i:3;s:10:"discussion";i:4;s:8:"comments";i:5;s:9:"revisions";i:6;s:4:"slug";i:7;s:6:"author";i:8;s:6:"format";i:9;s:15:"page_attributes";i:10;s:14:"featured_image";i:11;s:10:"categories";i:12;s:4:"tags";i:13;s:15:"send-trackbacks";}s:11:"description";s:0:"";}', 'Forums Fields', 'forums-fields', 'publish', 'closed', 'closed', '', 'group_615a4099967d3', '', '', '2021-10-16 11:47:52', '2021-10-16 01:47:52', '', 0, 'https://dev.sockbrew.design/?p=52', 0, 'acf-field-group', '', 0),
(53, 1, '2021-10-09 21:14:52', '2021-10-09 11:14:52', 'a:8:{s:4:"type";s:11:"date_picker";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:14:"display_format";s:5:"d/m/Y";s:13:"return_format";s:6:"F j, Y";s:9:"first_day";i:1;}', 'Forum Date', 'forum_date', 'publish', 'closed', 'closed', '', 'field_615a418f66d63', '', '', '2021-10-09 21:14:52', '2021-10-09 11:14:52', '', 52, 'https://dev.sockbrew.design/?post_type=acf-field&p=53', 0, 'acf-field', '', 0),
(54, 1, '2021-10-09 21:14:52', '2021-10-09 11:14:52', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:49:"Include a short description of the forum details.";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Description', 'description', 'publish', 'closed', 'closed', '', 'field_615a41c566d64', '', '', '2021-10-16 11:47:52', '2021-10-16 01:47:52', '', 52, 'https://dev.sockbrew.design/?post_type=acf-field&#038;p=54', 1, 'acf-field', '', 0),
(55, 1, '2021-10-09 21:14:52', '2021-10-09 11:14:52', 'a:10:{s:4:"type";s:4:"file";s:12:"instructions";s:52:"This should be a link to the program, in PDF format.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:7:"library";s:3:"all";s:8:"min_size";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:3:"pdf";}', 'Link to Program', 'link_to_program', 'publish', 'closed', 'closed', '', 'field_615a41e466d65', '', '', '2021-10-16 11:47:52', '2021-10-16 01:47:52', '', 52, 'https://dev.sockbrew.design/?post_type=acf-field&#038;p=55', 2, 'acf-field', '', 0),
(56, 1, '2021-10-09 21:14:52', '2021-10-09 11:14:52', 'a:7:{s:4:"type";s:6:"oembed";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:5:"width";s:0:"";s:6:"height";s:0:"";}', 'Forum Video Link', 'youtube_link', 'publish', 'closed', 'closed', '', 'field_615a421f66d66', '', '', '2021-10-09 21:14:52', '2021-10-09 11:14:52', '', 52, 'https://dev.sockbrew.design/?post_type=acf-field&p=56', 3, 'acf-field', '', 0),
(57, 1, '2021-10-09 21:14:52', '2021-10-09 11:14:52', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:68:"List out the forum topics and speakers, they will appear in a table.";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Topics and Speakers', 'topics_and_speakers', 'publish', 'closed', 'closed', '', 'field_6160c6a283e10', '', '', '2021-10-16 11:47:52', '2021-10-16 01:47:52', '', 52, 'https://dev.sockbrew.design/?post_type=acf-field&#038;p=57', 4, 'acf-field', '', 0),
(58, 1, '2021-10-09 21:14:52', '2021-10-09 11:14:52', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Speaker Name', 'speaker_name', 'publish', 'closed', 'closed', '', 'field_6160c8ac83e11', '', '', '2021-10-09 21:14:52', '2021-10-09 11:14:52', '', 57, 'https://dev.sockbrew.design/?post_type=acf-field&p=58', 0, 'acf-field', '', 0),
(59, 1, '2021-10-09 21:14:52', '2021-10-09 11:14:52', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Speaker Credentials', 'speaker_credentials', 'publish', 'closed', 'closed', '', 'field_6160c91183e13', '', '', '2021-10-09 21:14:52', '2021-10-09 11:14:52', '', 57, 'https://dev.sockbrew.design/?post_type=acf-field&p=59', 1, 'acf-field', '', 0),
(60, 1, '2021-10-09 21:14:52', '2021-10-09 11:14:52', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Speaker Topic', 'speaker_topic', 'publish', 'closed', 'closed', '', 'field_6160c8cd83e12', '', '', '2021-10-09 21:14:52', '2021-10-09 11:14:52', '', 57, 'https://dev.sockbrew.design/?post_type=acf-field&p=60', 2, 'acf-field', '', 0),
(61, 1, '2021-10-09 21:14:53', '2021-10-09 11:14:53', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:11:"publication";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:8:"seamless";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:13:{i:0;s:9:"permalink";i:1;s:11:"the_content";i:2;s:7:"excerpt";i:3;s:10:"discussion";i:4;s:8:"comments";i:5;s:9:"revisions";i:6;s:4:"slug";i:7;s:6:"author";i:8;s:6:"format";i:9;s:15:"page_attributes";i:10;s:14:"featured_image";i:11;s:10:"categories";i:12;s:15:"send-trackbacks";}s:11:"description";s:0:"";}', 'Publication Group', 'publication-group', 'publish', 'closed', 'closed', '', 'group_615522b7ab542', '', '', '2021-10-16 11:49:48', '2021-10-16 01:49:48', '', 0, 'https://dev.sockbrew.design/?p=61', 0, 'acf-field-group', '', 0),
(62, 1, '2021-10-09 21:14:53', '2021-10-09 11:14:53', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Authors', 'authors', 'publish', 'closed', 'closed', '', 'field_61552362ff0dc', '', '', '2021-10-09 21:14:53', '2021-10-09 11:14:53', '', 61, 'https://dev.sockbrew.design/?post_type=acf-field&p=62', 0, 'acf-field', '', 0),
(63, 1, '2021-10-09 21:14:53', '2021-10-09 11:14:53', 'a:8:{s:4:"type";s:11:"date_picker";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:14:"display_format";s:1:"Y";s:13:"return_format";s:1:"Y";s:9:"first_day";i:1;}', 'Published Year', 'published_year', 'publish', 'closed', 'closed', '', 'field_61552660d324f', '', '', '2021-10-09 21:14:53', '2021-10-09 11:14:53', '', 61, 'https://dev.sockbrew.design/?post_type=acf-field&p=63', 1, 'acf-field', '', 0),
(65, 1, '2021-10-09 21:14:53', '2021-10-09 11:14:53', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Abstract', 'abstract', 'publish', 'closed', 'closed', '', 'field_615526f3d3251', '', '', '2021-10-16 11:49:48', '2021-10-16 01:49:48', '', 61, 'https://dev.sockbrew.design/?post_type=acf-field&#038;p=65', 2, 'acf-field', '', 0),
(66, 1, '2021-10-09 21:14:53', '2021-10-09 11:14:53', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Link to Publication', 'link_to_publication', 'publish', 'closed', 'closed', '', 'field_6155291a7f3ad', '', '', '2021-10-16 11:49:48', '2021-10-16 01:49:48', '', 61, 'https://dev.sockbrew.design/?post_type=acf-field&#038;p=66', 3, 'acf-field', '', 0),
(67, 1, '2021-10-09 21:14:53', '2021-10-09 11:14:53', 'a:13:{s:4:"type";s:8:"taxonomy";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:8:"taxonomy";s:21:"publications_category";s:10:"field_type";s:12:"multi_select";s:10:"allow_null";i:0;s:8:"add_term";i:0;s:10:"save_terms";i:1;s:10:"load_terms";i:1;s:13:"return_format";s:6:"object";s:8:"multiple";i:0;}', 'Category', 'category', 'publish', 'closed', 'closed', '', 'field_615529807f3ae', '', '', '2021-10-16 11:49:48', '2021-10-16 01:49:48', '', 61, 'https://dev.sockbrew.design/?post_type=acf-field&#038;p=67', 4, 'acf-field', '', 0),
(68, 1, '2021-10-09 21:14:53', '2021-10-09 11:14:53', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:81:"A screenshot of the front of the publication. Can be a PDF or Website Screenshot.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Publication Image', 'publication_image', 'publish', 'closed', 'closed', '', 'field_6160d5f290f30', '', '', '2021-10-16 11:49:48', '2021-10-16 01:49:48', '', 61, 'https://dev.sockbrew.design/?post_type=acf-field&#038;p=68', 5, 'acf-field', '', 0),
(69, 1, '2021-10-09 21:17:54', '2021-10-09 11:17:54', '', 'Forums', '', 'publish', 'closed', 'closed', '', 'forums', '', '', '2021-10-16 16:46:33', '2021-10-16 06:46:33', '', 0, 'https://dev.sockbrew.design/?page_id=69', 0, 'page', '', 0),
(70, 1, '2021-10-09 21:17:54', '2021-10-09 11:17:54', '', 'IBQC Forums', '', 'inherit', 'closed', 'closed', '', '69-revision-v1', '', '', '2021-10-09 21:17:54', '2021-10-09 11:17:54', '', 69, 'https://dev.sockbrew.design/?p=70', 0, 'revision', '', 0),
(73, 3, '2021-10-10 09:59:22', '2021-10-09 23:59:22', '{"fields":{"0":{"id":"0","type":"name","label":"Name","format":"simple","description":"","required":"1","size":"medium","simple_placeholder":"","simple_default":"","first_placeholder":"","first_default":"","middle_placeholder":"","middle_default":"","last_placeholder":"","last_default":"","css":""},"7":{"id":"7","type":"text","label":"Company","description":"","size":"medium","placeholder":"","limit_count":"1","limit_mode":"characters","default_value":"","input_mask":"","css":""},"1":{"id":"1","type":"email","label":"Email","description":"","required":"1","size":"medium","placeholder":"","confirmation_placeholder":"","default_value":"","filter_type":"","allowlist":"","denylist":"","css":""},"8":{"id":"8","type":"text","label":"Phone","description":"","size":"medium","placeholder":"","limit_count":"1","limit_mode":"characters","default_value":"","input_mask":"","css":""},"2":{"id":"2","type":"textarea","label":"Message","description":"","required":"1","size":"medium","placeholder":"","limit_count":"1","limit_mode":"characters","default_value":"","css":""}},"id":"73","field_id":9,"settings":{"form_title":"Contact","form_desc":"","submit_text":"Submit","submit_text_processing":"Sending...","antispam":"1","form_class":"","submit_class":"uk-button uk-button-primary","ajax_submit":"1","notification_enable":"1","notifications":{"1":{"email":"sockbrewdesign@gmail.com, riley.post@canberra.edu.au","subject":"New Entry: Contact Form","sender_name":"IBQC: International Building Quality Centre Contact","sender_address":"{admin_email}","replyto":"{field_id=\\"1\\"}","message":"{all_fields}"}},"confirmations":{"1":{"type":"message","message":"<p>Thanks for contacting International Building Quality Centre. We will be in touch with you shortly.<\\/p>","message_scroll":"1","page":"11","redirect":""}}},"meta":{"template":"4dbf022985a4fe4bda4a80365011a3a0"}}', 'Contact', '', 'publish', 'closed', 'closed', '', 'simple-contact-form', '', '', '2021-10-18 08:30:16', '2021-10-17 22:30:16', '', 0, 'https://dev.sockbrew.design/?post_type=wpforms&#038;p=73', 0, 'wpforms', '', 0),
(74, 3, '2021-10-10 10:06:10', '2021-10-10 00:06:10', '<!-- wp:paragraph -->\n<p>Please contact us any time you have a question or issue and we will have a member of our team answer your query.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:wpforms/form-selector {"formId":"73"} /-->', 'Contact', '', 'inherit', 'closed', 'closed', '', '27-revision-v1', '', '', '2021-10-10 10:06:10', '2021-10-10 00:06:10', '', 27, 'https://dev.sockbrew.design/?p=74', 0, 'revision', '', 0),
(75, 3, '2021-10-10 10:52:33', '2021-10-10 00:52:33', '<!-- wp:paragraph -->\n<p>Please contact us any time you have a question or issue and we will have a member of our team answer your query.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:wpforms/form-selector {"formId":"73"} /-->', 'Contact', '', 'inherit', 'closed', 'closed', '', '27-autosave-v1', '', '', '2021-10-10 10:52:33', '2021-10-10 00:52:33', '', 27, 'https://dev.sockbrew.design/?p=75', 0, 'revision', '', 0),
(76, 2, '2021-10-10 16:55:01', '2021-10-10 06:55:01', '', 'LOGO 2', '', 'inherit', 'open', 'closed', '', 'logo-2', '', '', '2021-10-10 16:55:01', '2021-10-10 06:55:01', '', 0, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/LOGO-2-1.png', 0, 'attachment', 'image/png', 0),
(83, 3, '2021-10-11 11:12:03', '2021-10-11 01:12:03', '', 'hero', '', 'inherit', 'open', 'closed', '', 'hero', '', '', '2021-10-11 11:12:03', '2021-10-11 01:12:03', '', 8, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png', 0, 'attachment', 'image/png', 0),
(85, 3, '2021-10-11 11:13:26', '2021-10-11 01:13:26', '<!-- wp:cover {"url":"https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png","id":83} -->\n<div class="wp-block-cover has-background-dim"><img class="wp-block-cover__image-background wp-image-83" alt="" src="https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","fontSize":"huge"} -->\n<p class="has-text-align-center has-huge-font-size"> Welcome to the IBQC </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {"align":"center","placeholder":"Write title…","fontSize":"normal"} -->\n<p class="has-text-align-center has-normal-font-size"> A pre-eminent International Centre of Excellence in terms of the identification of building regulatory systems and regimes that are international exemplars. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:buttons -->\n<div class="wp-block-buttons"><!-- wp:button -->\n<div class="wp-block-button"><a class="wp-block-button__link" href="https://dev.sockbrew.design/about-ibqc/">Find out more</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons --></div></div>\n<!-- /wp:cover -->\n\n<!-- wp:paragraph {"fontSize":"large"} -->\n<p class="has-large-font-size">ICC Pulse Podcast Episode 42: International Building Quality Centre (IBQC) Guidelines for Developing Countries</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>In the final episode of Season 3 of the ICC Pulse Podcast,&nbsp;Judy Zakreski, Code Council Vice President of Global Services talks with&nbsp;Professor Kim Lovegrove&nbsp;and&nbsp;Professor Alfred Omenya&nbsp;on the newly-released&nbsp;Good Practice Guidelines and Principles for the Development of Building Regulations in Low Income Countries.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"id":9,"sizeSlug":"full","linkDestination":"none"} -->\n<figure class="wp-block-image size-full"><img src="https://dev.sockbrew.design/wp-content/uploads/2021/09/podcast.png" alt="" class="wp-image-9"/></figure>\n<!-- /wp:image -->', 'Home', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2021-10-11 11:13:26', '2021-10-11 01:13:26', '', 8, 'https://dev.sockbrew.design/?p=85', 0, 'revision', '', 0),
(86, 3, '2021-10-11 11:14:00', '2021-10-11 01:14:00', '<!-- wp:cover {"url":"https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png","id":83} -->\n<div class="wp-block-cover has-background-dim"><img class="wp-block-cover__image-background wp-image-83" alt="" src="https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","fontSize":"huge"} -->\n<p class="has-text-align-center has-huge-font-size"> Welcome to the IBQC </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {"align":"center","placeholder":"Write title…","fontSize":"normal"} -->\n<p class="has-text-align-center has-normal-font-size"> A pre-eminent International Centre of Excellence in terms of the identification of building regulatory systems and regimes that are international exemplars. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:buttons {"contentJustification":"center"} -->\n<div class="wp-block-buttons is-content-justification-center"><!-- wp:button {"className":"is-style-outline"} -->\n<div class="wp-block-button is-style-outline"><a class="wp-block-button__link" href="https://dev.sockbrew.design/about-ibqc/">Find out more</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons --></div></div>\n<!-- /wp:cover -->\n\n<!-- wp:paragraph {"fontSize":"large"} -->\n<p class="has-large-font-size">ICC Pulse Podcast Episode 42: International Building Quality Centre (IBQC) Guidelines for Developing Countries</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>In the final episode of Season 3 of the ICC Pulse Podcast,&nbsp;Judy Zakreski, Code Council Vice President of Global Services talks with&nbsp;Professor Kim Lovegrove&nbsp;and&nbsp;Professor Alfred Omenya&nbsp;on the newly-released&nbsp;Good Practice Guidelines and Principles for the Development of Building Regulations in Low Income Countries.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"id":9,"sizeSlug":"full","linkDestination":"none"} -->\n<figure class="wp-block-image size-full"><img src="https://dev.sockbrew.design/wp-content/uploads/2021/09/podcast.png" alt="" class="wp-image-9"/></figure>\n<!-- /wp:image -->', 'Home', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2021-10-11 11:14:00', '2021-10-11 01:14:00', '', 8, 'https://dev.sockbrew.design/?p=86', 0, 'revision', '', 0),
(87, 3, '2021-10-11 11:14:35', '2021-10-11 01:14:35', '<!-- wp:cover {"url":"https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png","id":83,"minHeight":600} -->\n<div class="wp-block-cover has-background-dim" style="min-height:600px"><img class="wp-block-cover__image-background wp-image-83" alt="" src="https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","fontSize":"huge"} -->\n<p class="has-text-align-center has-huge-font-size"> Welcome to the IBQC </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {"align":"center","placeholder":"Write title…","fontSize":"normal"} -->\n<p class="has-text-align-center has-normal-font-size"> A pre-eminent International Centre of Excellence in terms of the identification of building regulatory systems and regimes that are international exemplars. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:buttons {"contentJustification":"center"} -->\n<div class="wp-block-buttons is-content-justification-center"><!-- wp:button {"className":"is-style-outline"} -->\n<div class="wp-block-button is-style-outline"><a class="wp-block-button__link" href="https://dev.sockbrew.design/about-ibqc/">Find out more</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons --></div></div>\n<!-- /wp:cover -->\n\n<!-- wp:paragraph {"fontSize":"large"} -->\n<p class="has-large-font-size">ICC Pulse Podcast Episode 42: International Building Quality Centre (IBQC) Guidelines for Developing Countries</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>In the final episode of Season 3 of the ICC Pulse Podcast,&nbsp;Judy Zakreski, Code Council Vice President of Global Services talks with&nbsp;Professor Kim Lovegrove&nbsp;and&nbsp;Professor Alfred Omenya&nbsp;on the newly-released&nbsp;Good Practice Guidelines and Principles for the Development of Building Regulations in Low Income Countries.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"id":9,"sizeSlug":"full","linkDestination":"none"} -->\n<figure class="wp-block-image size-full"><img src="https://dev.sockbrew.design/wp-content/uploads/2021/09/podcast.png" alt="" class="wp-image-9"/></figure>\n<!-- /wp:image -->', 'Home', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2021-10-11 11:14:35', '2021-10-11 01:14:35', '', 8, 'https://dev.sockbrew.design/?p=87', 0, 'revision', '', 0),
(88, 3, '2021-10-11 11:15:35', '2021-10-11 01:15:35', '<!-- wp:cover {"url":"https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png","id":83,"minHeight":600} -->\n<div class="wp-block-cover has-background-dim" style="min-height:600px"><img class="wp-block-cover__image-background wp-image-83" alt="" src="https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"60px"}}} -->\n<p class="has-text-align-center" style="font-size:60px"> Welcome to the IBQC </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {"align":"center","placeholder":"Write title…","fontSize":"medium"} -->\n<p class="has-text-align-center has-medium-font-size"> A pre-eminent International Centre of Excellence in terms of the identification of building regulatory systems and regimes that are international exemplars. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:buttons {"contentJustification":"center"} -->\n<div class="wp-block-buttons is-content-justification-center"><!-- wp:button {"className":"is-style-outline"} -->\n<div class="wp-block-button is-style-outline"><a class="wp-block-button__link" href="https://dev.sockbrew.design/about-ibqc/">Find out more</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons --></div></div>\n<!-- /wp:cover -->\n\n<!-- wp:paragraph {"fontSize":"large"} -->\n<p class="has-large-font-size">ICC Pulse Podcast Episode 42: International Building Quality Centre (IBQC) Guidelines for Developing Countries</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>In the final episode of Season 3 of the ICC Pulse Podcast,&nbsp;Judy Zakreski, Code Council Vice President of Global Services talks with&nbsp;Professor Kim Lovegrove&nbsp;and&nbsp;Professor Alfred Omenya&nbsp;on the newly-released&nbsp;Good Practice Guidelines and Principles for the Development of Building Regulations in Low Income Countries.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"id":9,"sizeSlug":"full","linkDestination":"none"} -->\n<figure class="wp-block-image size-full"><img src="https://dev.sockbrew.design/wp-content/uploads/2021/09/podcast.png" alt="" class="wp-image-9"/></figure>\n<!-- /wp:image -->', 'Home', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2021-10-11 11:15:35', '2021-10-11 01:15:35', '', 8, 'https://dev.sockbrew.design/?p=88', 0, 'revision', '', 0),
(89, 3, '2021-10-11 11:21:30', '2021-10-11 01:21:30', '', 'podcast', '', 'inherit', 'open', 'closed', '', 'podcast-2', '', '', '2021-10-11 11:21:30', '2021-10-11 01:21:30', '', 8, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/podcast.png', 0, 'attachment', 'image/png', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(90, 3, '2021-10-11 11:21:59', '2021-10-11 01:21:59', '<!-- wp:cover {"url":"https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png","id":83,"minHeight":600} -->\n<div class="wp-block-cover has-background-dim" style="min-height:600px"><img class="wp-block-cover__image-background wp-image-83" alt="" src="https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"60px"}}} -->\n<p class="has-text-align-center" style="font-size:60px"> Welcome to the IBQC </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {"align":"center","placeholder":"Write title…","fontSize":"medium"} -->\n<p class="has-text-align-center has-medium-font-size"> A pre-eminent International Centre of Excellence in terms of the identification of building regulatory systems and regimes that are international exemplars. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:buttons {"contentJustification":"center"} -->\n<div class="wp-block-buttons is-content-justification-center"><!-- wp:button {"className":"is-style-outline"} -->\n<div class="wp-block-button is-style-outline"><a class="wp-block-button__link" href="https://dev.sockbrew.design/about-ibqc/">Find out more</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons --></div></div>\n<!-- /wp:cover -->\n\n<!-- wp:columns -->\n<div class="wp-block-columns"><!-- wp:column -->\n<div class="wp-block-column"><!-- wp:heading -->\n<h2> ICC Pulse Podcast Episode 42: International Building Quality Centre (IBQC) Guidelines for Developing Countries </h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p> In the final episode of Season 3 of the ICC Pulse Podcast, Judy Zakreski, Code Council Vice President of Global Services talks with Professor Kim Lovegrove and Professor Alfred Omenya on the newly-released Good Practice Guidelines and Principles for the Development of Building Regulations in Low Income Countries. </p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class="wp-block-column"><!-- wp:image {"id":89,"sizeSlug":"full","linkDestination":"none"} -->\n<figure class="wp-block-image size-full"><img src="https://dev.sockbrew.design/wp-content/uploads/2021/10/podcast.png" alt="" class="wp-image-89"/></figure>\n<!-- /wp:image --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2021-10-11 11:21:59', '2021-10-11 01:21:59', '', 8, 'https://dev.sockbrew.design/?p=90', 0, 'revision', '', 0),
(92, 3, '2021-10-11 11:24:02', '2021-10-11 01:24:02', '', 'view-modern-business-skyscrapers-glass-sky-view-landscape-commercial-building-1024x683-1', '', 'inherit', 'open', 'closed', '', 'view-modern-business-skyscrapers-glass-sky-view-landscape-commercial-building-1024x683-1', '', '', '2021-10-11 11:24:02', '2021-10-11 01:24:02', '', 16, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/view-modern-business-skyscrapers-glass-sky-view-landscape-commercial-building-1024x683-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(93, 3, '2021-10-11 11:24:21', '2021-10-11 01:24:21', '<!-- wp:quote {"className":"is-style-large"} -->\n<blockquote class="wp-block-quote is-style-large"><p>To establish a pre-eminent International Centre of Excellence in terms of the identification of building regulatory systems and regimes that are international exemplars.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:columns -->\n<div class="wp-block-columns"><!-- wp:column -->\n<div class="wp-block-column"><!-- wp:paragraph -->\n<p>To be a sounding board or point of reference for law reformers, policymakers and stakeholders intent on designing building regulation that provides the greatest opportunity for the realisation of codes and laws that maximise:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li>Public safety;</li><li>Cost-effective and efficient construction systems; and</li><li>Sustainability within the context of the built environment.</li></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>The IBQC will also pave the way for students, who are intent on developing expertise in best practice construction regulation, practices and systems, to embark upon postgraduate studies on point.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The IBQC will be a medium through which comparative analyses can be applied to reforming jurisdictions to enable the potential client to have concepts peer-reviewed.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>This will provide the University of Canberra with the opportunity of commissioning research on point, albeit such research will be remunerative for the University.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The paramount vision being that, through its research and its members, the IBQC will have a positive and material impact on building regulation and practices in Australia and jurisdictions across the world.</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class="wp-block-column"><!-- wp:image {"id":92,"sizeSlug":"full","linkDestination":"none"} -->\n<figure class="wp-block-image size-full"><img src="https://dev.sockbrew.design/wp-content/uploads/2021/10/view-modern-business-skyscrapers-glass-sky-view-landscape-commercial-building-1024x683-1.jpg" alt="" class="wp-image-92"/></figure>\n<!-- /wp:image --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->', 'Vision', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2021-10-11 11:24:21', '2021-10-11 01:24:21', '', 16, 'https://dev.sockbrew.design/?p=93', 0, 'revision', '', 0),
(94, 3, '2021-10-11 11:25:41', '2021-10-11 01:25:41', '<!-- wp:quote {"className":"is-style-large"} -->\n<blockquote class="wp-block-quote is-style-large"><p>To establish a pre-eminent International Centre of Excellence in terms of the identification of building regulatory systems and regimes that are international exemplars.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:separator {"customColor":"#84a7b5","className":"is-style-wide"} -->\n<hr class="wp-block-separator has-text-color has-background is-style-wide" style="background-color:#84a7b5;color:#84a7b5"/>\n<!-- /wp:separator -->\n\n<!-- wp:columns -->\n<div class="wp-block-columns"><!-- wp:column -->\n<div class="wp-block-column"><!-- wp:paragraph -->\n<p>To be a sounding board or point of reference for law reformers, policymakers and stakeholders intent on designing building regulation that provides the greatest opportunity for the realisation of codes and laws that maximise:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li>Public safety;</li><li>Cost-effective and efficient construction systems; and</li><li>Sustainability within the context of the built environment.</li></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>The IBQC will also pave the way for students, who are intent on developing expertise in best practice construction regulation, practices and systems, to embark upon postgraduate studies on point.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The IBQC will be a medium through which comparative analyses can be applied to reforming jurisdictions to enable the potential client to have concepts peer-reviewed.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>This will provide the University of Canberra with the opportunity of commissioning research on point, albeit such research will be remunerative for the University.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The paramount vision being that, through its research and its members, the IBQC will have a positive and material impact on building regulation and practices in Australia and jurisdictions across the world.</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class="wp-block-column"><!-- wp:image {"id":92,"sizeSlug":"full","linkDestination":"none"} -->\n<figure class="wp-block-image size-full"><img src="https://dev.sockbrew.design/wp-content/uploads/2021/10/view-modern-business-skyscrapers-glass-sky-view-landscape-commercial-building-1024x683-1.jpg" alt="" class="wp-image-92"/></figure>\n<!-- /wp:image --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->', 'Vision', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2021-10-11 11:25:41', '2021-10-11 01:25:41', '', 16, 'https://dev.sockbrew.design/?p=94', 0, 'revision', '', 0),
(95, 3, '2021-10-11 11:26:09', '2021-10-11 01:26:09', '<!-- wp:cover {"url":"https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png","id":83,"minHeight":600} -->\n<div class="wp-block-cover has-background-dim" style="min-height:600px"><img class="wp-block-cover__image-background wp-image-83" alt="" src="https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"60px"}}} -->\n<p class="has-text-align-center" style="font-size:60px"> Welcome to the IBQC </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {"align":"center","placeholder":"Write title…","fontSize":"medium"} -->\n<p class="has-text-align-center has-medium-font-size"> A pre-eminent International Centre of Excellence in terms of the identification of building regulatory systems and regimes that are international exemplars. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:buttons {"contentJustification":"center"} -->\n<div class="wp-block-buttons is-content-justification-center"><!-- wp:button {"className":"is-style-outline"} -->\n<div class="wp-block-button is-style-outline"><a class="wp-block-button__link" href="https://dev.sockbrew.design/about-ibqc/">Find out more</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons --></div></div>\n<!-- /wp:cover -->\n\n<!-- wp:columns -->\n<div class="wp-block-columns"><!-- wp:column -->\n<div class="wp-block-column"><!-- wp:heading -->\n<h2> ICC Pulse Podcast Episode 42: International Building Quality Centre (IBQC) Guidelines for Developing Countries </h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p> In the final episode of Season 3 of the ICC Pulse Podcast,&nbsp;Judy Zakreski, Code Council Vice President of Global Services talks with&nbsp;Professor Kim Lovegrove&nbsp;and&nbsp;Professor Alfred Omenya&nbsp;on the newly-released&nbsp;Good Practice Guidelines and Principles for the Development of Building Regulations in Low Income Countries. </p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class="wp-block-column"><!-- wp:image {"align":"center","id":89,"sizeSlug":"full","linkDestination":"none"} -->\n<div class="wp-block-image"><figure class="aligncenter size-full"><img src="https://dev.sockbrew.design/wp-content/uploads/2021/10/podcast.png" alt="" class="wp-image-89"/></figure></div>\n<!-- /wp:image --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2021-10-11 11:26:09', '2021-10-11 01:26:09', '', 8, 'https://dev.sockbrew.design/?p=95', 0, 'revision', '', 0),
(96, 3, '2021-10-11 11:26:11', '2021-10-11 01:26:11', '<!-- wp:quote {"className":"is-style-large"} -->\n<blockquote class="wp-block-quote is-style-large"><p>To establish a pre-eminent International Centre of Excellence in terms of the identification of building regulatory systems and regimes that are international exemplars.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:separator {"customColor":"#84a7b5","className":"is-style-wide"} -->\n<hr class="wp-block-separator has-text-color has-background is-style-wide" style="background-color:#84a7b5;color:#84a7b5"/>\n<!-- /wp:separator -->\n\n<!-- wp:columns -->\n<div class="wp-block-columns"><!-- wp:column -->\n<div class="wp-block-column"><!-- wp:paragraph -->\n<p>To be a sounding board or point of reference for law reformers, policymakers and stakeholders intent on designing building regulation that provides the greatest opportunity for the realisation of codes and laws that maximise:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li>Public safety;</li><li>Cost-effective and efficient construction systems; and</li><li>Sustainability within the context of the built environment.</li></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>The IBQC will also pave the way for students, who are intent on developing expertise in best practice construction regulation, practices and systems, to embark upon postgraduate studies on point.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The IBQC will be a medium through which comparative analyses can be applied to reforming jurisdictions to enable the potential client to have concepts peer-reviewed.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>This will provide the University of Canberra with the opportunity of commissioning research on point, albeit such research will be remunerative for the University.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The paramount vision being that, through its research and its members, the IBQC will have a positive and material impact on building regulation and practices in Australia and jurisdictions across the world.</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class="wp-block-column"><!-- wp:image {"align":"center","id":92,"sizeSlug":"full","linkDestination":"none"} -->\n<div class="wp-block-image"><figure class="aligncenter size-full"><img src="https://dev.sockbrew.design/wp-content/uploads/2021/10/view-modern-business-skyscrapers-glass-sky-view-landscape-commercial-building-1024x683-1.jpg" alt="" class="wp-image-92"/></figure></div>\n<!-- /wp:image --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->', 'Vision', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2021-10-11 11:26:11', '2021-10-11 01:26:11', '', 16, 'https://dev.sockbrew.design/?p=96', 0, 'revision', '', 0),
(98, 3, '2021-10-11 11:27:16', '2021-10-11 01:27:16', '<!-- wp:cover {"url":"https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png","id":83,"minHeight":600} -->\n<div class="wp-block-cover has-background-dim" style="min-height:600px"><img class="wp-block-cover__image-background wp-image-83" alt="" src="https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"60px"}}} -->\n<p class="has-text-align-center" style="font-size:60px"> Welcome to the IBQC </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {"align":"center","placeholder":"Write title…","fontSize":"medium"} -->\n<p class="has-text-align-center has-medium-font-size"> A pre-eminent International Centre of Excellence in terms of the identification of building regulatory systems and regimes that are international exemplars. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:buttons {"contentJustification":"center"} -->\n<div class="wp-block-buttons is-content-justification-center"><!-- wp:button {"className":"is-style-outline"} -->\n<div class="wp-block-button is-style-outline"><a class="wp-block-button__link" href="https://dev.sockbrew.design/about-ibqc/">Find out more</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons --></div></div>\n<!-- /wp:cover -->\n\n<!-- wp:columns -->\n<div class="wp-block-columns"><!-- wp:column -->\n<div class="wp-block-column"><!-- wp:heading -->\n<h2>Latest news</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3>ICC Pulse Podcast Episode 42: International Building Quality Centre (IBQC) Guidelines for Developing Countries </h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p> In the final episode of Season 3 of the ICC Pulse Podcast,&nbsp;Judy Zakreski, Code Council Vice President of Global Services talks with&nbsp;Professor Kim Lovegrove&nbsp;and&nbsp;Professor Alfred Omenya&nbsp;on the newly-released&nbsp;Good Practice Guidelines and Principles for the Development of Building Regulations in Low Income Countries. </p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class="wp-block-column"><!-- wp:image {"align":"center","id":89,"sizeSlug":"full","linkDestination":"none"} -->\n<div class="wp-block-image"><figure class="aligncenter size-full"><img src="https://dev.sockbrew.design/wp-content/uploads/2021/10/podcast.png" alt="ICC Pulse podcast graphic" class="wp-image-89"/></figure></div>\n<!-- /wp:image --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2021-10-11 11:27:16', '2021-10-11 01:27:16', '', 8, 'https://dev.sockbrew.design/?p=98', 0, 'revision', '', 0),
(99, 3, '2021-10-11 11:40:07', '2021-10-11 01:40:07', '', 'construction-silhouette-1024x684-1', '', 'inherit', 'open', 'closed', '', 'construction-silhouette-1024x684-1', '', '', '2021-10-11 11:40:07', '2021-10-11 01:40:07', '', 11, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/construction-silhouette-1024x684-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(100, 3, '2021-10-11 11:40:47', '2021-10-11 01:40:47', '', 'construction-worker-truss-installation-1024x684-1', '', 'inherit', 'open', 'closed', '', 'construction-worker-truss-installation-1024x684-1', '', '', '2021-10-11 11:40:47', '2021-10-11 01:40:47', '', 11, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/construction-worker-truss-installation-1024x684-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(101, 3, '2021-10-11 11:41:04', '2021-10-11 01:41:04', '<!-- wp:columns -->\n<div class="wp-block-columns"><!-- wp:column -->\n<div class="wp-block-column"><!-- wp:paragraph -->\n<p> The motivation for the establishment of the IBQC was founded on the recognition that many jurisdictions in recent times have been visited with tremendous challenges on account of building regulations that have not delivered the level of safety and security expected by the public.<br><br>Indeed, there have been regulatory failures that have culminated in the loss of life along with seriously deleterious economic impacts upon citizens.<br><br>These challenges have culminated in recognition by industry stakeholders that a rethinking of the philosophies and traditions that underpin the design of modern-day building control is both timely and necessary.<br><br>The IBQC serves as a collaborative medium through which systems, practices, regulations, codes and laws that provide best practice solutions and answers are identified, endorsed and encouraged. </p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class="wp-block-column"><!-- wp:image {"align":"center","id":99,"sizeSlug":"full","linkDestination":"none"} -->\n<div class="wp-block-image"><figure class="aligncenter size-full"><img src="https://dev.sockbrew.design/wp-content/uploads/2021/10/construction-silhouette-1024x684-1.jpg" alt="" class="wp-image-99"/></figure></div>\n<!-- /wp:image --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->\n\n<!-- wp:columns -->\n<div class="wp-block-columns"><!-- wp:column -->\n<div class="wp-block-column"><!-- wp:image {"align":"center","id":100,"sizeSlug":"full","linkDestination":"none"} -->\n<div class="wp-block-image"><figure class="aligncenter size-full"><img src="https://dev.sockbrew.design/wp-content/uploads/2021/10/construction-worker-truss-installation-1024x684-1.jpg" alt="" class="wp-image-100"/></figure></div>\n<!-- /wp:image --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class="wp-block-column"><!-- wp:paragraph -->\n<p> The IBQC will also, through research and comparative analysis, benchmark and identify jurisdictions that have pioneered and implemented best practice and emerging construction technology, probity regimes and enlightened construction systems and practices. In doing so, it will have regard to that which is best for the present and that which is best for the future.<br><br>As the IBQC will be hosted by the University of Canberra, there will exist the opportunity for students to avail themselves of the resources of the Centre with a view to carrying out further research on best practice regulatory ecology and establishing postgraduate study pathways.<br><br>The IBQC has developed an online library that continues to evolve into a compilation of best practice research publications and papers to generate a resource for students, law reformers, policymakers, practitioners and academics.<br><br>The IBQC aspires to become a sounding board providing an opinion on the viability of regulatory initiatives in terms of their benchmarking with best-practice research on point. </p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->', 'About IBQC', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2021-10-11 11:41:04', '2021-10-11 01:41:04', '', 11, 'https://dev.sockbrew.design/?p=101', 0, 'revision', '', 0),
(102, 3, '2021-10-11 20:41:26', '2021-10-11 10:41:26', '<!-- wp:cover {"url":"https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png","id":83,"minHeight":600} -->\n<div class="wp-block-cover has-background-dim" style="min-height:600px"><img class="wp-block-cover__image-background wp-image-83" alt="" src="https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"60px"}}} -->\n<p class="has-text-align-center" style="font-size:60px"> Welcome to the IBQC </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {"align":"center","placeholder":"Write title…","fontSize":"medium"} -->\n<p class="has-text-align-center has-medium-font-size"> A pre-eminent International Centre of Excellence in terms of the identification of building regulatory systems and regimes that are international exemplars. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:buttons {"contentJustification":"center"} -->\n<div class="wp-block-buttons is-content-justification-center"><!-- wp:button {"className":"is-style-outline"} -->\n<div class="wp-block-button is-style-outline"><a class="wp-block-button__link" href="https://dev.sockbrew.design/about-ibqc/">Find out more</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons --></div></div>\n<!-- /wp:cover -->\n\n<!-- wp:columns {"className":"homecolumns"} -->\n<div class="wp-block-columns homecolumns"><!-- wp:column -->\n<div class="wp-block-column"><!-- wp:heading -->\n<h2>Latest news</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3>ICC Pulse Podcast Episode 42: International Building Quality Centre (IBQC) Guidelines for Developing Countries </h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p> In the final episode of Season 3 of the ICC Pulse Podcast,&nbsp;Judy Zakreski, Code Council Vice President of Global Services talks with&nbsp;Professor Kim Lovegrove&nbsp;and&nbsp;Professor Alfred Omenya&nbsp;on the newly-released&nbsp;Good Practice Guidelines and Principles for the Development of Building Regulations in Low Income Countries. </p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class="wp-block-column"><!-- wp:image {"align":"center","id":89,"sizeSlug":"full","linkDestination":"none"} -->\n<div class="wp-block-image"><figure class="aligncenter size-full"><img src="https://dev.sockbrew.design/wp-content/uploads/2021/10/podcast.png" alt="ICC Pulse podcast graphic" class="wp-image-89"/></figure></div>\n<!-- /wp:image --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2021-10-11 20:41:26', '2021-10-11 10:41:26', '', 8, 'https://dev.sockbrew.design/?p=102', 0, 'revision', '', 0),
(104, 1, '2021-10-14 17:42:26', '2021-10-14 07:42:26', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:12:"board-member";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Board Members Fields', 'board-members-fields', 'publish', 'closed', 'closed', '', 'group_6167742faf425', '', '', '2021-10-16 11:44:04', '2021-10-16 01:44:04', '', 0, 'https://dev.sockbrew.design/?p=104', 0, 'acf-field-group', '', 0),
(105, 1, '2021-10-14 17:42:26', '2021-10-14 07:42:26', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:89:"If applicable use this field to show the board member\'s title, such as chair or treasure.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Board Member Title', 'board_member_title', 'publish', 'closed', 'closed', '', 'field_61677496eb69b', '', '', '2021-10-14 17:42:26', '2021-10-14 07:42:26', '', 104, 'https://dev.sockbrew.design/?post_type=acf-field&p=105', 0, 'acf-field', '', 0),
(106, 1, '2021-10-14 17:42:26', '2021-10-14 07:42:26', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:114:"This field will appear underneath the Board Member\'s name. Use it to include an important award or relevant title.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Secondary Title', 'secondary_title', 'publish', 'closed', 'closed', '', 'field_61677442eb69a', '', '', '2021-10-14 17:42:26', '2021-10-14 07:42:26', '', 104, 'https://dev.sockbrew.design/?post_type=acf-field&p=106', 1, 'acf-field', '', 0),
(107, 1, '2021-10-14 17:42:26', '2021-10-14 07:42:26', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:59:"Use this field to write a short bio about the board member.";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:7:"wpautop";}', 'Bio', 'bio', 'publish', 'closed', 'closed', '', 'field_61677623eb6a1', '', '', '2021-10-14 17:42:26', '2021-10-14 07:42:26', '', 104, 'https://dev.sockbrew.design/?post_type=acf-field&p=107', 2, 'acf-field', '', 0),
(108, 1, '2021-10-14 17:42:26', '2021-10-14 07:42:26', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:36:"Include an Image of the Board Member";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Board Member Image', 'board_member_image', 'publish', 'closed', 'closed', '', 'field_61677737eb6a6', '', '', '2021-10-16 11:44:04', '2021-10-16 01:44:04', '', 104, 'https://dev.sockbrew.design/?post_type=acf-field&#038;p=108', 3, 'acf-field', '', 0),
(109, 1, '2021-10-14 17:42:26', '2021-10-14 07:42:26', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:169:"Use this field to list out any affiliations or roles applicable to the board member. When choosing a year, pick any date within the year, only the year will be selected.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Professional Affiliations', 'professional_affiliations', 'publish', 'closed', 'closed', '', 'field_61677500eb69c', '', '', '2021-10-16 11:44:04', '2021-10-16 01:44:04', '', 104, 'https://dev.sockbrew.design/?post_type=acf-field&#038;p=109', 4, 'acf-field', '', 0),
(110, 1, '2021-10-14 17:42:26', '2021-10-14 07:42:26', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Role or Affiliation', 'role', 'publish', 'closed', 'closed', '', 'field_61677510eb69d', '', '', '2021-10-14 17:42:26', '2021-10-14 07:42:26', '', 109, 'https://dev.sockbrew.design/?post_type=acf-field&p=110', 0, 'acf-field', '', 0),
(111, 1, '2021-10-14 17:42:26', '2021-10-14 07:42:26', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Professional Body', 'professional_body', 'publish', 'closed', 'closed', '', 'field_6167753aeb69e', '', '', '2021-10-14 17:42:26', '2021-10-14 07:42:26', '', 109, 'https://dev.sockbrew.design/?post_type=acf-field&p=111', 1, 'acf-field', '', 0),
(112, 1, '2021-10-14 17:42:26', '2021-10-14 07:42:26', 'a:8:{s:4:"type";s:11:"date_picker";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:14:"display_format";s:1:"Y";s:13:"return_format";s:1:"Y";s:9:"first_day";i:1;}', 'Year', 'pro_start_year', 'publish', 'closed', 'closed', '', 'field_6167754beb69f', '', '', '2021-10-14 17:42:26', '2021-10-14 07:42:26', '', 109, 'https://dev.sockbrew.design/?post_type=acf-field&p=112', 2, 'acf-field', '', 0),
(113, 1, '2021-10-14 17:42:26', '2021-10-14 07:42:26', 'a:8:{s:4:"type";s:11:"date_picker";s:12:"instructions";s:92:"Select an end year if there was a range of time for the affiliation. This field is optional.";s:8:"required";i:0;s:17:"conditional_logic";a:1:{i:0;a:1:{i:0;a:2:{s:5:"field";s:19:"field_6167754beb69f";s:8:"operator";s:7:"!=empty";}}}s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:14:"display_format";s:1:"Y";s:13:"return_format";s:1:"Y";s:9:"first_day";i:1;}', 'End Year', 'pro_end_year', 'publish', 'closed', 'closed', '', 'field_616775bceb6a0', '', '', '2021-10-14 17:42:26', '2021-10-14 07:42:26', '', 109, 'https://dev.sockbrew.design/?post_type=acf-field&p=113', 3, 'acf-field', '', 0),
(114, 1, '2021-10-14 17:42:26', '2021-10-14 07:42:26', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:154:"Use this field to list out any awards applicable to the board member. When choosing a year, pick any date within the year, only the year will be selected.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Awards', 'awards', 'publish', 'closed', 'closed', '', 'field_61677654eb6a2', '', '', '2021-10-16 11:44:04', '2021-10-16 01:44:04', '', 104, 'https://dev.sockbrew.design/?post_type=acf-field&#038;p=114', 5, 'acf-field', '', 0),
(115, 1, '2021-10-14 17:42:26', '2021-10-14 07:42:26', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Award Title', 'award_title', 'publish', 'closed', 'closed', '', 'field_61677660eb6a3', '', '', '2021-10-14 17:42:26', '2021-10-14 07:42:26', '', 114, 'https://dev.sockbrew.design/?post_type=acf-field&p=115', 0, 'acf-field', '', 0),
(116, 1, '2021-10-14 17:42:26', '2021-10-14 07:42:26', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Award Issuer', 'award_issuer', 'publish', 'closed', 'closed', '', 'field_61677669eb6a4', '', '', '2021-10-14 17:42:26', '2021-10-14 07:42:26', '', 114, 'https://dev.sockbrew.design/?post_type=acf-field&p=116', 1, 'acf-field', '', 0),
(117, 1, '2021-10-14 17:42:26', '2021-10-14 07:42:26', 'a:8:{s:4:"type";s:11:"date_picker";s:12:"instructions";s:69:"Select any date in the relevant year, only the year will be selected.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:14:"display_format";s:1:"Y";s:13:"return_format";s:1:"Y";s:9:"first_day";i:1;}', 'Year', 'award_year', 'publish', 'closed', 'closed', '', 'field_616776e2eb6a5', '', '', '2021-10-14 17:42:26', '2021-10-14 07:42:26', '', 114, 'https://dev.sockbrew.design/?post_type=acf-field&p=117', 2, 'acf-field', '', 0),
(118, 3, '2021-10-14 17:45:46', '2021-10-14 07:45:46', '', 'Professor Charles Lemckert', '', 'publish', 'closed', 'closed', '', 'professor-charles-lemckert', '', '', '2021-10-15 12:23:34', '2021-10-15 02:23:34', '', 0, 'https://dev.sockbrew.design/?post_type=board-member&#038;p=118', 1, 'board-member', '', 0),
(119, 1, '2021-10-14 17:44:23', '2021-10-14 07:44:23', '', 'Charles-Lemckert-Profile-Pic', '', 'inherit', 'open', 'closed', '', 'charles-lemckert-profile-pic', '', '', '2021-10-14 17:44:23', '2021-10-14 07:44:23', '', 118, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/Charles-Lemckert-Profile-Pic.jpg', 0, 'attachment', 'image/jpeg', 0),
(122, 1, '2021-10-14 17:49:21', '2021-10-14 07:49:21', '', 'Leadership', '', 'publish', 'closed', 'closed', '', 'leadership', '', '', '2021-10-16 16:46:22', '2021-10-16 06:46:22', '', 0, 'https://dev.sockbrew.design/?page_id=122', 0, 'page', '', 0),
(123, 1, '2021-10-14 17:49:21', '2021-10-14 07:49:21', '', 'IBQC Leadership', '', 'inherit', 'closed', 'closed', '', '122-revision-v1', '', '', '2021-10-14 17:49:21', '2021-10-14 07:49:21', '', 122, 'https://dev.sockbrew.design/?p=123', 0, 'revision', '', 0),
(124, 1, '2021-10-14 17:50:48', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-10-14 17:50:48', '0000-00-00 00:00:00', '', 0, 'https://dev.sockbrew.design/?p=124', 1, 'nav_menu_item', '', 0),
(125, 1, '2021-10-14 17:50:48', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-10-14 17:50:48', '0000-00-00 00:00:00', '', 0, 'https://dev.sockbrew.design/?p=125', 1, 'nav_menu_item', '', 0),
(126, 1, '2021-10-14 17:50:48', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-10-14 17:50:48', '0000-00-00 00:00:00', '', 0, 'https://dev.sockbrew.design/?p=126', 1, 'nav_menu_item', '', 0),
(127, 1, '2021-10-14 17:50:48', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-10-14 17:50:48', '0000-00-00 00:00:00', '', 0, 'https://dev.sockbrew.design/?p=127', 1, 'nav_menu_item', '', 0),
(128, 1, '2021-10-14 17:50:48', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-10-14 17:50:48', '0000-00-00 00:00:00', '', 0, 'https://dev.sockbrew.design/?p=128', 1, 'nav_menu_item', '', 0),
(129, 1, '2021-10-14 17:50:48', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-10-14 17:50:48', '0000-00-00 00:00:00', '', 0, 'https://dev.sockbrew.design/?p=129', 1, 'nav_menu_item', '', 0),
(130, 1, '2021-10-14 17:50:48', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-10-14 17:50:48', '0000-00-00 00:00:00', '', 0, 'https://dev.sockbrew.design/?p=130', 1, 'nav_menu_item', '', 0),
(131, 1, '2021-10-14 17:51:28', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-10-14 17:51:28', '0000-00-00 00:00:00', '', 0, 'https://dev.sockbrew.design/?p=131', 1, 'nav_menu_item', '', 0),
(132, 1, '2021-10-14 17:51:28', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-10-14 17:51:28', '0000-00-00 00:00:00', '', 0, 'https://dev.sockbrew.design/?p=132', 1, 'nav_menu_item', '', 0),
(133, 1, '2021-10-14 17:51:28', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-10-14 17:51:28', '0000-00-00 00:00:00', '', 0, 'https://dev.sockbrew.design/?p=133', 1, 'nav_menu_item', '', 0),
(134, 1, '2021-10-14 17:51:28', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-10-14 17:51:28', '0000-00-00 00:00:00', '', 0, 'https://dev.sockbrew.design/?p=134', 1, 'nav_menu_item', '', 0),
(135, 1, '2021-10-14 17:51:28', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-10-14 17:51:28', '0000-00-00 00:00:00', '', 0, 'https://dev.sockbrew.design/?p=135', 1, 'nav_menu_item', '', 0),
(136, 1, '2021-10-14 17:51:28', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-10-14 17:51:28', '0000-00-00 00:00:00', '', 0, 'https://dev.sockbrew.design/?p=136', 1, 'nav_menu_item', '', 0),
(137, 1, '2021-10-14 17:51:28', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-10-14 17:51:28', '0000-00-00 00:00:00', '', 0, 'https://dev.sockbrew.design/?p=137', 1, 'nav_menu_item', '', 0),
(141, 3, '2021-10-15 09:08:12', '2021-10-14 23:08:12', '', 'buildingregulation', '', 'inherit', 'open', 'closed', '', 'buildingregulation', '', '', '2021-10-15 09:08:12', '2021-10-14 23:08:12', '', 42, 'https://dev.sockbrew.design/wp-content/uploads/2021/09/buildingregulation.png', 0, 'attachment', 'image/png', 0),
(143, 3, '2021-10-15 09:10:52', '2021-10-14 23:10:52', '', 'lowincome', '', 'inherit', 'open', 'closed', '', 'lowincome', '', '', '2021-10-15 09:10:52', '2021-10-14 23:10:52', '', 41, 'https://dev.sockbrew.design/wp-content/uploads/2021/09/lowincome.png', 0, 'attachment', 'image/png', 0),
(144, 1, '2021-10-15 09:14:27', '2021-10-14 23:14:27', '', 'Good Practices for Construction Regulation and Enforcement Reform – Guidelines for Reformers', '', 'publish', 'closed', 'closed', '', 'good-practices-for-construction-regulation-and-enforcement-reform-guidelines-for-reformers-2013', '', '', '2021-10-15 17:24:59', '2021-10-15 07:24:59', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=144', 0, 'publication', '', 0),
(145, 3, '2021-10-15 09:14:22', '2021-10-14 23:14:22', '', 'enforcement', '', 'inherit', 'open', 'closed', '', 'enforcement', '', '', '2021-10-15 09:14:22', '2021-10-14 23:14:22', '', 144, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/enforcement.png', 0, 'attachment', 'image/png', 0),
(146, 3, '2021-10-15 09:18:05', '2021-10-14 23:18:05', '', 'Dealing with construction permits - Assessing quality control and safety mechanisms', '', 'publish', 'closed', 'closed', '', 'dealing-with-construction-permits-assessing-quality-control-and-safety-mechanisms', '', '', '2021-10-15 09:43:51', '2021-10-14 23:43:51', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=146', 0, 'publication', '', 0),
(147, 3, '2021-10-15 09:17:43', '2021-10-14 23:17:43', '', 'mechanism', '', 'inherit', 'open', 'closed', '', 'mechanism', '', '', '2021-10-15 09:17:43', '2021-10-14 23:17:43', '', 146, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/mechanism.png', 0, 'attachment', 'image/png', 0),
(148, 3, '2021-10-15 09:21:36', '2021-10-14 23:21:36', '', 'Dealing with Construction Permits - Private sector participation in construction regulation', '', 'publish', 'closed', 'closed', '', 'dealing-with-construction-permits-private-sector-participation-in-construction-regulation', '', '', '2021-10-15 09:43:48', '2021-10-14 23:43:48', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=148', 0, 'publication', '', 0),
(149, 3, '2021-10-15 09:21:26', '2021-10-14 23:21:26', '', 'constructionpermit', '', 'inherit', 'open', 'closed', '', 'constructionpermit', '', '', '2021-10-15 09:21:26', '2021-10-14 23:21:26', '', 148, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/constructionpermit.png', 0, 'attachment', 'image/png', 0),
(150, 1, '2021-10-15 09:24:00', '2021-10-14 23:24:00', '', 'What a Best Practice Building Act for 2020 and Beyond Would Look Like', '', 'publish', 'closed', 'closed', '', 'what-a-best-practice-building-act-for-2020-and-beyond-would-look-like', '', '', '2021-10-15 17:24:29', '2021-10-15 07:24:29', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=150', 0, 'publication', '', 0),
(151, 3, '2021-10-15 09:23:54', '2021-10-14 23:23:54', '', 'beyond', '', 'inherit', 'open', 'closed', '', 'beyond', '', '', '2021-10-15 09:23:54', '2021-10-14 23:23:54', '', 150, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/beyond.png', 0, 'attachment', 'image/png', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(152, 3, '2021-10-15 09:46:02', '2021-10-14 23:46:02', '', 'Building regulation for resilience - Converting Disaster Experience into a Safer Built Environment', '', 'publish', 'closed', 'closed', '', 'building-regulation-for-resilience-converting-disaster-experience-into-a-safer-built-environment', '', '', '2021-10-15 09:46:02', '2021-10-14 23:46:02', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=152', 0, 'publication', '', 0),
(153, 1, '2021-10-15 09:47:37', '2021-10-14 23:47:37', '', 'The Virtues of Risk-Based Building Classifications & Mandatory Inspections', '', 'publish', 'closed', 'closed', '', 'the-virtues-of-risk-based-building-classifications-mandatory-inspections-2020', '', '', '2021-10-15 17:23:25', '2021-10-15 07:23:25', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=153', 0, 'publication', '', 0),
(154, 3, '2021-10-15 09:47:32', '2021-10-14 23:47:32', '', 'mandatory', '', 'inherit', 'open', 'closed', '', 'mandatory', '', '', '2021-10-15 09:47:32', '2021-10-14 23:47:32', '', 153, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/mandatory.png', 0, 'attachment', 'image/png', 0),
(155, 3, '2021-10-15 09:49:10', '2021-10-14 23:49:10', '', 'What role should risk-based inspections play in construction?', '', 'publish', 'closed', 'closed', '', 'what-role-should-risk-based-inspections-play-in-construction', '', '', '2021-10-15 09:49:10', '2021-10-14 23:49:10', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=155', 0, 'publication', '', 0),
(156, 3, '2021-10-15 09:49:07', '2021-10-14 23:49:07', '', 'risk', '', 'inherit', 'open', 'closed', '', 'risk', '', '', '2021-10-15 09:49:07', '2021-10-14 23:49:07', '', 155, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/risk.png', 0, 'attachment', 'image/png', 0),
(157, 1, '2021-10-15 09:52:04', '2021-10-14 23:52:04', '', 'Building Confidence: Improving the effectiveness of compliance and enforcement systems for the building and construction industry across Australia', '', 'publish', 'closed', 'closed', '', 'building-confidence-improving-the-effectiveness-of-compliance-and-enforcement-systems-for-the-building-and-construction-industry-across-australia-2018', '', '', '2021-10-15 17:22:46', '2021-10-15 07:22:46', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=157', 0, 'publication', '', 0),
(158, 3, '2021-10-15 09:51:57', '2021-10-14 23:51:57', '', 'confidence', '', 'inherit', 'open', 'closed', '', 'confidence', '', '', '2021-10-15 09:51:57', '2021-10-14 23:51:57', '', 157, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/confidence.png', 0, 'attachment', 'image/png', 0),
(159, 1, '2021-10-15 09:53:19', '2021-10-14 23:53:19', '', 'Building Confidence Report & Dame Judith Hackitt Report – Comparative Commentary for RICS Built Environment Journal', '', 'publish', 'closed', 'closed', '', 'building-confidence-report-dame-judith-hackitt-report-comparative-commentary-for-rics-built-environment-journal-2020', '', '', '2021-10-15 17:21:25', '2021-10-15 07:21:25', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=159', 0, 'publication', '', 0),
(160, 3, '2021-10-15 09:53:16', '2021-10-14 23:53:16', '', 'uae', '', 'inherit', 'open', 'closed', '', 'uae', '', '', '2021-10-15 09:53:16', '2021-10-14 23:53:16', '', 159, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/uae.png', 0, 'attachment', 'image/png', 0),
(161, 1, '2021-10-15 09:54:30', '2021-10-14 23:54:30', '', 'Independent Review of Building Regulations and Fire Safety: final report', '', 'publish', 'closed', 'closed', '', 'independent-review-of-building-regulations-and-fire-safety-final-report-2018', '', '', '2021-10-15 17:21:01', '2021-10-15 07:21:01', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=161', 0, 'publication', '', 0),
(162, 3, '2021-10-15 09:54:27', '2021-10-14 23:54:27', '', '9607', '', 'inherit', 'open', 'closed', '', '9607', '', '', '2021-10-15 09:54:27', '2021-10-14 23:54:27', '', 161, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/9607.png', 0, 'attachment', 'image/png', 0),
(163, 1, '2021-10-15 09:55:41', '2021-10-14 23:55:41', '', 'Independent Review of Building Regulations and Fire Safety: interim report', '', 'publish', 'closed', 'closed', '', 'independent-review-of-building-regulations-and-fire-safety-interim-report-2017', '', '', '2021-10-15 17:20:36', '2021-10-15 07:20:36', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=163', 0, 'publication', '', 0),
(164, 3, '2021-10-15 09:55:27', '2021-10-14 23:55:27', '', '9551', '', 'inherit', 'open', 'closed', '', '9551', '', '', '2021-10-15 09:55:27', '2021-10-14 23:55:27', '', 163, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/9551.png', 0, 'attachment', 'image/png', 0),
(165, 1, '2021-10-15 09:56:53', '2021-10-14 23:56:53', '', 'Beyond the stable door: Hackitt and the future of fire safety regulation in the UK', '', 'publish', 'closed', 'closed', '', 'beyond-the-stable-door-hackitt-and-the-future-of-fire-safety-regulation-in-the-uk-2019', '', '', '2021-10-15 17:20:06', '2021-10-15 07:20:06', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=165', 0, 'publication', '', 0),
(166, 3, '2021-10-15 09:56:48', '2021-10-14 23:56:48', '', 'hackitt', '', 'inherit', 'open', 'closed', '', 'hackitt', '', '', '2021-10-15 09:56:48', '2021-10-14 23:56:48', '', 165, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/hackitt.png', 0, 'attachment', 'image/png', 0),
(167, 3, '2021-10-15 10:38:34', '2021-10-15 00:38:34', '', 'Review of Building Regulations and Fire Safety: Submission of Evidence', '', 'publish', 'closed', 'closed', '', 'review-of-building-regulations-and-fire-safety-submission-of-evidence', '', '', '2021-10-15 10:38:34', '2021-10-15 00:38:34', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=167', 0, 'publication', '', 0),
(168, 3, '2021-10-15 10:36:44', '2021-10-15 00:36:44', '', 'safety', '', 'inherit', 'open', 'closed', '', 'safety', '', '', '2021-10-15 10:36:44', '2021-10-15 00:36:44', '', 167, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/safety.png', 0, 'attachment', 'image/png', 0),
(169, 1, '2021-10-15 10:40:13', '2021-10-15 00:40:13', '', 'Raising the Bar: Improving Competence Building a Safer Future Interim Report', '', 'publish', 'closed', 'closed', '', 'raising-the-bar-improving-competence-building-a-safer-future-interim-report-2019', '', '', '2021-10-15 17:19:42', '2021-10-15 07:19:42', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=169', 0, 'publication', '', 0),
(170, 3, '2021-10-15 10:40:08', '2021-10-15 00:40:08', '', 'steering', '', 'inherit', 'open', 'closed', '', 'steering', '', '', '2021-10-15 10:40:08', '2021-10-15 00:40:08', '', 169, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/steering.png', 0, 'attachment', 'image/png', 0),
(171, 3, '2021-10-15 10:41:53', '2021-10-15 00:41:53', '', 'Licensing 159 activities—not 909 (2007)', '', 'publish', 'closed', 'closed', '', 'licensing-159-activities-not-909-2007', '', '', '2021-10-15 10:41:53', '2021-10-15 00:41:53', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=171', 0, 'publication', '', 0),
(172, 3, '2021-10-15 10:41:44', '2021-10-15 00:41:44', '', '159', '', 'inherit', 'open', 'closed', '', '159', '', '', '2021-10-15 10:41:44', '2021-10-15 00:41:44', '', 171, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/159.png', 0, 'attachment', 'image/png', 0),
(173, 1, '2021-10-15 10:43:25', '2021-10-15 00:43:25', '', 'Creating a new profession from scratch', '', 'publish', 'closed', 'closed', '', 'creating-a-new-profession-from-scratch-2008', '', '', '2021-10-15 17:19:16', '2021-10-15 07:19:16', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=173', 0, 'publication', '', 0),
(174, 3, '2021-10-15 10:43:02', '2021-10-15 00:43:02', '', 'scratch', '', 'inherit', 'open', 'closed', '', 'scratch', '', '', '2021-10-15 10:43:02', '2021-10-15 00:43:02', '', 173, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/scratch.png', 0, 'attachment', 'image/png', 0),
(175, 1, '2021-10-15 10:44:42', '2021-10-15 00:44:42', '', 'Private help for a public problem', '', 'publish', 'closed', 'closed', '', 'private-help-for-a-public-problem-2009', '', '', '2021-10-15 17:18:43', '2021-10-15 07:18:43', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=175', 0, 'publication', '', 0),
(176, 3, '2021-10-15 10:44:38', '2021-10-15 00:44:38', '', 'newprofession', '', 'inherit', 'open', 'closed', '', 'newprofession', '', '', '2021-10-15 10:44:38', '2021-10-15 00:44:38', '', 175, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/newprofession.png', 0, 'attachment', 'image/png', 0),
(177, 1, '2021-10-15 11:06:47', '2021-10-15 01:06:47', '', 'Private help for a public problem', '', 'publish', 'closed', 'closed', '', 'private-help-for-a-public-problem-2009-2', '', '', '2021-10-15 17:18:03', '2021-10-15 07:18:03', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=177', 0, 'publication', '', 0),
(178, 3, '2021-10-15 11:06:43', '2021-10-15 01:06:43', '', 'dealing', '', 'inherit', 'open', 'closed', '', 'dealing', '', '', '2021-10-15 11:06:43', '2021-10-15 01:06:43', '', 177, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/dealing.png', 0, 'attachment', 'image/png', 0),
(179, 1, '2021-10-15 11:08:33', '2021-10-15 01:08:33', '', 'Zoning and urban planning – Understanding the benefits', '', 'publish', 'closed', 'closed', '', 'zoning-and-urban-planning-understanding-the-benefits-2015', '', '', '2021-10-15 17:17:12', '2021-10-15 07:17:12', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=179', 0, 'publication', '', 0),
(180, 3, '2021-10-15 11:08:28', '2021-10-15 01:08:28', '', 'zoning', '', 'inherit', 'open', 'closed', '', 'zoning', '', '', '2021-10-15 11:08:28', '2021-10-15 01:08:28', '', 179, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/zoning.png', 0, 'attachment', 'image/png', 0),
(181, 1, '2021-10-15 11:10:29', '2021-10-15 01:10:29', '', 'Fire risk reduction on the margins of an urbanising world', '', 'publish', 'closed', 'closed', '', 'fire-risk-reduction-on-the-margins-of-an-urbanising-world-2019', '', '', '2021-10-15 17:16:50', '2021-10-15 07:16:50', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=181', 0, 'publication', '', 0),
(182, 3, '2021-10-15 11:10:18', '2021-10-15 01:10:18', '', 'edinburgh', '', 'inherit', 'open', 'closed', '', 'edinburgh', '', '', '2021-10-15 11:10:18', '2021-10-15 01:10:18', '', 181, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/edinburgh.png', 0, 'attachment', 'image/png', 0),
(183, 1, '2021-10-15 11:17:22', '2021-10-15 01:17:22', '', 'Fire Safety Engineering – Transitional Plan for Fire Safety Engineering – Report 8 of the Series', '', 'publish', 'closed', 'closed', '', 'fire-safety-engineering-transitional-plan-for-fire-safety-engineering-report-8-of-the-series-2020', '', '', '2021-10-15 17:16:28', '2021-10-15 07:16:28', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=183', 0, 'publication', '', 0),
(184, 3, '2021-10-15 11:14:57', '2021-10-15 01:14:57', '', 'firesafety', '', 'inherit', 'open', 'closed', '', 'firesafety', '', '', '2021-10-15 11:14:57', '2021-10-15 01:14:57', '', 183, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/firesafety.png', 0, 'attachment', 'image/png', 0),
(185, 1, '2021-10-15 11:58:45', '2021-10-15 01:58:45', '', 'Fire Engineering – Challenges, Changes and the Redesign of Regulation', '', 'publish', 'closed', 'closed', '', 'fire-engineering-challenges-changes-and-the-redesign-of-regulation-2020', '', '', '2021-10-15 17:16:01', '2021-10-15 07:16:01', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=185', 0, 'publication', '', 0),
(186, 3, '2021-10-15 11:58:38', '2021-10-15 01:58:38', '', 'redesign', '', 'inherit', 'open', 'closed', '', 'redesign', '', '', '2021-10-15 11:58:38', '2021-10-15 01:58:38', '', 185, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/redesign.png', 0, 'attachment', 'image/png', 0),
(187, 1, '2021-10-15 11:59:52', '2021-10-15 01:59:52', '', 'Prescription in Fire Regulation: Treatment, Cure or Placebo?', '', 'publish', 'closed', 'closed', '', 'prescription-in-fire-regulation-treatment-cure-or-placebo-2019', '', '', '2021-10-15 17:15:34', '2021-10-15 07:15:34', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=187', 0, 'publication', '', 0),
(188, 3, '2021-10-15 11:59:46', '2021-10-15 01:59:46', '', 'prescription', '', 'inherit', 'open', 'closed', '', 'prescription', '', '', '2021-10-15 11:59:46', '2021-10-15 01:59:46', '', 187, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/prescription.png', 0, 'attachment', 'image/png', 0),
(189, 1, '2021-10-15 12:01:00', '2021-10-15 02:01:00', '', 'Independent Review of Building Regulations and Fire Safety: final report', '', 'publish', 'closed', 'closed', '', 'independent-review-of-building-regulations-and-fire-safety-final-report-2018-2', '', '', '2021-10-15 17:15:02', '2021-10-15 07:15:02', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=189', 0, 'publication', '', 0),
(190, 3, '2021-10-15 12:00:55', '2021-10-15 02:00:55', '', 'safer', '', 'inherit', 'open', 'closed', '', 'safer', '', '', '2021-10-15 12:00:55', '2021-10-15 02:00:55', '', 189, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/safer.png', 0, 'attachment', 'image/png', 0),
(191, 1, '2021-10-15 12:01:59', '2021-10-15 02:01:59', '', 'Independent Review of Building Regulations and Fire Safety: interim report', '', 'publish', 'closed', 'closed', '', 'independent-review-of-building-regulations-and-fire-safety-interim-report-2017-2', '', '', '2021-10-15 17:14:34', '2021-10-15 07:14:34', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=191', 0, 'publication', '', 0),
(192, 3, '2021-10-15 12:01:38', '2021-10-15 02:01:38', '', 'future', '', 'inherit', 'open', 'closed', '', 'future', '', '', '2021-10-15 12:01:38', '2021-10-15 02:01:38', '', 191, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/future.png', 0, 'attachment', 'image/png', 0),
(193, 1, '2021-10-15 12:17:23', '2021-10-15 02:17:23', '', 'Beyond the stable door: Hackitt and the future of fire safety regulation in the UK', '', 'publish', 'closed', 'closed', '', 'beyond-the-stable-door-hackitt-and-the-future-of-fire-safety-regulation-in-the-uk-2019-2', '', '', '2021-10-15 17:14:09', '2021-10-15 07:14:09', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=193', 0, 'publication', '', 0),
(194, 3, '2021-10-15 12:17:20', '2021-10-15 02:17:20', '', 'journal', '', 'inherit', 'open', 'closed', '', 'journal', '', '', '2021-10-15 12:17:20', '2021-10-15 02:17:20', '', 193, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/journal.png', 0, 'attachment', 'image/png', 0),
(195, 1, '2021-10-15 12:18:48', '2021-10-15 02:18:48', '', 'Review of Building Regulations and Fire Safety: Submission of Evidence', '', 'publish', 'closed', 'closed', '', 'review-of-building-regulations-and-fire-safety-submission-of-evidence-2', '', '', '2021-10-15 17:13:33', '2021-10-15 07:13:33', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=195', 0, 'publication', '', 0),
(196, 3, '2021-10-15 12:18:44', '2021-10-15 02:18:44', '', 'evidence', '', 'inherit', 'open', 'closed', '', 'evidence', '', '', '2021-10-15 12:18:44', '2021-10-15 02:18:44', '', 195, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/evidence.png', 0, 'attachment', 'image/png', 0),
(197, 1, '2021-10-15 12:20:03', '2021-10-15 02:20:03', '', 'Fire Safety Regulation: Prescription', '', 'publish', 'closed', 'closed', '', 'fire-safety-regulation-prescription', '', '', '2021-10-15 17:21:51', '2021-10-15 07:21:51', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=197', 0, 'publication', '', 0),
(198, 3, '2021-10-15 12:19:50', '2021-10-15 02:19:50', '', 'university', '', 'inherit', 'open', 'closed', '', 'university', '', '', '2021-10-15 12:19:50', '2021-10-15 02:19:50', '', 197, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/university.png', 0, 'attachment', 'image/png', 0),
(199, 1, '2021-10-15 12:21:02', '2021-10-15 02:21:02', '', 'A Review of Sociological Issues in Fire Safety Regulation', '', 'publish', 'closed', 'closed', '', 'a-review-of-sociological-issues-in-fire-safety-regulation-2016', '', '', '2021-10-15 17:13:04', '2021-10-15 07:13:04', '', 0, 'https://dev.sockbrew.design/?post_type=publication&#038;p=199', 0, 'publication', '', 0),
(200, 3, '2021-10-15 12:20:58', '2021-10-15 02:20:58', '', 'last', '', 'inherit', 'open', 'closed', '', 'last', '', '', '2021-10-15 12:20:58', '2021-10-15 02:20:58', '', 199, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/last.png', 0, 'attachment', 'image/png', 0),
(201, 3, '2021-10-15 12:23:36', '2021-10-15 02:23:36', '', 'Professor Charles Lemckert', '', 'inherit', 'closed', 'closed', '', '118-autosave-v1', '', '', '2021-10-15 12:23:36', '2021-10-15 02:23:36', '', 118, 'https://dev.sockbrew.design/?p=201', 0, 'revision', '', 0),
(202, 4, '2021-10-15 12:26:33', '2021-10-15 02:26:33', '', 'Adjunct Professor Kim Lovegrove, RML, MSE', '', 'publish', 'closed', 'closed', '', 'adjunct-professor-kim-lovegrove-rml-mse', '', '', '2021-10-16 16:40:42', '2021-10-16 06:40:42', '', 0, 'https://dev.sockbrew.design/?post_type=board-member&#038;p=202', 0, 'board-member', '', 0),
(203, 3, '2021-10-15 12:25:04', '2021-10-15 02:25:04', '', '1', '', 'inherit', 'open', 'closed', '', '1', '', '', '2021-10-15 12:25:04', '2021-10-15 02:25:04', '', 202, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/1.jpg', 0, 'attachment', 'image/jpeg', 0),
(204, 1, '2021-10-15 17:28:26', '2021-10-15 07:28:26', '', 'The Virtues of Risk-Based Building Classifications & Mandatory Inspections', '', 'inherit', 'open', 'closed', '', 'the-virtues-of-risk-based-building-classifications-mandatory-inspections-2', '', '', '2021-10-15 17:28:26', '2021-10-15 07:28:26', '', 43, 'https://dev.sockbrew.design/wp-content/uploads/2021/09/The-Virtues-of-Risk-Based-Building-Classifications-Mandatory-Inspections.png', 0, 'attachment', 'image/png', 0),
(205, 3, '2021-10-16 09:50:40', '2021-10-15 23:50:40', '<!-- wp:quote {"className":"is-style-large"} -->\n<blockquote class="wp-block-quote is-style-large"><p>To establish a pre-eminent International Centre of Excellence in terms of the identification of building regulatory systems and regimes that are international exemplars.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:separator {"customColor":"#84a7b5","className":"is-style-wide"} -->\n<hr class="wp-block-separator has-text-color has-background is-style-wide" style="background-color:#84a7b5;color:#84a7b5"/>\n<!-- /wp:separator -->\n\n<!-- wp:paragraph -->\n<p>To be a sounding board or point of reference for law reformers, policymakers and stakeholders intent on designing building regulation that provides the greatest opportunity for the realisation of codes and laws that maximise:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li>Public safety;</li><li>Cost-effective and efficient construction systems; and</li><li>Sustainability within the context of the built environment.</li></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>The IBQC will also pave the way for students, who are intent on developing expertise in best practice construction regulation, practices and systems, to embark upon postgraduate studies on point.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The IBQC will be a medium through which comparative analyses can be applied to reforming jurisdictions to enable the potential client to have concepts peer-reviewed.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>This will provide the University of Canberra with the opportunity of commissioning research on point, albeit such research will be remunerative for the University.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The paramount vision being that, through its research and its members, the IBQC will have a positive and material impact on building regulation and practices in Australia and jurisdictions across the world.</p>\n<!-- /wp:paragraph -->', 'Vision', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2021-10-16 09:50:40', '2021-10-15 23:50:40', '', 16, 'https://dev.sockbrew.design/?p=205', 0, 'revision', '', 0),
(206, 1, '2021-10-16 09:58:19', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-10-16 09:58:19', '0000-00-00 00:00:00', '', 0, 'https://dev.sockbrew.design/?p=206', 1, 'nav_menu_item', '', 0),
(207, 1, '2021-10-16 10:17:45', '2021-10-15 23:58:34', ' ', '', '', 'publish', 'closed', 'closed', '', '207', '', '', '2021-10-16 10:17:45', '2021-10-16 00:17:45', '', 0, 'https://dev.sockbrew.design/?p=207', 1, 'nav_menu_item', '', 0),
(208, 1, '2021-10-16 10:17:45', '2021-10-15 23:58:34', ' ', '', '', 'publish', 'closed', 'closed', '', '208', '', '', '2021-10-16 10:17:45', '2021-10-16 00:17:45', '', 0, 'https://dev.sockbrew.design/?p=208', 6, 'nav_menu_item', '', 0),
(209, 1, '2021-10-16 10:17:45', '2021-10-15 23:58:34', ' ', '', '', 'publish', 'closed', 'closed', '', '209', '', '', '2021-10-16 10:17:45', '2021-10-16 00:17:45', '', 0, 'https://dev.sockbrew.design/?p=209', 5, 'nav_menu_item', '', 0),
(210, 1, '2021-10-16 10:17:45', '2021-10-15 23:58:34', ' ', '', '', 'publish', 'closed', 'closed', '', '210', '', '', '2021-10-16 10:17:45', '2021-10-16 00:17:45', '', 0, 'https://dev.sockbrew.design/?p=210', 3, 'nav_menu_item', '', 0),
(211, 1, '2021-10-16 10:17:45', '2021-10-15 23:58:34', ' ', '', '', 'publish', 'closed', 'closed', '', '211', '', '', '2021-10-16 10:17:45', '2021-10-16 00:17:45', '', 0, 'https://dev.sockbrew.design/?p=211', 4, 'nav_menu_item', '', 0),
(212, 1, '2021-10-16 10:17:45', '2021-10-15 23:58:34', ' ', '', '', 'publish', 'closed', 'closed', '', '212', '', '', '2021-10-16 10:17:45', '2021-10-16 00:17:45', '', 0, 'https://dev.sockbrew.design/?p=212', 2, 'nav_menu_item', '', 0),
(213, 1, '2021-10-16 10:58:13', '2021-10-16 00:58:13', '', 'favicon', '', 'inherit', 'open', 'closed', '', 'favicon', '', '', '2021-10-16 10:58:13', '2021-10-16 00:58:13', '', 0, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/favicon.png', 0, 'attachment', 'image/png', 0),
(214, 1, '2021-10-16 10:58:16', '2021-10-16 00:58:16', 'https://dev.sockbrew.design/wp-content/uploads/2021/10/cropped-favicon.png', 'cropped-favicon.png', '', 'inherit', 'open', 'closed', '', 'cropped-favicon-png', '', '', '2021-10-16 10:58:16', '2021-10-16 00:58:16', '', 0, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/cropped-favicon.png', 0, 'attachment', 'image/png', 0),
(216, 1, '2021-10-16 11:34:30', '2021-10-16 01:34:30', '', 'Universal Good Practice Building Regulation: The Key Elements', '', 'publish', 'closed', 'closed', '', 'universal-good-practice-building-regulation-the-key-elements', '', '', '2021-10-16 11:34:30', '2021-10-16 01:34:30', '', 0, 'https://dev.sockbrew.design/?post_type=forum&#038;p=216', 0, 'forum', '', 0),
(217, 1, '2021-10-16 11:29:47', '2021-10-16 01:29:47', '', 'IBQC-Forum-Overview-Agenda', '', 'inherit', 'open', 'closed', '', 'ibqc-forum-overview-agenda', '', '', '2021-10-16 11:29:47', '2021-10-16 01:29:47', '', 216, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/IBQC-Forum-Overview-Agenda.pdf', 0, 'attachment', 'application/pdf', 0),
(218, 3, '2021-10-16 11:45:11', '2021-10-16 01:45:11', '', 'Adjunct Professor Robert Whittaker AM, FRSN, FAIB, FAIQS, MAIBS', '', 'publish', 'closed', 'closed', '', 'adjunct-professor-robert-whittaker-am-frsn-faib-faiqs-maibs', '', '', '2021-10-16 11:45:11', '2021-10-16 01:45:11', '', 0, 'https://dev.sockbrew.design/?post_type=board-member&#038;p=218', 4, 'board-member', '', 0),
(219, 3, '2021-10-16 11:45:07', '2021-10-16 01:45:07', '', '2', '', 'inherit', 'open', 'closed', '', '2', '', '', '2021-10-16 11:45:07', '2021-10-16 01:45:07', '', 218, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/2.jpg', 0, 'attachment', 'image/jpeg', 0),
(220, 1, '2021-10-16 11:46:29', '2021-10-16 01:46:29', '', 'Ms. Bronwyn Weir', '', 'publish', 'closed', 'closed', '', 'ms-bronwyn-weir', '', '', '2021-10-16 12:37:01', '2021-10-16 02:37:01', '', 0, 'https://dev.sockbrew.design/?post_type=board-member&#038;p=220', 6, 'board-member', '', 0),
(221, 3, '2021-10-16 11:46:23', '2021-10-16 01:46:23', '', '3', '', 'inherit', 'open', 'closed', '', '3', '', '', '2021-10-16 11:46:23', '2021-10-16 01:46:23', '', 220, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/3.jpg', 0, 'attachment', 'image/jpeg', 0),
(222, 3, '2021-10-16 11:47:09', '2021-10-16 01:47:09', '', 'Mr. Dominic Sims', '', 'publish', 'closed', 'closed', '', 'mr-dominic-sims', '', '', '2021-10-16 11:47:09', '2021-10-16 01:47:09', '', 0, 'https://dev.sockbrew.design/?post_type=board-member&#038;p=222', 9, 'board-member', '', 0),
(223, 3, '2021-10-16 11:47:04', '2021-10-16 01:47:04', '', '4', '', 'inherit', 'open', 'closed', '', '4', '', '', '2021-10-16 11:47:04', '2021-10-16 01:47:04', '', 222, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/4.jpg', 0, 'attachment', 'image/jpeg', 0),
(224, 3, '2021-10-16 11:50:45', '2021-10-16 01:50:45', '', 'Dame Judith Hackitt', '', 'publish', 'closed', 'closed', '', 'dame-judith-hackitt', '', '', '2021-10-16 11:50:45', '2021-10-16 01:50:45', '', 0, 'https://dev.sockbrew.design/?post_type=board-member&#038;p=224', 10, 'board-member', '', 0),
(225, 3, '2021-10-16 11:48:49', '2021-10-16 01:48:49', '', '5', '', 'inherit', 'open', 'closed', '', '5', '', '', '2021-10-16 11:48:49', '2021-10-16 01:48:49', '', 224, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/5.jpg', 0, 'attachment', 'image/jpeg', 0),
(226, 1, '2021-10-16 11:52:46', '2021-10-16 01:52:46', '', 'Mr Michael de Lint, MA, PLE', '', 'publish', 'closed', 'closed', '', 'mr-michael-de-lint-ma-ple', '', '', '2021-10-16 12:36:06', '2021-10-16 02:36:06', '', 0, 'https://dev.sockbrew.design/?post_type=board-member&#038;p=226', 2, 'board-member', '', 0),
(227, 3, '2021-10-16 11:52:42', '2021-10-16 01:52:42', '', '6', '', 'inherit', 'open', 'closed', '', '6', '', '', '2021-10-16 11:52:42', '2021-10-16 01:52:42', '', 226, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/6.png', 0, 'attachment', 'image/png', 0),
(228, 1, '2021-10-16 11:54:19', '2021-10-16 01:54:19', '', 'Mr Neil Savery', '', 'publish', 'closed', 'closed', '', 'mr-neil-savery', '', '', '2021-10-16 12:36:19', '2021-10-16 02:36:19', '', 0, 'https://dev.sockbrew.design/?post_type=board-member&#038;p=228', 3, 'board-member', '', 0),
(229, 3, '2021-10-16 11:54:13', '2021-10-16 01:54:13', '', '7', '', 'inherit', 'open', 'closed', '', '7', '', '', '2021-10-16 11:54:13', '2021-10-16 01:54:13', '', 228, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/7.png', 0, 'attachment', 'image/png', 0),
(230, 1, '2021-10-16 11:55:16', '2021-10-16 01:55:16', '', 'Mr Alejandro Espinosa-Wang', '', 'publish', 'closed', 'closed', '', 'mr-alejandro-espinosa-wang', '', '', '2021-10-16 12:36:43', '2021-10-16 02:36:43', '', 0, 'https://dev.sockbrew.design/?post_type=board-member&#038;p=230', 5, 'board-member', '', 0),
(231, 3, '2021-10-16 11:55:12', '2021-10-16 01:55:12', '', '8', '', 'inherit', 'open', 'closed', '', '8', '', '', '2021-10-16 11:55:12', '2021-10-16 01:55:12', '', 230, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/8.jpg', 0, 'attachment', 'image/jpeg', 0),
(232, 3, '2021-10-16 11:56:47', '2021-10-16 01:56:47', '', 'Professor José Torero FRSE, FRSN', '', 'publish', 'closed', 'closed', '', 'professor-jose-torero-frse-frsn', '', '', '2021-10-16 11:56:47', '2021-10-16 01:56:47', '', 0, 'https://dev.sockbrew.design/?post_type=board-member&#038;p=232', 7, 'board-member', '', 0),
(233, 3, '2021-10-16 11:56:43', '2021-10-16 01:56:43', '', '9', '', 'inherit', 'open', 'closed', '', '9', '', '', '2021-10-16 11:56:43', '2021-10-16 01:56:43', '', 232, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/9.png', 0, 'attachment', 'image/png', 0),
(234, 3, '2021-10-16 11:57:21', '2021-10-16 01:57:21', '', 'Ms. Stephanie Barwise QC', '', 'publish', 'closed', 'closed', '', 'ms-stephanie-barwise-qc', '', '', '2021-10-16 11:57:21', '2021-10-16 01:57:21', '', 0, 'https://dev.sockbrew.design/?post_type=board-member&#038;p=234', 8, 'board-member', '', 0),
(235, 3, '2021-10-16 11:57:15', '2021-10-16 01:57:15', '', '10', '', 'inherit', 'open', 'closed', '', '10', '', '', '2021-10-16 11:57:15', '2021-10-16 01:57:15', '', 234, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/10.png', 0, 'attachment', 'image/png', 0),
(236, 1, '2021-10-16 11:58:01', '2021-10-16 01:58:01', '', 'ARCH. Professor Alfred Omenya', '', 'publish', 'closed', 'closed', '', 'arch-professor-alfred-omenya', '', '', '2021-10-16 12:37:18', '2021-10-16 02:37:18', '', 0, 'https://dev.sockbrew.design/?post_type=board-member&#038;p=236', 11, 'board-member', '', 0),
(237, 3, '2021-10-16 11:57:56', '2021-10-16 01:57:56', '', '11', '', 'inherit', 'open', 'closed', '', '11', '', '', '2021-10-16 11:57:56', '2021-10-16 01:57:56', '', 236, 'https://dev.sockbrew.design/wp-content/uploads/2021/10/11.jpg', 0, 'attachment', 'image/jpeg', 0),
(239, 1, '2021-10-16 14:19:11', '2021-10-16 04:19:11', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:9:"news-post";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'News Post Fields', 'news-post-fields', 'publish', 'closed', 'closed', '', 'group_616a5225741b3', '', '', '2021-10-16 16:03:23', '2021-10-16 06:03:23', '', 0, 'https://sockbrew.design/?post_type=acf-field-group&#038;p=239', 0, 'acf-field-group', '', 0),
(240, 1, '2021-10-16 14:19:11', '2021-10-16 04:19:11', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:53:"Place a short news article here (500 characters max).";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";i:500;s:4:"rows";s:0:"";s:9:"new_lines";s:7:"wpautop";}', 'News Content', 'news_content', 'publish', 'closed', 'closed', '', 'field_616a522d8aa14', '', '', '2021-10-16 14:19:11', '2021-10-16 04:19:11', '', 239, 'https://sockbrew.design/?post_type=acf-field&p=240', 0, 'acf-field', '', 0),
(241, 1, '2021-10-16 14:20:18', '2021-10-16 04:20:18', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:57:"This image will appear next to the post on the main page.";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'News Post Title Image', 'news_post_title_image', 'publish', 'closed', 'closed', '', 'field_616a52c250180', '', '', '2021-10-16 16:03:23', '2021-10-16 06:03:23', '', 239, 'https://sockbrew.design/?post_type=acf-field&#038;p=241', 1, 'acf-field', '', 0),
(242, 1, '2021-10-16 14:21:00', '2021-10-16 04:21:00', '', 'IBQC News', '', 'publish', 'closed', 'closed', '', 'ibqc-news', '', '', '2021-10-16 16:24:38', '2021-10-16 06:24:38', '', 0, 'https://sockbrew.design/?page_id=242', 0, 'page', '', 0),
(243, 1, '2021-10-16 14:21:00', '2021-10-16 04:21:00', '', 'IBQC News', '', 'inherit', 'closed', 'closed', '', '242-revision-v1', '', '', '2021-10-16 14:21:00', '2021-10-16 04:21:00', '', 242, 'https://sockbrew.design/?p=243', 0, 'revision', '', 0),
(244, 1, '2021-10-16 14:22:39', '2021-10-16 04:22:39', '', 'ICC Pulse Podcast Episode 42: International Building Quality Centre (IBQC) Guidelines for Developing Countries', '', 'publish', 'closed', 'closed', '', 'icc-pulse-podcast-episode-42-international-building-quality-centre-ibqc-guidelines-for-developing-countries', '', '', '2021-10-16 15:53:11', '2021-10-16 05:53:11', '', 0, 'https://sockbrew.design/?post_type=news-post&#038;p=244', 0, 'news-post', '', 0),
(245, 1, '2021-10-16 14:27:26', '2021-10-16 04:27:26', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:158:"Use these two fields to create a clickable button which will appear under the front page with a link to something, such as a podcast or more information page.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";i:1;s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Clickable Link Button', 'clickable_link_button', 'publish', 'closed', 'closed', '', 'field_616a53a9ebc91', '', '', '2021-10-16 14:27:26', '2021-10-16 04:27:26', '', 239, 'https://sockbrew.design/?post_type=acf-field&p=245', 2, 'acf-field', '', 0),
(246, 1, '2021-10-16 14:27:26', '2021-10-16 04:27:26', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:40:"The text that will appear on the button.";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";i:50;}', 'Button Text', 'button_text', 'publish', 'closed', 'closed', '', 'field_616a5446ebc92', '', '', '2021-10-16 15:50:43', '2021-10-16 05:50:43', '', 245, 'https://sockbrew.design/?post_type=acf-field&#038;p=246', 0, 'acf-field', '', 0),
(247, 1, '2021-10-16 14:27:26', '2021-10-16 04:27:26', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:19:"The url to link to.";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'URL', 'url', 'publish', 'closed', 'closed', '', 'field_616a5478ebc93', '', '', '2021-10-16 14:27:26', '2021-10-16 04:27:26', '', 245, 'https://sockbrew.design/?post_type=acf-field&p=247', 1, 'acf-field', '', 0),
(248, 1, '2021-10-16 16:03:50', '2021-10-16 06:03:50', '<!-- wp:cover {"url":"https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png","id":83,"minHeight":600} -->\n<div class="wp-block-cover has-background-dim" style="min-height:600px"><img class="wp-block-cover__image-background wp-image-83" alt="" src="https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"60px"}}} -->\n<p class="has-text-align-center" style="font-size:60px"> Welcome to the IBQC </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {"align":"center","placeholder":"Write title…","fontSize":"medium"} -->\n<p class="has-text-align-center has-medium-font-size"> A pre-eminent International Centre of Excellence in terms of the identification of building regulatory systems and regimes that are international exemplars. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:buttons {"contentJustification":"center"} -->\n<div class="wp-block-buttons is-content-justification-center"><!-- wp:button {"className":"is-style-outline"} -->\n<div class="wp-block-button is-style-outline"><a class="wp-block-button__link" href="https://dev.sockbrew.design/about-ibqc/">Find out more</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons --></div></div>\n<!-- /wp:cover -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2021-10-16 16:03:50', '2021-10-16 06:03:50', '', 8, 'https://sockbrew.design/?p=248', 0, 'revision', '', 0),
(251, 1, '2021-10-16 16:46:22', '2021-10-16 06:46:22', '', 'Leadership', '', 'inherit', 'closed', 'closed', '', '122-revision-v1', '', '', '2021-10-16 16:46:22', '2021-10-16 06:46:22', '', 122, 'https://sockbrew.design/?p=251', 0, 'revision', '', 0),
(252, 1, '2021-10-16 16:46:31', '2021-10-16 06:46:31', '', 'Forums', '', 'inherit', 'closed', 'closed', '', '69-revision-v1', '', '', '2021-10-16 16:46:31', '2021-10-16 06:46:31', '', 69, 'https://sockbrew.design/?p=252', 0, 'revision', '', 0),
(254, 3, '2021-10-16 17:32:39', '2021-10-16 07:32:39', '<!-- wp:cover {"url":"https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png","id":83,"minHeight":600} -->\n<div class="wp-block-cover has-background-dim" style="min-height:600px"><img class="wp-block-cover__image-background wp-image-83" alt="" src="https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"60px"}}} -->\n<p class="has-text-align-center" style="font-size:60px"> Welcome to the IBQC </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {"align":"center","placeholder":"Write title…","fontSize":"medium"} -->\n<p class="has-text-align-center has-medium-font-size"> A pre-eminent International Centre of Excellence in terms of the identification of building regulatory systems and regimes that are international exemplars. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:buttons {"contentJustification":"center"} -->\n<div class="wp-block-buttons is-content-justification-center"><!-- wp:button {"className":"is-style-outline"} -->\n<div class="wp-block-button is-style-outline"><a class="wp-block-button__link" href="https://dev.sockbrew.design/about/">Find out more</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons --></div></div>\n<!-- /wp:cover -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2021-10-16 17:32:39', '2021-10-16 07:32:39', '', 8, 'https://sockbrew.design/?p=254', 0, 'revision', '', 0),
(255, 3, '2021-10-16 17:33:04', '2021-10-16 07:33:04', '<!-- wp:cover {"url":"https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png","id":83,"minHeight":600} -->\n<div class="wp-block-cover has-background-dim" style="min-height:600px"><img class="wp-block-cover__image-background wp-image-83" alt="" src="https://dev.sockbrew.design/wp-content/uploads/2021/10/hero.png" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"60px"}}} -->\n<p class="has-text-align-center" style="font-size:60px"> Welcome to the IBQC </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {"align":"center","placeholder":"Write title…","fontSize":"medium"} -->\n<p class="has-text-align-center has-medium-font-size"> A pre-eminent International Centre of Excellence in terms of the identification of building regulatory systems and regimes that are international exemplars. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:buttons {"contentJustification":"center"} -->\n<div class="wp-block-buttons is-content-justification-center"><!-- wp:button {"className":"is-style-outline"} -->\n<div class="wp-block-button is-style-outline"><a class="wp-block-button__link" href="/about-ibqc/">Find out more</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons --></div></div>\n<!-- /wp:cover -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2021-10-16 17:33:04', '2021-10-16 07:33:04', '', 8, 'https://sockbrew.design/?p=255', 0, 'revision', '', 0),
(256, 2, '2021-10-16 22:34:50', '2021-10-16 12:34:50', '<!-- wp:columns -->\n<div class="wp-block-columns"><!-- wp:column -->\n<div class="wp-block-column"><!-- wp:paragraph -->\n<p> The motivation for the establishment of the IBQC was founded on the recognition that many jurisdictions in recent times have been visited with tremendous challenges on account of building regulations that have not delivered the level of safety and security expected by the public.<br><br>Indeed, there have been regulatory failures that have culminated in the loss of life along with seriously deleterious economic impacts upon citizens.<br><br>These challenges have culminated in recognition by industry stakeholders that a rethinking of the philosophies and traditions that underpin the design of modern-day building control is both timely and necessary.<br><br>The IBQC serves as a collaborative medium through which systems, practices, regulations, codes and laws that provide best practice solutions and answers are identified, endorsed and encouraged. </p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class="wp-block-column"><!-- wp:image {"align":"center","id":99,"sizeSlug":"full","linkDestination":"none"} -->\n<div class="wp-block-image"><figure class="aligncenter size-full"><img src="https://dev.sockbrew.design/wp-content/uploads/2021/10/construction-silhouette-1024x684-1.jpg" alt="" class="wp-image-99"/></figure></div>\n<!-- /wp:image --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->\n\n<!-- wp:columns -->\n<div class="wp-block-columns"><!-- wp:column -->\n<div class="wp-block-column"><!-- wp:image {"align":"center","id":100,"sizeSlug":"full","linkDestination":"none"} -->\n<div class="wp-block-image"><figure class="aligncenter size-full"><img src="https://dev.sockbrew.design/wp-content/uploads/2021/10/construction-worker-truss-installation-1024x684-1.jpg" alt="" class="wp-image-100"/></figure></div>\n<!-- /wp:image --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class="wp-block-column"><!-- wp:paragraph -->\n<p> The IBQC will also, through research and comparative analysis, benchmark and identify jurisdictions that have pioneered and implemented best practice and emerging construction technology, probity regimes and enlightened construction systems and practices. In doing so, it will have regard to that which is best for the present and that which is best for the future.<br><br>As the IBQC will be hosted by the University of Canberra, there will exist the opportunity for students to avail themselves of the resources of the Centre with a view to carrying out further research on best practice regulatory ecology and establishing postgraduate study pathways.<br><br>The IBQC has developed an online library that continues to evolve into a compilation of best practice research publications and papers to generate a resource for students, law reformers, policymakers, practitioners and academics.<br><br>The IBQC aspires to become a sounding board providing an opinion on the viability of regulatory initiatives in terms of their benchmarking with best-practice research on point. </p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->', 'About', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2021-10-16 22:34:50', '2021-10-16 12:34:50', '', 11, 'https://sockbrew.design/?p=256', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(261, 1, '2021-11-30 18:16:01', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-11-30 18:16:01', '0000-00-00 00:00:00', '', 0, 'https://sockbrew.design/?p=261', 0, 'post', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(33, 1, 0),
(41, 6, 0),
(42, 8, 0),
(43, 6, 0),
(43, 7, 0),
(52, 1, 0),
(61, 1, 0),
(104, 1, 0),
(144, 6, 0),
(144, 8, 0),
(146, 9, 0),
(148, 9, 0),
(150, 7, 0),
(152, 8, 0),
(153, 9, 0),
(155, 6, 0),
(157, 7, 0),
(157, 8, 0),
(159, 7, 0),
(161, 7, 0),
(161, 8, 0),
(163, 7, 0),
(163, 8, 0),
(165, 7, 0),
(165, 8, 0),
(167, 7, 0),
(169, 7, 0),
(171, 6, 0),
(173, 6, 0),
(175, 7, 0),
(175, 9, 0),
(177, 7, 0),
(179, 6, 0),
(181, 6, 0),
(183, 6, 0),
(183, 7, 0),
(185, 7, 0),
(185, 8, 0),
(187, 7, 0),
(187, 8, 0),
(189, 6, 0),
(189, 8, 0),
(191, 6, 0),
(191, 8, 0),
(193, 8, 0),
(195, 8, 0),
(197, 8, 0),
(199, 8, 0),
(207, 10, 0),
(208, 10, 0),
(209, 10, 0),
(210, 10, 0),
(211, 10, 0),
(212, 10, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(6, 6, 'publications_category', '', 0, 11),
(7, 7, 'publications_category', '', 0, 14),
(8, 8, 'publications_category', '', 0, 15),
(9, 9, 'publications_category', 'Construction permits', 0, 4),
(10, 10, 'nav_menu', '', 0, 6) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorised', 'uncategorised', 0),
(6, 'Good Practice', 'good-practice', 0),
(7, 'Law Reform', 'law-reform', 0),
(8, 'Regulations', 'regulations', 0),
(9, 'Permits', 'permits', 0),
(10, 'Main Nav', 'main-nav', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'shane.ducksbury'),
(2, 1, 'first_name', 'Shane'),
(3, 1, 'last_name', 'Ducksbury'),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '261'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:13:"108.162.250.0";}'),
(19, 2, 'nickname', 'olly.hills'),
(20, 2, 'first_name', 'Olly'),
(21, 2, 'last_name', 'Hills'),
(22, 2, 'description', ''),
(23, 2, 'rich_editing', 'true'),
(24, 2, 'syntax_highlighting', 'true'),
(25, 2, 'comment_shortcuts', 'false'),
(26, 2, 'admin_color', 'fresh'),
(27, 2, 'use_ssl', '0'),
(28, 2, 'show_admin_bar_front', 'true'),
(29, 2, 'locale', ''),
(30, 2, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(31, 2, 'wp_user_level', '10'),
(32, 2, 'dismissed_wp_pointers', ''),
(33, 3, 'nickname', 'kate.mcginness'),
(34, 3, 'first_name', 'Kate'),
(35, 3, 'last_name', 'McGinness'),
(36, 3, 'description', ''),
(37, 3, 'rich_editing', 'true'),
(38, 3, 'syntax_highlighting', 'true'),
(39, 3, 'comment_shortcuts', 'false'),
(40, 3, 'admin_color', 'fresh'),
(41, 3, 'use_ssl', '0'),
(42, 3, 'show_admin_bar_front', 'true'),
(43, 3, 'locale', ''),
(44, 3, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(45, 3, 'wp_user_level', '10'),
(46, 3, 'dismissed_wp_pointers', ''),
(47, 3, 'session_tokens', 'a:2:{s:64:"2548bebef9c17598cf85eee71ef2b949a3f1b536eecfa4ddcd9d138dfb3366eb";a:4:{s:10:"expiration";i:1635037115;s:2:"ip";s:15:"108.162.250.166";s:2:"ua";s:130:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.81 Safari/537.36 Edg/94.0.992.50";s:5:"login";i:1634864315;}s:64:"0a5b2e40920f4150b76aee979f840887407a2e6f26c795353fa552253d6bf6f4";a:4:{s:10:"expiration";i:1635037773;s:2:"ip";s:14:"108.162.250.26";s:2:"ua";s:130:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.81 Safari/537.36 Edg/94.0.992.50";s:5:"login";i:1634864973;}}'),
(48, 3, 'wp_dashboard_quick_press_last_post_id', '140'),
(49, 3, 'community-events-location', 'a:1:{s:2:"ip";s:13:"108.162.250.0";}'),
(50, 2, 'session_tokens', 'a:3:{s:64:"87f21e81b63bbc7fcce80e0bfa3e00344812bb0ca1936557f94f80932a54c727";a:4:{s:10:"expiration";i:1634521533;s:2:"ip";s:15:"108.162.250.197";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.81 Safari/537.36";s:5:"login";i:1634348733;}s:64:"5834c353d2ee7dab496544678541de07c98602988c824a38fa2640e0d4ecdb4e";a:4:{s:10:"expiration";i:1634537678;s:2:"ip";s:14:"108.162.250.26";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.81 Safari/537.36";s:5:"login";i:1634364878;}s:64:"737bbe45e1af3276774b9c26ccbc4bb8d03497a7fc2b93f77ebe856320cc512a";a:4:{s:10:"expiration";i:1634537692;s:2:"ip";s:14:"108.162.250.26";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.81 Safari/537.36";s:5:"login";i:1634364892;}}'),
(51, 2, 'wp_dashboard_quick_press_last_post_id', '139'),
(52, 2, 'community-events-location', 'a:1:{s:2:"ip";s:13:"108.162.250.0";}'),
(53, 1, 'wpmdb_dismiss_muplugin_failed_update_1.2', '1'),
(54, 2, 'wp_user-settings', 'libraryContent=browse'),
(55, 2, 'wp_user-settings-time', '1633848924'),
(56, 1, 'wp_user-settings', 'libraryContent=browse'),
(57, 1, 'wp_user-settings-time', '1634197542'),
(58, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(59, 1, 'metaboxhidden_nav-menus', 'a:5:{i:0;s:25:"add-post-type-publication";i:1;s:19:"add-post-type-forum";i:2;s:26:"add-post-type-board-member";i:3;s:12:"add-post_tag";i:4;s:25:"add-publications_category";}'),
(60, 3, 'wp_user-settings', 'libraryContent=browse'),
(61, 3, 'wp_user-settings-time', '1634252894'),
(62, 1, 'nav_menu_recently_edited', '10'),
(63, 3, 'nav_menu_recently_edited', '10'),
(64, 3, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(65, 3, 'metaboxhidden_nav-menus', 'a:5:{i:0;s:25:"add-post-type-publication";i:1;s:19:"add-post-type-forum";i:2;s:26:"add-post-type-board-member";i:3;s:12:"add-post_tag";i:4;s:25:"add-publications_category";}'),
(66, 4, 'nickname', 'demo.user'),
(67, 4, 'first_name', 'Demo'),
(68, 4, 'last_name', 'User'),
(69, 4, 'description', ''),
(70, 4, 'rich_editing', 'true'),
(71, 4, 'syntax_highlighting', 'true'),
(72, 4, 'comment_shortcuts', 'false'),
(73, 4, 'admin_color', 'fresh'),
(74, 4, 'use_ssl', '0'),
(75, 4, 'show_admin_bar_front', 'true'),
(76, 4, 'locale', ''),
(77, 4, 'wp_capabilities', 'a:1:{s:16:"ibqc_team_member";b:1;}'),
(78, 4, 'wp_user_level', '7'),
(79, 4, 'dismissed_wp_pointers', ''),
(81, 4, 'wp_dashboard_quick_press_last_post_id', '250'),
(82, 4, 'community-events-location', 'a:1:{s:2:"ip";s:13:"108.162.250.0";}'),
(83, 5, 'nickname', 'riley.post'),
(84, 5, 'first_name', 'Riley'),
(85, 5, 'last_name', 'Post'),
(86, 5, 'description', ''),
(87, 5, 'rich_editing', 'true'),
(88, 5, 'syntax_highlighting', 'true'),
(89, 5, 'comment_shortcuts', 'false'),
(90, 5, 'admin_color', 'fresh'),
(91, 5, 'use_ssl', '0'),
(92, 5, 'show_admin_bar_front', 'true'),
(93, 5, 'locale', ''),
(94, 5, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(95, 5, 'wp_user_level', '10'),
(96, 5, 'dismissed_wp_pointers', ''),
(97, 4, 'closedpostboxes_dashboard', 'a:0:{}'),
(98, 4, 'metaboxhidden_dashboard', 'a:4:{i:0;s:19:"dashboard_right_now";i:1;s:18:"dashboard_activity";i:2;s:21:"dashboard_quick_press";i:3;s:17:"dashboard_primary";}'),
(99, 1, 'session_tokens', 'a:1:{s:64:"36d6f8d44297b92e6135c47b8f17b871ffd55f5d0549b2c543be7837f888a8f5";a:4:{s:10:"expiration";i:1638432960;s:2:"ip";s:15:"108.162.250.178";s:2:"ua";s:68:"Mozilla/5.0 (X11; Linux x86_64; rv:94.0) Gecko/20100101 Firefox/94.0";s:5:"login";i:1638260160;}}'),
(101, 5, 'wp_dashboard_quick_press_last_post_id', '260'),
(102, 5, 'community-events-location', 'a:1:{s:2:"ip";s:13:"108.162.250.0";}'),
(103, 5, 'session_tokens', 'a:1:{s:64:"47da8094e4343774faf000254fdefe42ca5df52003f322f5cc2f8c5d921324ad";a:4:{s:10:"expiration";i:1637096290;s:2:"ip";s:15:"108.162.250.178";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.81 Safari/537.36";s:5:"login";i:1636923490;}}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'shane.ducksbury', '$P$B6xUlHUUzgWzS8DL9JV1v9Ra/9wBXM/', 'shane-ducksbury', 'u3113923@uni.canberra.edu.au', 'http://dev.sockbrew.design', '2021-09-11 10:11:29', '', 0, 'shane.ducksbury'),
(2, 'olly.hills', '$P$BwIGsOHf9YKjg7leNbM346jdFfDeqW.', 'olly-hills', 'u3218519@uni.canberra.edu.au', '', '2021-09-12 08:43:54', '1631436234:$P$Bw.y8Dw32zW6xfbad.xR6NyF4UB73O/', 0, 'Olly Hills'),
(3, 'kate.mcginness', '$P$B6apr/U.q.YAm//x4kwshMLZI05VVH.', 'kate-mcginness', 'u3095286@uni.canberra.edu.au', '', '2021-09-12 08:47:50', '1631436470:$P$B6SHPUo.2soVryJzI8V6c9N4qT072K/', 0, 'Kate McGinness'),
(4, 'demo.user', '$P$BKXV38Z6/PMgco2CoRAr68dz11nD6G/', 'demo-user', 'demo@sockbrew.design', '', '2021-10-16 06:39:13', '', 0, 'Demo User'),
(5, 'riley.post', '$P$BtwZC7sslrEKj6u.OMqxLLKXvXziJZ/', 'riley-post', 'Riley.Post@canberra.edu.au', '', '2021-10-16 06:44:09', '', 0, 'Riley Post') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_wpforms_tasks_meta`
#

DROP TABLE IF EXISTS `wp_wpforms_tasks_meta`;


#
# Table structure of table `wp_wpforms_tasks_meta`
#

CREATE TABLE `wp_wpforms_tasks_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wpforms_tasks_meta`
#
INSERT INTO `wp_wpforms_tasks_meta` ( `id`, `action`, `data`, `date`) VALUES
(1, 'wpforms_process_entry_emails_meta_cleanup', 'Wzg2NDAwXQ==', '2021-10-10 00:01:14'),
(2, 'wpforms_admin_addons_cache_update', 'W10=', '2021-10-10 00:01:14'),
(3, 'wpforms_admin_builder_templates_cache_update', 'W10=', '2021-10-10 00:01:14'),
(4, 'wpforms_admin_notifications_update', 'W10=', '2021-10-10 00:04:28'),
(5, 'wpforms_admin_notifications_update', 'W10=', '2021-10-11 00:04:36'),
(6, 'wpforms_admin_notifications_update', 'W10=', '2021-10-11 00:05:01'),
(7, 'wpforms_admin_notifications_update', 'W10=', '2021-10-13 09:48:23'),
(8, 'wpforms_admin_notifications_update', 'W10=', '2021-10-14 10:13:53'),
(9, 'wpforms_admin_notifications_update', 'W10=', '2021-10-14 10:15:06'),
(10, 'wpforms_admin_notifications_update', 'W10=', '2021-10-15 23:44:36'),
(11, 'wpforms_admin_notifications_update', 'W10=', '2021-10-17 01:50:47'),
(12, 'wpforms_builder_help_cache_update', 'W10=', '2021-10-17 22:29:54'),
(13, 'wpforms_admin_notifications_update', 'W10=', '2021-10-20 05:57:14'),
(14, 'wpforms_admin_notifications_update', 'W10=', '2021-10-22 00:58:36'),
(15, 'wpforms_admin_notifications_update', 'W10=', '2021-11-14 20:58:12'),
(16, 'wpforms_admin_notifications_update', 'W10=', '2021-11-30 08:16:01'),
(17, 'wpforms_admin_notifications_update', 'W10=', '2021-11-30 08:16:54') ;

#
# End of data contents of table `wp_wpforms_tasks_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_wpmailsmtp_debug_events`
#

DROP TABLE IF EXISTS `wp_wpmailsmtp_debug_events`;


#
# Table structure of table `wp_wpmailsmtp_debug_events`
#

CREATE TABLE `wp_wpmailsmtp_debug_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content` text COLLATE utf8mb4_unicode_520_ci,
  `initiator` text COLLATE utf8mb4_unicode_520_ci,
  `event_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wpmailsmtp_debug_events`
#
INSERT INTO `wp_wpmailsmtp_debug_events` ( `id`, `content`, `initiator`, `event_type`, `created_at`) VALUES
(1, 'Mailer: Gmail\r\n{\n  "error": {\n    "code": 401,\n    "message": "Request is missing required authentication credential. Expected OAuth 2 access token, login cookie or other valid authentication credential. See https://developers.google.com/identity/sign-in/web/devconsole-project.",\n    "errors": [\n      {\n        "message": "Login Required.",\n        "domain": "global",\n        "reason": "required",\n        "location": "Authorization",\n        "locationType": "header"\n      }\n    ],\n    "status": "UNAUTHENTICATED"\n  }\n}', '{"file":"\\/var\\/www\\/html\\/wp-content\\/plugins\\/wp-mail-smtp\\/src\\/Reports\\/Emails\\/Summary.php","line":112}', 0, '2021-10-11 04:00:32'),
(2, 'Mailer: Gmail\r\n{\n  "error": {\n    "code": 401,\n    "message": "Request is missing required authentication credential. Expected OAuth 2 access token, login cookie or other valid authentication credential. See https://developers.google.com/identity/sign-in/web/devconsole-project.",\n    "errors": [\n      {\n        "message": "Login Required.",\n        "domain": "global",\n        "reason": "required",\n        "location": "Authorization",\n        "locationType": "header"\n      }\n    ],\n    "status": "UNAUTHENTICATED"\n  }\n}', '{"file":"\\/var\\/www\\/html\\/wp-content\\/plugins\\/wpforms-lite\\/src\\/Emails\\/Mailer.php","line":509}', 0, '2021-10-11 04:00:33') ;

#
# End of data contents of table `wp_wpmailsmtp_debug_events`
# --------------------------------------------------------



#
# Delete any existing table `wp_wpmailsmtp_tasks_meta`
#

DROP TABLE IF EXISTS `wp_wpmailsmtp_tasks_meta`;


#
# Table structure of table `wp_wpmailsmtp_tasks_meta`
#

CREATE TABLE `wp_wpmailsmtp_tasks_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wpmailsmtp_tasks_meta`
#
INSERT INTO `wp_wpmailsmtp_tasks_meta` ( `id`, `action`, `data`, `date`) VALUES
(1, 'wp_mail_smtp_summary_report_email', 'W10=', '2021-10-10 00:26:04'),
(2, 'wp_mail_smtp_admin_notifications_update', 'W10=', '2021-10-10 00:33:59'),
(3, 'wp_mail_smtp_admin_notifications_update', 'W10=', '2021-10-11 01:09:26'),
(4, 'wp_mail_smtp_admin_notifications_update', 'W10=', '2021-10-13 09:48:23'),
(5, 'wp_mail_smtp_admin_notifications_update', 'W10=', '2021-10-14 10:13:53'),
(6, 'wp_mail_smtp_admin_notifications_update', 'W10=', '2021-10-14 10:15:06'),
(7, 'wp_mail_smtp_admin_notifications_update', 'W10=', '2021-10-15 23:44:36'),
(8, 'wp_mail_smtp_admin_notifications_update', 'W10=', '2021-10-17 01:50:47'),
(9, 'wp_mail_smtp_admin_notifications_update', 'W10=', '2021-10-20 05:57:14'),
(10, 'wp_mail_smtp_admin_notifications_update', 'W10=', '2021-10-22 00:58:36'),
(11, 'wp_mail_smtp_admin_notifications_update', 'W10=', '2021-11-14 20:58:12'),
(12, 'wp_mail_smtp_admin_notifications_update', 'W10=', '2021-11-30 08:16:01'),
(13, 'wp_mail_smtp_admin_notifications_update', 'W10=', '2021-11-30 08:16:54') ;

#
# End of data contents of table `wp_wpmailsmtp_tasks_meta`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

